<div class="tab-pane fade" id="popMessages" role="tabpanel" aria-labelledby="popMessages-tab">
    
    <?php if($member->pop_messages->count() < 1): ?>
        <div class="form-group">
            <a href="<?php echo e(route('admin.popMessage.create', $member->id)); ?>" class="btn btn-info btn-xs">
                <i class="fas fa-plus"></i> &nbsp; <?php echo e(trans('global.pop_messages')); ?>

            </a>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered table-striped table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo e(trans('global.message')); ?></th>
                        <th><?php echo e(trans('cruds.bonu.fields.created_by')); ?></th>
                        <th><?php echo e(trans('global.created_at')); ?></th>
                        <th><?php echo e(trans('global.actions')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $member->pop_messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($message->message ?? '-'); ?></td>
                            <td><?php echo e($message->created_by->name ?? '-'); ?></td>
                            <td><?php echo e($message->created_at); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.popMessage.show', $message->id)); ?>" target="_blank"
                                    class="btn btn-info btn-xs">
                                    <i class="fa fa-eye"></i> <?php echo e(trans('global.show')); ?>

                                </a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_notes')): ?>
                                    <form action="<?php echo e(route('admin.popMessage.destroy', $message->id)); ?>" method="POST"
                                        onsubmit="return confirm('Are you sure?');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger btn-xs">
                                            <i class="fa fa-trash"></i> &nbsp; Delete
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td colspan="4" class="text-center">No data Available</td>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH E:\projects\gymapp\resources\views/admin/members/tabs/pop_messages.blade.php ENDPATH**/ ?>