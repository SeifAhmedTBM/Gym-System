
<?php $__env->startSection('content'); ?>
    
        <div style="margin-bottom: 10px;" class="row">
            <div class="col-lg-6">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expense_create')): ?>
                    <a class="btn btn-success" href="<?php echo e(route('admin.expenses.create')); ?>">
                        <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.expense.title_singular')); ?>

                    </a>

                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('export_expenses')): ?>
                    <a href="<?php echo e(route('admin.expenses.export',request()->all())); ?>" class="btn btn-info"><i class="fa fa-download">
                        </i> <?php echo e(trans('global.export_excel')); ?>

                    </a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expenses_filter')): ?>
                    <?php echo $__env->make('admin_includes.filters', [
                    'columns' => [
                        'name' => ['label' => 'Name', 'type' => 'text'],
                        'amount' => ['label' => 'Amount', 'type' => 'number'],
                        'account_id' => ['label' => 'Account', 'type' => 'select' , 'data' => $accounts],
                        'expenses_category_id'  => ['label' => 'Expenses Category', 'type' => 'select' , 'data' => $expenses_categories ,'related_to' => 'expenses_category'],
                        'created_by_id' => ['label' => 'Created By', 'type' => 'select', 'data' => $users],
                        'date' => ['label' => 'Date', 'type' => 'date','from_and_to' => true],
                        'created_at' => ['label' => 'Created at', 'type' => 'date', 'from_and_to' => true]
                    ],
                        'route' => 'admin.expenses.index'
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('csvImport.modal', ['model' => 'Expense', 'route' => 'admin.expenses.parseCsvImport'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expenses_counter')): ?>
            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-body" style="text-align:center">
                        <h2 class="text-center"><?php echo e(trans('cruds.expense.title_singular')); ?></h2>
                        <h2 class="text-center"><?php echo e($monthly_expences->count()); ?></h2>
                        <small class="text-center text-danger">Current Month Total</small>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-body" style="text-align:center">
                        <h2 class="text-center"><?php echo e(trans('cruds.expense.fields.amount')); ?></h2>
                        <h2 class="text-center"><?php echo e(number_format($monthly_expences->sum('amount')) ?? 0); ?></h2>
                        <small class="text-center text-danger">Current Month Total</small>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    
    <div class="card">
        <div class="card-header">
            <h5><?php echo e(trans('cruds.expense.title_singular')); ?> <?php echo e(trans('global.list')); ?></h5>
        </div>

        <div class="card-body">
            <table class=" table table-bordered table-striped table-hover ajaxTable datatable datatable-Expense">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.expense.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.expense.fields.expenses_category')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.branch.title_singular')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.expense.fields.name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.expense.fields.date')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.account.title_singular')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.expense.fields.amount')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.expense.fields.created_by')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <script>
        $(function() {
            let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expense_delete')): ?>
                let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>';
                let deleteButton = {
                text: deleteButtonTrans,
                url: "<?php echo e(route('admin.expenses.massDestroy')); ?>",
                className: 'btn-danger',
                action: function (e, dt, node, config) {
                var ids = $.map(dt.rows({ selected: true }).data(), function (entry) {
                return entry.id
                });
            
                if (ids.length === 0) {
                alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')
            
                return
                }
            
                if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
                $.ajax({
                headers: {'x-csrf-token': _token},
                method: 'POST',
                url: config.url,
                data: { ids: ids, _method: 'DELETE' }})
                .done(function () { location.reload() })
                }
                }
                }
                dtButtons.push(deleteButton)
            <?php endif; ?>

            let dtOverrideGlobals = {
                buttons:[],
                processing: true,
                serverSide: true,
                retrieve: true,
                searching:true,
                aaSorting: [],
                ajax: "<?php echo e(route('admin.expenses.index', request()->all())); ?>",
                columns: [{
                        data: 'placeholder',
                        name: 'placeholder'
                    },
                    {
                        data: 'id',
                        name: 'id'
                    },
                    {
                        data: 'expenses_category_name',
                        name: 'expenses_category.name'
                    },
                    {
                        data: 'branch_name',
                        name: 'branch_name'
                    },
                    {
                        data: 'name',
                        name: 'name'
                    },
                    {
                        data: 'date',
                        name: 'date'
                    },
                    {
                        data: 'account_name',
                        name: 'account.name'
                    },
                    {
                        data: 'amount',
                        name: 'amount'
                    },
                   
                    {
                        data: 'created_by_name',
                        name: 'created_by.name'
                    },
                    {
                        data: 'actions',
                        name: '<?php echo e(trans('global.actions')); ?>'
                    }
                ],
                orderCellsTop: true,
                order: [
                    [1, 'desc']
                ],
                pageLength: 50,
            };
            let table = $('.datatable-Expense').DataTable(dtOverrideGlobals);
            $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e) {
                $($.fn.dataTable.tables(true)).DataTable()
                    .columns.adjust();
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Gym-System\resources\views/admin/expenses/index.blade.php ENDPATH**/ ?>