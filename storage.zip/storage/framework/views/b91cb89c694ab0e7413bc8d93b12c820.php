
<?php $__env->startSection('content'); ?>
<style>
    /* *{
        font-size: 10px!important;
        font-weight: bold;
    } */
</style>
    <div class="card">
        <div class="card-header">
            Monthly Overall Report
        </div>
        <?php
            use Carbon\Carbon;
        ?>
        <div class="card-body">
            <h4 style="padding:10px 0px ">Current Month Report From : <?php echo e(Carbon::now()->startOfMonth()->format('Y-m-d')); ?> To : <?php echo e(Carbon::now()->format('Y-m-d')); ?> </h4>
            <table class="table table-striped table-hover table-bordered zero-configuration">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Branch</th>
                        <th class="bg-primary">Income</th>
                        <th class="bg-danger">Outcome</th>
                        <th class="bg-success">Net Income</th>
                        <th class="bg-secondary">Partner</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $total_income = 0;
                        $total_outcome = 0;
                        $total_net = 0;
                        $partner_total = 0;
                    ?>
                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $tran_payments = $branch->transactions->where('transactionable_type', 'App\Models\Payment')->sum('amount');
                            $tran_externalPayments = $branch->transactions->where('transactionable_type', 'App\Models\ExternalPayment')->sum('amount');
                            $income = ($tran_payments + $tran_externalPayments);
                            
                            $tran_refunds = $branch->transactions->where('transactionable_type', 'App\Models\Refund')->sum('amount');
                            $tran_loans = $branch->transactions->where('transactionable_type', 'App\Models\Loan')->sum('amount');
                            $tran_expenses = $branch->transactions->where('transactionable_type', 'App\Models\Expense')->sum('amount');
                            $total_comission = 0;
                            $tran_expenses_commission = $branch->transactions->whereIn('transactionable_type', ['App\Models\Payment','App\Models\ExternalPayment']);
                            foreach ($tran_expenses_commission as $key => $tr) {
                                if($tr->account->commission_percentage > 0 ){
                                    $total_comission =  $total_comission + $tr->amount * ($tr->account->commission_percentage/100);
                                }
                            }
                            $outcome = ($tran_refunds + $tran_loans + $tran_expenses + $total_comission);

                            $total_income = $total_income +$income;
                            $total_outcome = $total_outcome +$outcome;
                            $total_net = $total_net +($income - $outcome);

                            $partner_net = ((($income - $outcome) * $branch->partner_percentage)/100);
                            $partner_total += $partner_net;
                        ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($branch->name); ?></td>
                            <td class="bg-primary"><?php echo e(number_format($income)); ?></td>
                            <td class="bg-danger"><?php echo e(number_format($outcome)); ?></td>
                            <td class="bg-success"><?php echo e(number_format($income - $outcome)); ?></td>
                            <td class="bg-secondary"><?php echo e(number_format($partner_net)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="bg-success" colspan="2" style="text-align:center;">Total</td>
                        <td class="bg-success"> <?php echo e(number_format($total_income)); ?> </td>
                        <td class="bg-success"> <?php echo e(number_format($total_outcome)); ?> </td>
                        <td class="bg-success"> <?php echo e(number_format($total_net)); ?> </td>
                        <td class="bg-success"> <?php echo e(number_format($partner_total)); ?></td>
                    </tr>
                </tbody>
            </table>
            <h4 style="padding:10px 0px ">Previous Month Report From : <?php echo e($startOfLastMonth); ?> To : <?php echo e($endOfLastMonth); ?> </h4>
           <table class="table table-striped table-hover table-bordered zero-configuration">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Branch</th>
                        <th class="bg-primary">Income</th>
                        <th class="bg-danger">Outcome</th>
                        <th class="bg-success">Net Income</th>
                        <th class="bg-secondary">Partner</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $total_income = 0;
                        $total_outcome = 0;
                        $total_net = 0;
                        $partner_total = 0;
                    ?>
                    <?php $__currentLoopData = $lastMonthBranchesTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $tran_payments = $branch->transactions->where('transactionable_type', 'App\Models\Payment')->sum('amount');
                            $tran_externalPayments = $branch->transactions->where('transactionable_type', 'App\Models\ExternalPayment')->sum('amount');
                            $income = ($tran_payments + $tran_externalPayments);
                            
                            $tran_refunds = $branch->transactions->where('transactionable_type', 'App\Models\Refund')->sum('amount');
                            $tran_loans = $branch->transactions->where('transactionable_type', 'App\Models\Loan')->sum('amount');
                            $tran_expenses = $branch->transactions->where('transactionable_type', 'App\Models\Expense')->sum('amount');
                            $total_comission = 0;
                            $tran_expenses_commission = $branch->transactions->whereIn('transactionable_type', ['App\Models\Payment','App\Models\ExternalPayment']);
                            foreach ($tran_expenses_commission as $key => $tr) {
                                if($tr->account->commission_percentage > 0 ){
                                    $total_comission =  $total_comission + $tr->amount * ($tr->account->commission_percentage/100);
                                }
                            }
                            $outcome = ($tran_refunds + $tran_loans + $tran_expenses + $total_comission);

                            $total_income = $total_income +$income;
                            $total_outcome = $total_outcome +$outcome;
                            $total_net = $total_net +($income - $outcome);

                            $partner_net = ((($income - $outcome) * $branch->partner_percentage)/100);
                            $partner_total += $partner_net;
                        ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($branch->name); ?></td>
                            <td class="bg-primary"><?php echo e(number_format($income)); ?></td>
                            <td class="bg-danger"><?php echo e(number_format($outcome)); ?></td>
                            <td class="bg-success"><?php echo e(number_format($income - $outcome)); ?></td>
                            <td class="bg-secondary"><?php echo e(number_format($partner_net)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="bg-success" colspan="2" style="text-align:center;">Total</td>
                        <td class="bg-success"> <?php echo e(number_format($total_income)); ?> </td>
                        <td class="bg-success"> <?php echo e(number_format($total_outcome)); ?> </td>
                        <td class="bg-success"> <?php echo e(number_format($total_net)); ?> </td>
                        <td class="bg-success"> <?php echo e(number_format($partner_total)); ?></td>
                    </tr>
                </tbody>
           </table>
          
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            Sales Monthly Performance
        </div>
        <div class="card-body">
            <div class="form-group">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(URL::current()); ?>" method="get">
                            <div class="form-group">
                                <label for="date"><?php echo e(trans('global.branches')); ?></label>
                                <div class="input-group">
                                    <!-- <input type="date" class="form-control" name="from"
                                        value="<?php echo e($startOfLastMonth); ?>" disabled>
                                    <input type="date" class="form-control" name="to"
                                        value="<?php echo e($endOfLastMonth); ?>" disabled> -->
                                    <select name="branch_id" id="branch_id" class="form-control"
                                        <?php echo e($employee && $employee->branch_id != null ? 'readonly' : ''); ?>>
                                        <option value="<?php echo e(null); ?>" selected hidden disabled>Branch</option>
                                        <?php $__currentLoopData = \App\Models\Branch::pluck('name', 'id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($id); ?>" <?php echo e($branch_id == $id ? 'selected' : ''); ?>>
                                                <?php echo e($name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <div class="input-group-prepend">
                                        <button class="btn btn-primary" type="submit"><?php echo e(trans('global.submit')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <h4 style="padding:10px 0px ">Current Month Sales Report From : <?php echo e(Carbon::now()->startOfMonth()->format('Y-m-d')); ?> To : <?php echo e(Carbon::now()->format('Y-m-d')); ?> </h4>
            <div class="form-group row">
                <div class="col-sm-4 col-lg-4">
                    <div class="card mb-2">
                        <div class="card-body text-center text-white bg-primary">
                            <div>
                                <h3><?php echo e(number_format($current_month_invoices)); ?></h3>
                                <div>Invoices</div>
                                <strong>( total net amount )</strong>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                    <div class="card mb-2 text-center text-white bg-success">
                        <div class="card-body">
                            <div>
                                <h3><?php echo e(number_format($current_month_payments_sum_amount)); ?></h3>
                                <div>Payments</div>
                                <strong>( total payments for invoices this month )</strong>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                    <div class="card mb-2 text-center text-white bg-warning">
                        <div class="card-body">
                            <div>
                                <h3><?php echo e(number_format($current_month_pending)); ?></h3>
                                <div>Pending</div>
                                <strong>( Pending amounts this month )</strong>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                    <div class="card mb-2 text-center text-white bg-success">
                        <div class="card-body">
                            <div>
                                <h3><?php echo e(number_format($current_month_payments)); ?></h3>
                                <div>All Payments</div>
                                <strong>( total payments collected this month )</strong>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                    <div class="card mb-2 text-center text-white bg-danger">
                        <div class="card-body">
                            <div>
                                <h3><?php echo e(number_format($current_month_refunds)); ?></h3>
                                <div>Refunds</div>
                                <strong>( total refunds this month )</strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            

            <h4 style="padding:10px 0px ">Previous Month Sales Report From : <?php echo e($startOfLastMonth); ?> To : <?php echo e($endOfLastMonth); ?> </h4>
            
            <div class="form-group row">
                <div class="col-sm-4 col-lg-4">
                    <div class="card mb-2">
                        <div class="card-body text-center text-white bg-primary">
                            <div>
                                <h3><?php echo e(number_format($invoices)); ?></h3>
                                <div>Invoices</div>
                                <strong>( total net amount )</strong>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                    <div class="card mb-2 text-center text-white bg-success">
                        <div class="card-body">
                            <div>
                                <h3><?php echo e(number_format($payments_sum_amount)); ?></h3>
                                <div>Payments</div>
                                <strong>( total payments for invoices this month )</strong>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                    <div class="card mb-2 text-center text-white bg-warning">
                        <div class="card-body">
                            <div>
                                <h3><?php echo e(number_format($pending)); ?></h3>
                                <div>Pending</div>
                                <strong>( Pending amounts this month )</strong>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                    <div class="card mb-2 text-center text-white bg-success">
                        <div class="card-body">
                            <div>
                                <h3><?php echo e(number_format($payments)); ?></h3>
                                <div>All Payments</div>
                                <strong>( total payments collected this month )</strong>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4">
                    <div class="card mb-2 text-center text-white bg-danger">
                        <div class="card-body">
                            <div>
                                <h3><?php echo e(number_format($refunds)); ?></h3>
                                <div>Refunds</div>
                                <strong>( total refunds this month )</strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            Trainer Monthly Report
        </div>
        <div class="card-body">
          <div class="form-group">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(URL::current()); ?>" method="get">
                        <div class="form-group">
                            <label for="date"><?php echo e(trans('global.branches')); ?></label>
                            <div class="input-group">
                                <!-- <input type="date" class="form-control" name="from"
                                    value="<?php echo e($startOfLastMonth); ?>" disabled>
                                <input type="date" class="form-control" name="to"
                                    value="<?php echo e($endOfLastMonth); ?>" disabled> -->
                                <select name="branch_id" id="branch_id" class="form-control"
                                    <?php echo e($employee && $employee->branch_id != null ? 'readonly' : ''); ?>>
                                    <option value="<?php echo e(null); ?>" selected hidden disabled>Branch</option>
                                    <?php $__currentLoopData = \App\Models\Branch::pluck('name', 'id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($id); ?>" <?php echo e($branch_id == $id ? 'selected' : ''); ?>>
                                            <?php echo e($name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="input-group-prepend">
                                    <button class="btn btn-primary" type="submit"><?php echo e(trans('global.submit')); ?></button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
          </div>
          

          
          
          <h4 style="padding:10px 0px ">Current Month Trainer Report From : <?php echo e(Carbon::now()->startOfMonth()->format('Y-m-d')); ?> To : <?php echo e(Carbon::now()->format('Y-m-d')); ?> </h4>
          <div class="form-group row">
            <div class="col-sm-4 col-lg-4">
                <div class="card mb-2">
                    <div class="card-body text-center text-white bg-primary">
                        <div>
                            <h3><?php echo e(number_format($current_month_trainer_invoices)); ?></h3>
                            <div>Invoices</div>
                            <strong>( total net amount )</strong>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-4 col-lg-4">
                <div class="card mb-2 text-center text-white bg-success">
                    <div class="card-body">
                        <div>
                            <h3><?php echo e(number_format($current_month_trainer_payments_sum_amount)); ?></h3>
                            <div>Payments</div>
                            <strong>( total payments for invoices this month )</strong>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-4 col-lg-4">
                <div class="card mb-2 text-center text-white bg-warning">
                    <div class="card-body">
                        <div>
                            <h3><?php echo e(number_format($current_month_trainer_pending)); ?></h3>
                            <div>Pending</div>
                            <strong>( Pending amounts this month )</strong>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-4 col-lg-4">
                <div class="card mb-2 text-center text-white bg-success">
                    <div class="card-body">
                        <div>
                            <h3><?php echo e(number_format($current_month_trainer_payments)); ?></h3>
                            <div>All Payments</div>
                            <strong>( total payments collected this month )</strong>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-4 col-lg-4">
                <div class="card mb-2 text-center text-white bg-danger">
                    <div class="card-body">
                        <div>
                            <h3><?php echo e(number_format($current_month_trainer_refunds)); ?></h3>
                            <div>Refunds</div>
                            <strong>( total refunds this month )</strong>
                        </div>
                    </div>
                </div>
            </div>
          </div>
          

          
          <h4 style="padding:10px 0px ">Previous Month Trainer Report From : <?php echo e($startOfLastMonth); ?> To : <?php echo e($endOfLastMonth); ?> </h4>
          <div class="form-group row">
            <div class="col-sm-4 col-lg-4">
                <div class="card mb-2">
                    <div class="card-body text-center text-white bg-primary">
                        <div>
                            <h3><?php echo e(number_format($trainer_invoices)); ?></h3>
                            <div>Invoices</div>
                            <strong>( total net amount )</strong>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-4 col-lg-4">
                <div class="card mb-2 text-center text-white bg-success">
                    <div class="card-body">
                        <div>
                            <h3><?php echo e(number_format($trainer_payments_sum_amount)); ?></h3>
                            <div>Payments</div>
                            <strong>( total payments for invoices this month )</strong>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-4 col-lg-4">
                <div class="card mb-2 text-center text-white bg-warning">
                    <div class="card-body">
                        <div>
                            <h3><?php echo e(number_format($trainer_pending)); ?></h3>
                            <div>Pending</div>
                            <strong>( Pending amounts this month )</strong>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-4 col-lg-4">
                <div class="card mb-2 text-center text-white bg-success">
                    <div class="card-body">
                        <div>
                            <h3><?php echo e(number_format($trainer_payments)); ?></h3>
                            <div>All Payments</div>
                            <strong>( total payments collected this month )</strong>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-4 col-lg-4">
                <div class="card mb-2 text-center text-white bg-danger">
                    <div class="card-body">
                        <div>
                            <h3><?php echo e(number_format($trainer_refunds)); ?></h3>
                            <div>Refunds</div>
                            <strong>( total refunds this month )</strong>
                        </div>
                    </div>
                </div>
            </div>
          </div>
          
        </div>
    </div>

  
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Gym-System\resources\views/admin/reports/prev_month_report.blade.php ENDPATH**/ ?>