<?php $__env->startSection('content'); ?>
        <div class="form-group row">
            <div class="col-lg-9">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('membership_create')): ?>
                    <a class="btn btn-success" href="<?php echo e(route('admin.memberships.create')); ?>">
                        <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.membership.title_singular')); ?>

                    </a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('membership_filter')): ?>
                    <?php echo $__env->make('admin_includes.filters', [
                    'columns' => [
                        // 'id' => ['label' => 'ID', 'type' => 'number'],
                        'name'              => ['label' => 'Name', 'type' => 'text', 'related_to' => 'member'],
                        'phone'             => ['label' => 'Member Phone', 'type' => 'number', 'related_to' => 'member'],
                        'member_code'       => ['label' => 'Member Code', 'type' => 'text', 'related_to' => 'member'],
                        // 'email' => ['label' => 'Member Email', 'type' => 'email', 'related_to' => 'member.user'],
                        'member_id'         => ['label' => 'Member', 'type' => 'select', 'data' => $members],
                        'sales_by_id'       => ['label' => 'Sales By', 'type' => 'select', 'data' => $sales],
                        'trainer_id'        => ['label' => 'Trainer', 'type' => 'select', 'data' => $trainers],
                        'service_pricelist_id' => ['label' => 'Service', 'type' => 'select', 'data' => $services],
                        'service_type_id'   => ['label' => 'Service Type', 'type' => 'select', 'data' => $service_types,'related_to' => 'service_pricelist.service'],
                        'branch_id'         => ['label' => 'Branch', 'type' => 'select', 'data' => $branches,'related_to' => 'member'],
                        'gender'            => ['label' => trans('global.gender'), 'type' => 'text', 'related_to' => 'member'],
                        'status'            => ['label' => trans('global.status'), 'type' => 'select', 'data' => \App\Models\Membership::SELECT_STATUS],
                        'start_date'        => ['label' => trans('global.start_date'), 'type' => 'date', 'from_and_to' => true],
                        'end_date'          => ['label' => trans('global.end_date'), 'type' => 'date', 'from_and_to' => true],
                        'created_at'        => ['label' => 'Created at', 'type' => 'date', 'from_and_to' => true],
                    ],
                    'route' => 'admin.assigned-memberships'
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo $__env->make('csvImport.modal', ['model' => 'Membership', 'route' => 'admin.memberships.parseCsvImport'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('export_memberships')): ?>
                    <a href="<?php echo e(route('admin.memberships.export',request()->all())); ?>" class="btn btn-info">
                        <i class="fa fa-download"></i> <?php echo e(trans('global.export_excel')); ?>

                    </a>
                <?php endif; ?>

                <button type="button" data-toggle="modal" data-target="#sendReminder" class="btn btn-dark"><i
                        class="fa fa-plus-circle"></i> Reminder</button>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('membership_counter')): ?>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h2 class="text-center"><?php echo e(trans('cruds.membership.title')); ?></h2>
                            <h2 class="text-center" id="membershipsCounter"></h2>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    
    <div class="card">
        <div class="card-header">
            <?php echo e(trans('cruds.membership.title_singular')); ?> <?php echo e(trans('global.list')); ?>

        </div>

        <div class="card-body">
            
            <table class=" table table-bordered table-striped table-hover ajaxTable datatable datatable-Membership">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.membership.fields.id')); ?>

                        </th>
                        
                        <th>
                            <?php echo e(trans('cruds.membership.fields.member')); ?>

                        </th>
                        
                        <th>
                            <?php echo e(trans('global.gender')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.membership.fields.start_date')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.membership.fields.end_date')); ?>

                        </th>
                        <th>
                            Assigned Coach
                        </th>
                        <th>
                            <?php echo e(trans('cruds.membership.fields.service')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.branch.title_singular')); ?>

                        </th>
                        <?php if(config('domains')[config('app.url')]['sports_option'] == true): ?>
                        <th>
                            <?php echo e(trans('global.sport')); ?>

                        </th>
                        <?php endif; ?>
                        <th>
                            <?php echo e(trans('global.status')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.membership.fields.sales_by')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('global.remaining_sessions')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('global.last_attendance')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.membership.fields.created_at')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <script>
        $(function() {
            $("#lockers").css('display', 'none');
            let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
            // <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('membership_delete')): ?>
            //     let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>';
            //     let deleteButton = {
            //     text: deleteButtonTrans,
            //     url: "<?php echo e(route('admin.memberships.massDestroy')); ?>",
            //     className: 'btn-danger',
            //     action: function (e, dt, node, config) {
            //     var ids = $.map(dt.rows({ selected: true }).data(), function (entry) {
            //     return entry.id
            //     });
            
            //     if (ids.length === 0) {
            //     alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')
            
            //     return
            //     }
            
            //     if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
            //     $.ajax({
            //     headers: {'x-csrf-token': _token},
            //     method: 'POST',
            //     url: config.url,
            //     data: { ids: ids, _method: 'DELETE' }})
            //     .done(function () { location.reload() })
            //     }
            //     }
            //     }
            //     dtButtons.push(deleteButton)
            // <?php endif; ?>

            let dtOverrideGlobals = {
                buttons: dtButtons,
                processing: true,
                serverSide: true,
                retrieve: true,
                searching:true,
                aaSorting: [],
                ajax: "<?php echo e(route('admin.assigned-memberships', request()->all())); ?>",
                columns: [{
                        data: 'placeholder',
                        name: 'placeholder'
                    },
                    {
                        data: 'id',
                        name: 'id'
                    },
                    // {
                    //     data: 'member_code',
                    //     name: 'member_code'
                    // },
                    {
                        data: 'member_name',
                        name: 'member.member_code'
                    },
                    // {
                    //     data: 'member_phone',
                    //     name: 'member.phone'
                    // },
                    {
                        data: 'member_gender',
                        name: 'member.gender'
                    },
                    {
                        data: 'start_date',
                        name: 'start_date'
                    },
                    {
                        data: 'end_date',
                        name: 'end_date'
                    },
                    {
                        data: 'assigned_coach_name',
                        name: 'assigned_coach.name'
                    },
                    {
                        data: 'service_pricelist_name',
                        name: 'service_pricelist.name'
                    },
                    {
                        data: 'branch_name',
                        name: 'branch_name'
                    },
                    <?php if(config('domains')[config('app.url')]['sports_option'] == true): ?>
                    {
                        data: 'sport',
                        name: 'sport.name',
                        searchable: false
                    },
                    <?php endif; ?>
                    {
                        data: 'status',
                        name: 'status'
                    },
                    {
                        data: 'sales_by_name',
                        name: 'sales_by.name'
                    },
                    {
                        data: 'remaining_sessions',
                        name: 'remaining_sessions'
                    },
                    {
                        data: 'last_attendance',
                        name: 'last_attendance'
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                    {
                        data: 'actions',
                        name: '<?php echo e(trans('global.actions')); ?>'
                    }
                ],
                orderCellsTop: true,
                order: [
                    [1, 'desc']
                ],
                pageLength: 20,
            };
            let table = $('.datatable-Membership').DataTable(dtOverrideGlobals);
            $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e) {
                $($.fn.dataTable.tables(true)).DataTable()
                    .columns.adjust();
            });

            function getCount (){
                $("#membershipsCounter").text(table.ajax.json().recordsTotal);
            }

            setTimeout(getCount, 5000)

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\gymapp\resources\views/admin/memberships/assigned_memberships.blade.php ENDPATH**/ ?>