<div class="card reminderCard">
    <div class="card-header">
        <?php echo e(trans('cruds.reminder.title_singular')); ?>

    </div>
    <div class="card-body">
        <div class="row">
            
            <div class="col-md-6">
                <label for="due_date"><?php echo e(trans('global.due_date')); ?></label>
                <input type="date" class="form-control" name="due_date" id="due_date">
            </div>
        </div>
    </div>
</div><?php /**PATH E:\projects\gymapp\resources\views/partials/invoice_reminder.blade.php ENDPATH**/ ?>