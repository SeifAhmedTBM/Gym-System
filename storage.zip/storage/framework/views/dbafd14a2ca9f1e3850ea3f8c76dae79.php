<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route("admin.employees.update", [$employee->id])); ?>" enctype="multipart/form-data">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
    <div class="card">
        <div class="card-header">
            <h5><?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.employee.title_singular')); ?> | <b><?php echo e($employee->name); ?></b></h5>
        </div>
        <div class="card-body">
            <input type="hidden" name="employee_id" value="<?php echo e($employee->id); ?>">
            <?php if($employee->user_id != NULL): ?>
            <div class="alert alert-info font-weight-bold">
                <i class="fa fa-exclamation-circle"></i> 
                This employee has user with ID # <?php echo e($employee->user_id); ?> <a href="<?php echo e(route('admin.users.edit', $employee->user_id)); ?>" style="color:black !important;"> Click Here to update !</a>
            </div>
            <?php endif; ?>  

            <div class="form-row">
                <div class="col-md-4">
                    <div class="form-group">
                        <?php echo Form::label('name', trans('global.name'), ['class' => 'required']); ?>

                        <?php echo Form::text('name', $employee->name, ['class' => 'form-control', 'placeholder' => trans('global.name')]); ?>

                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <?php echo Form::label('phone', trans('global.phone'), ['class' => 'required']); ?>

                        <?php echo Form::number('phone', $employee->phone, ['class' => 'form-control', 'placeholder' => trans('global.phone')]); ?>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        <label class="required" for="salary"><?php echo e(trans('cruds.employee.fields.salary')); ?></label>
                        <input class="form-control <?php echo e($errors->has('salary') ? 'is-invalid' : ''); ?>" type="number" name="salary" id="salary" value="<?php echo e(old('salary', $employee->salary)); ?>" step="0.01" required>
                        <?php if($errors->has('salary')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('salary')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.employee.fields.salary_helper')); ?></span>
                    </div>
                </div>
            </div>

            <div class="form-row">
                <div class="col-md-4">
                    <div class="form-group">
                        <?php echo Form::label('national', trans('cruds.lead.fields.national')); ?>

                        <?php echo Form::number('national', $employee->national, ['class' => 'form-control', 'placeholder' => trans('cruds.lead.fields.national')]); ?>

                    </div>
                </div>
                <div class="col-md-4">
                    <label for="target_amount"><?php echo e(trans('global.target_amount')); ?></label>
                    <?php echo Form::number('target_amount', $employee->target_amount, ['class' => 'form-control', 'placeholder' => trans('global.target_amount')]); ?>

                </div>
                <div class="col-md-4">
                    <label for="branch_id"><?php echo e(trans('cruds.branch.title_singular')); ?></label>
                    <select name="branch_id" id="branch_id" class="form-control select2">
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e($employee->branch_id == $id ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-md-4">
                    <label for="vacations_balance"><?php echo e(trans('global.vacations_balance')); ?></label>
                    <?php echo Form::number('vacations_balance', old('vacation_balance',$employee->vacations_balance) ?? 0, ['class' => 'form-control', 'placeholder' => trans('global.vacations_balance')]); ?>

                </div>

                <div class="col-md-4">
                    <label for="access_card"><?php echo e(trans('global.access_card')); ?></label>
                    <?php echo Form::number('access_card', old('vacation_balance',$employee->access_card) ?? 0, ['class' => 'form-control', 'placeholder' => trans('global.access_card')]); ?>

                </div>
            </div>
        </div>
    </div>
   

<div class="card">
    <div class="card-body">
        <button type="submit" class="btn btn-primary">
            <i class="fa fa-check-circle"></i> <?php echo e(trans('global.save')); ?>

        </button>
    </div>
</div>

</form>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        function disableDayTime(checkBox) {
            let day_name = $(checkBox).data('day');
            if(checkBox.checked == true) {
                $("#from_"+day_name).val(' ');
                $("#from_"+day_name).attr('disabled', 'disabled');
                $("#to_"+day_name).val(' ');
                $("#to_"+day_name).attr('disabled', 'disabled');
            }else {
                $("#from_"+day_name).removeAttr('disabled');
                $("#to_"+day_name).removeAttr('disabled');
            }
        }

        function checkAttendance() {
            $(".switchMe").slideToggle();
        }

        function getScheduleDays(select) {
            let template_id = $(select).val();
            let url = "<?php echo e(route('admin.schedule-templates.get', ':id')); ?>";
            url = url.replace(':id', template_id);
            $.ajax({
                method : "GET",
                url : url,
                success: function(response) {
                    $(".appendDays").html('');
                    for(let i = 0 ; i < response.days.length ; i++) {
                        $(".appendDays").append(`
                        <tr>
                            <td>
                                <input type="hidden" name="days[]" value="${response.days[i].day}">
                                <b>${response.days[i].day} <span class="text-danger">*</span> </b><br>
                            </td>
                            <td>
                                <label class="c-switch c-switch-success shadow-none">
                                    <input type="checkbox" onchange="disableDayTime(this)" data-day="${response.days[i].day}" name="offday[${response.days[i].day}]" value="1" class="c-switch-input" ${response.days[i].is_offday == 1 ? 'checked' : ''}>
                                    <span class="c-switch-slider shadow-none"></span>
                                </label>
                            </td>
                            <td>
                                <input id="from_${response.days[i].day}" type="time" ${response.days[i].is_offday == 1 ? 'disabled' : ''} class="form-control" name="from[${response.days[i].day}]" value="${response.days[i].from}">
                            </td>
                            <td>
                                <input id="to_${response.days[i].day}" type="time" ${response.days[i].is_offday == 1 ? 'disabled' : ''}  class="form-control" name="to[${response.days[i].day}]" value="${response.days[i].to}">
                            </td>
                        </tr>
                        `);
                    }
                }
            })
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\gymapp\resources\views/admin/employees/edit.blade.php ENDPATH**/ ?>