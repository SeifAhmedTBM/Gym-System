<?php $__env->startSection('content'); ?>
<div class="from-group row">
    <div class="col-lg-4 col-md-2 col-sm-12">
        <div class="card">
            <div class="card-body">
                <h5 class="text-center">Total Salaries</h5>
                <h5 class="text-center"><?php echo e(number_format($payrolls->sum('basic_salary'))); ?></h5>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-md-2 col-sm-12">
        <div class="card">
            <div class="card-body">
                <h5 class="text-center">Total Bonuses</h5>
                <h5 class="text-center"><?php echo e(number_format($payrolls->sum('bonus'))); ?></h5>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-md-2 col-sm-12">
        <div class="card">
            <div class="card-body">
                <h5 class="text-center">Total Deductions</h5>
                <h5 class="text-center"><?php echo e(number_format($payrolls->sum('deduction'))); ?></h5>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-md-2 col-sm-12">
        <div class="card">
            <div class="card-body">
                <h5 class="text-center">Total Loans</h5>
                <h5 class="text-center"><?php echo e(number_format($payrolls->sum('loans'))); ?></h5>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-md-2 col-sm-12">
        <div class="card">
            <div class="card-body">
                <h5 class="text-center">Total Comissions</h5>
                <h5 class="text-center"><?php echo e(number_format($total_comissions)); ?></h5>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-md-2 col-sm-12">
        <div class="card">
            <div class="card-body">
                <h5 class="text-center">Total Net</h5>
                <h5 class="text-center"><?php echo e(number_format($payrolls->sum('net_salary'))); ?></h5>
            </div>
        </div>
    </div>
</div>
<div class="card">
    <div class="card-body">
        <form action="<?php echo e(route('admin.payroll.get')); ?>" method="get">
            <div class="row">
                <div class="col-md-12">
                    <label for="date"><?php echo e(trans('global.date')); ?></label>
                    <div class="input-group">
                        <input type="month" class="form-control" name="date" value="<?php echo e(request('date') ?? date('Y-m')); ?>">
                        <select name="branch_id" id="branch_id" class="form-control" <?php echo e($emp && $emp->branch_id != NULL ? 'readonly' : ''); ?>>
                            <option value="<?php echo e(NULL); ?>" selected hidden disabled>Branch</option>
                            <?php $__currentLoopData = \App\Models\Branch::pluck('name','id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e($branch_id == $id ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <select name="role_id" id="role_id" class="form-control">
                            <option value="<?php echo e(NULL); ?>" selected hidden disabled>Role</option>
                            <?php $__currentLoopData = \App\Models\Role::pluck('title','id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e(request('role_id') == $id ? 'selected' : ''); ?>><?php echo e($title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="input-group-prepend">
                            <button class="btn btn-primary" type="submit"><i class="fa fa-search"></i> <?php echo e(trans('global.submit')); ?></button>
                            <a href="<?php echo e(route('admin.payroll.export',request()->all())); ?>" class="btn btn-info">
                                <i class="fa fa-download"></i> <?php echo e(trans('global.export_excel')); ?>

                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header font-weight-bold">
        <div class="form-group row">
            <div class="col-md-3">
                <i class="fa fa-money-bill"></i> <?php echo e(trans('global.payroll')); ?>

            </div>
        </div>
    </div>
    <div class="card-body">
        <h4><?php echo e(trans('global.payroll')); ?> : 
            <span class="badge badge-success px-2 py-2">
                <?php echo e(request('date') ? request('date') : date('Y-m')); ?>

            </span>
        </h4>

        <form action="<?php echo e(route('admin.payroll.confirm_all',request()->all())); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group row">
                <div class="col-md-4 offset-md-6">
                    <label for="account_id" class="required">Account</label>
                    <select name="account_id" id="account_id" class="form-control" required>
                        <option value="<?php echo e(NULL); ?>"><?php echo e(trans('global.pleaseSelect')); ?></option>
                        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
        
                <div class="col-md-2">
                    <label><?php echo e(trans('global.confirm')); ?></label>
                    <button class="btn btn-dark btn-block float-right" type="submit">
                        <i class="fa fa-check"></i> Confirm All
                    </button>
                </div>
            </div>
        </form>
        
        <div class="table-responsive">
            <table class="table table-bordered table-outline text-center table-hover zero-configuration">
                <thead class="thead-light">
                    <tr>
                        <th class="text-dark"><?php echo e(trans('global.name')); ?></th>
                        <th class="text-dark"><?php echo e(trans('cruds.branch.title_singular')); ?></th>
                        <th class="text-dark"><?php echo e(trans('global.basic_salary')); ?></th>
                        <th class="text-dark"><?php echo e(trans('global.bonuses')); ?></th>
                        <th class="text-dark"><?php echo e(trans('global.all_deductions')); ?></th>
                        <th class="text-dark"><?php echo e(trans('cruds.loan.title')); ?></th>
                        <th class="text-dark">Fixed Comissions amount</th>
                        <th class="text-dark">Percentage Comissions amount</th>
                        <th class="text-dark">Total Comissions amount</th>
                        <th class="text-dark"><?php echo e(trans('global.net_salary')); ?></th>
                        <th class="text-dark">Confirmed</th>
                        <th class="text-dark"><?php echo e(trans('global.actions')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $payrolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="<?php echo e($payroll->status == 'confirmed' ? 'table-success' : ''); ?>">
                            <td class="font-weight-bold">
                                <i class="far fa-user"></i> <?php echo e($payroll->employee->name ?? '-'); ?><br>
                                <i class="fa fa-phone"></i> <?php echo e($payroll->employee->phone ?? '-'); ?><br>
                                <span class="badge badge-info px-2 py-2">
                                    <?php echo e($payroll->employee->user->roles[0]->title); ?>

                                </span>
                            </td>
                            <td><?php echo e($payroll->employee->branch->name ?? '-'); ?></td>
                            <td>
                                <?php echo e(number_format($payroll->basic_salary) . ' EGP'); ?>

                            </td>
                            <td>
                                <?php echo e(number_format($payroll->bonus) . ' EGP'); ?>

                            </td>
                            <td>
                                <?php echo e(number_format($payroll->deduction) . ' EGP'); ?>

                            </td>
                            <td>
                                <?php echo e(number_format($payroll->loans) . ' EGP'); ?>

                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.payroll.fixedComission', $payroll->id)); ?>" class="btn btn-sm btn-primary">
                                <?php echo e(number_format($payroll->fixed_comissions) . ' EGP'); ?>

                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.payroll.percentageComission', $payroll->id)); ?>" class="btn btn-sm btn-primary">
                                    <?php echo e(number_format($payroll->percentage_comissions) . ' EGP'); ?>

                                </a>
                            </td>
                            <td>
                                <?php echo e(number_format($payroll->fixed_comissions+$payroll->percentage_comissions) . ' EGP'); ?>

                            </td>
                            <td>
                                <?php echo e(number_format($payroll->net_salary) . ' EGP'); ?>

                            </td>
                            <td>
                                <?php echo $payroll->status == 'confirmed' ? '<i class="fa fa-check text-success"></i>' : '<i class="fa fa-times text-danger"></i>'; ?>

                            </td>
                            <td>
                                <div class="btn group">
                                    <a href="<?php echo e(route('admin.payroll.show', $payroll->id)); ?>" class="btn btn-sm btn-primary">
                                        <i class="fa fa-eye"></i> <?php echo e(trans('global.view')); ?>

                                    </a>
                                    <?php if($payroll->status == 'unconfirmed'): ?>
                                        <form action="<?php echo e(route('admin.payroll.status', $payroll->id)); ?>" method="POST"
                                            onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                            <input type="hidden" name="_method" value="PUT">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <button type="submit" class="btn btn-success btn-sm">
                                                <i class="fa fa-check-circle"></i> <?php echo e(trans('global.confirm')); ?>

                                            </button>
                                        </form>
                                    
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9"><?php echo e(trans('global.no_data_available')); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\gymapp\resources\views/admin/employees/payroll.blade.php ENDPATH**/ ?>