<?php $__env->startSection('content'); ?>
    
        <div class="row form-group">
            <div class="col-lg-6"> 
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment_filter')): ?>

                    <?php echo $__env->make('admin_includes.filters', [
                    'columns' => [
                        'invoice_id'    => ['label' => 'Invoice', 'type' => 'number'],
                        'account_id'    => ['label' => 'Account', 'type' => 'select' , 'data' => $accounts , 'related_to' => 'account'],
                        'branch_id'     => ['label' => 'Branch', 'type' => 'select', 'data' => $branches,'related_to' => 'account'],
                        'sales_by_id'   => ['label' => 'Sales By', 'type' => 'select' , 'data' => $sales_bies],
                        'created_at'    => ['label' => 'Created at', 'type' => 'date', 'from_and_to' => true]
                    ],
                        'route' => 'admin.payments.index'
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('csvImport.modal', ['model' => 'Payment', 'route' => 'admin.payments.parseCsvImport'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('export_payments')): ?>
                    <a href="<?php echo e(route('admin.payments.export',request()->all())); ?>" class="btn btn-info"><i class="fa fa-download">
                        </i> <?php echo e(trans('global.export_excel')); ?>

                    </a>
                <?php endif; ?>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment_counter')): ?>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h2 class="text-center"><?php echo e(trans('cruds.payment.title_singular')); ?></h2>
                            <h2 class="text-center"><?php echo e($payments->count()); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h2 class="text-center"><?php echo e(trans('cruds.payment.fields.amount')); ?></h2>
                            <h2 class="text-center"><?php echo e(number_format($payments->sum('amount')) ?? 0); ?></h2>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>

    
    <div class="card">
        <div class="card-header">
            <h5><?php echo e(trans('cruds.payment.title_singular')); ?> <?php echo e(trans('global.list')); ?></h5>
        </div>

        <div class="card-body">
            <table class=" table table-bordered table-striped table-hover ajaxTable datatable datatable-Payment">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.payment.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.payment.fields.invoice')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.member.title_singular')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.invoice.fields.account')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.branch.title_singular')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.service.title_singular')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.payment.fields.amount')); ?>

                        </th>
                        
                        <th>
                            <?php echo e(trans('cruds.status.title_singular')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('global.notes')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.payment.fields.sales_by')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.bonu.fields.created_by')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.payment.fields.created_at')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <script>
        $(function() {
            let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment_delete')): ?>
                let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>';
                let deleteButton = {
                text: deleteButtonTrans,
                url: "<?php echo e(route('admin.payments.massDestroy')); ?>",
                className: 'btn-danger',
                action: function (e, dt, node, config) {
                var ids = $.map(dt.rows({ selected: true }).data(), function (entry) {
                return entry.id
                });
            
                if (ids.length === 0) {
                alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')
            
                return
                }
            
                if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
                $.ajax({
                headers: {'x-csrf-token': _token},
                method: 'POST',
                url: config.url,
                data: { ids: ids, _method: 'DELETE' }})
                .done(function () { location.reload() })
                }
                }
                }
                dtButtons.push(deleteButton)
            <?php endif; ?>

            let dtOverrideGlobals = {
                buttons:[],
                processing: true,
                serverSide: true,
                retrieve: true,
                searching:true,
                aaSorting: [],
                ajax: "<?php echo e(route('admin.payments.index',request()->all())); ?>",
                columns: [{
                        data: 'placeholder',
                        name: 'placeholder'
                    },
                    {
                        data: 'id',
                        name: 'id'
                    },
                    {
                        data: 'invoice',
                        name: 'invoice'
                    },
                    {
                        data: 'member_name',
                        name: 'invoice.membership.member.member_code'
                    },
                    {
                        data: 'account',
                        name: 'account.name'
                    },
                    {
                        data: 'branch_name',
                        name: 'branch_name'
                    },
                    {
                        data: 'membership',
                        name: 'membership'
                    },
                    {
                        data: 'amount',
                        name: 'amount'
                    },
                    
                    {
                        data: 'status',
                        name: 'status'
                    },
                    {
                        data: 'notes',
                        name: 'notes'
                    },
                    {
                        data: 'sales_by_name',
                        name: 'sales_by.name'
                    },
                    {
                        data: 'created_by',
                        name: 'created_by.name'
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                    {
                        data: 'actions',
                        name: '<?php echo e(trans('global.actions')); ?>'
                    }
                ],
                orderCellsTop: true,
                order: [
                    [1, 'desc']
                ],
                pageLength: 50,
            };
            let table = $('.datatable-Payment').DataTable(dtOverrideGlobals);
            $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e) {
                $($.fn.dataTable.tables(true)).DataTable()
                    .columns.adjust();
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\gymapp\resources\views/admin/payments/index.blade.php ENDPATH**/ ?>