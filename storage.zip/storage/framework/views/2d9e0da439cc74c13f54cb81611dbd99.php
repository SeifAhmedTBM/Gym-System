
<h4><i class="fa fa-bell"></i> <?php echo e(trans('cruds.reminder.title')); ?></h4>
<div class="row">
    <div class="col-sm-6 col-lg-4">
        <a href="<?php echo e(route('admin.reports.reminders')); ?>" class="text-decoration-none">
            <div class="card ">
                <div class="card-body bg-info text-white text-center">
                    <h5 class="fs-4 fw-semibold"><?php echo e($today_reminders->count()); ?></h5>
                    <i class="fa fa-bell"></i>
                    <?php echo e(trans('global.today_reminders')); ?></h5>
                </div>
            </div>
        </a>
    </div>

    <div class="col-sm-6 col-lg-4">
        <a href="<?php echo e(route('admin.reports.reminders')); ?>" class="text-decoration-none">
            <div class="card ">
                <div class="card-body bg-info text-white text-center">
                    <h5 class="fs-4 fw-semibold"><?php echo e($upcomming_reminders->count()); ?></h5>
                    <i class="fa fa-bell"></i>
                    <?php echo e(trans('cruds.reminder.fields.upcomming_reminders')); ?></h5>
                </div>
            </div>
        </a>
    </div>

    <div class="col-sm-6 col-lg-4">
        <a href="<?php echo e(route('admin.reports.reminders')); ?>" class="text-decoration-none">
            <div class="card ">
                <div class="card-body bg-info text-white text-center">
                    <h5 class="fs-4 fw-semibold"><?php echo e($overdue_reminders->count()); ?></h5>
                    <i class="fa fa-bell"></i>
                    <?php echo e(trans('cruds.reminder.fields.overdue_remiders')); ?></h5>
                </div>
            </div>
        </a>
    </div>
</div>

<hr>

<h4><i class="fa fa-money"></i> <?php echo e(trans('global.monthly_sales')); ?></h4>
<div class="row">
    <div class="col-sm-6 col-lg-4">
        <a href="#" class="text-decoration-none">
            <div class="card ">
                <div class="card-body bg-success text-white text-center">
                    <h5 class="fs-4 fw-semibold"><?php echo e(number_format($invoices->sum('net_amount'))); ?></h5>
                    <i class="fa fa-bell"></i>
                    <?php echo e(trans('global.total_amount').' (Invoices) '); ?></h5>
                </div>
            </div>
        </a>
    </div>

    <div class="col-sm-6 col-lg-4">
        <a href="#" class="text-decoration-none">
            <div class="card ">
                <div class="card-body bg-primary text-white text-center">
                    <h5 class="fs-4 fw-semibold"><?php echo e(number_format($payments->sum('amount'))); ?></h5>
                    <i class="fa fa-bell"></i>
                    <?php echo e(trans('global.total_income').' (Payments) '); ?></h5>
                </div>
            </div>
        </a>
    </div>

    <div class="col-sm-6 col-lg-4">
        <a href="#" class="text-decoration-none">
            <div class="card ">
                <div class="card-body bg-warning text-white text-center">
                    <h5 class="fs-4 fw-semibold"><?php echo e(number_format($invoices->sum('rest'))); ?></h5>
                    <i class="fa fa-bell"></i>
                    <?php echo e(trans('global.pending').' ( Pending Payments this month)'); ?></h5>
                </div>
            </div>
        </a>
    </div>
</div>

<hr>
<h4><i class="fas fa-bullseye"></i> <?php echo e(trans('global.sales_achievements')); ?></h4>
<div class="row">
    <div class="col-sm-6 col-lg-4">
        <div class="card">
            <div class="card-body bg-success text-white text-center">
                <div>
                    <h5 class="fs-4 fw-semibold"><?php echo e(number_format($manager_target) . ' EGP'); ?></h5>
                    <h5> <?php echo e(trans('global.target')); ?></h5>
                </div>
            </div>
        </div>
    </div>

    

    <div class="col-sm-6 col-lg-4">
        <div class="card">
            <div class="card-body bg-primary text-white text-center">
                <div>
                    
                        <h5 class="fs-4 fw-semibold"> 
                            <?php echo e(number_format($manager_achieved) . ' EGP'); ?> (<?php echo e(number_format($manager_achieved_per,2)); ?>%)
                        </h5> 
                    
                    <h5><?php echo e(trans('global.achieved')); ?></h5>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-lg-4">
        <div class="card">
            <div class="card-body bg-warning text-white text-center">
                <div>
                    <h5 class="fs-4 fw-semibold"><?php echo e(number_format($manager_pending).' EGP' ?? 0); ?></h5>
                    <h5> <?php echo e(trans('global.pending')); ?></h5>
                </div>
            </div>
        </div>
    </div>
</div>


<hr>
<h4><i class="fas fa-bullseye"></i> <?php echo e(trans('global.total_transfered')); ?></h4>
<div class="row">
    <div class="col-sm-6 col-lg-4">
        <div class="card">
            <div class="card-body bg-success text-white text-center">
                <div>
                    <h5 class="fs-4 fw-semibold"> <?php echo e($all_leads->count()); ?></h5>
                    <h5><i class="fa fa-users"></i> <?php echo e(trans('global.total_leads')); ?></h5>
                </div>
            </div>
        </div>
    </div>

    

    <div class="col-sm-6 col-lg-4">
        <div class="card">
            <div class="card-body bg-primary text-white text-center">
                <div>
                    <h5 class="fs-4 fw-semibold"> <?php echo e($members->count() > 0 ? $members->count() .' ( '. number_format($members_per,1) .' ) %' : 0 .' %'); ?></h5>
                    <h5><i class="fa fa-check"></i> <?php echo e(trans('global.total_transfered')); ?></h5>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-lg-4">
        <div class="card">
            <div class="card-body bg-warning text-white text-center">
                <div>
                    <h5 class="fs-4 fw-semibold"><?php echo e($leads > 0 ? $leads .' ( '. number_format($leads_per,1) .' ) %' : 0 .' %'); ?></h5>
                    <h5> <i class="fa fa-spinner fa-spin"></i>  <?php echo e(trans('global.pending')); ?></h5>
                </div>
            </div>
        </div>
    </div>
</div>


<hr>

<div class="form-group">
    <div class="card">
        <div class="card-header">
            <?php echo e(Auth()->user()->employee && Auth()->user()->employee->branch ? Auth()->user()->employee->branch->name : ''); ?> Sources
        </div>
        <div class="card-body">
            <table class="table table-striped table-hover table-bordered zero-configuration">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Source</th>
                        <th>Leads</th>
                        <th>Members</th>
                        <th>Percentage</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($source->name); ?></td>
                            <td><?php echo e($source->leads_count); ?></td>
                            <td><?php echo e($source->members_count); ?></td>
                            <td><?php echo e($source->members_count > 0 ? number_format(($source->members_count / $source->leads_count) * 100,2).' %' : '0 %'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<div class="form-group">
    <div class="card">
        <div class="card-header">
            Reminders History
        </div>
        <div class="card-body">
            <table class="table table-striped table-hover table-bordered zero-configuration text-center">
                <thead class="thead-light">
                    <tr>
                        <th class="text-dark">#</th>
                        <th class="text-dark"><?php echo e(trans('global.name')); ?></th>
                        <?php $__currentLoopData = App\Models\LeadRemindersHistory::ACTION; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="text-dark"><?php echo e($value); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $reminder_sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reminder_sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="font-weight-bold"><?php echo e($loop->iteration); ?></td>
                            <td class="font-weight-bold"><?php echo e($reminder_sale->name ?? '-'); ?></td>
                            <?php $__currentLoopData = App\Models\LeadRemindersHistory::ACTION; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="font-weight-bold">
                                    <a href="<?php echo e(route('admin.remindersHistory.index',[
                                            'user_id'           => $reminder_sale->id,
                                            'action'            => $key,  
                                            'due_date[from]'    => date('Y-m-d')
                                        ])); ?>" target="_blank">
                                        <?php echo e($reminder_sale->reminders_histories()->whereDate('due_date',date('Y-m-d'))->whereAction($key)->count() ?? 0); ?>

                                    </a>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<div class="form-group">
    <div class="card">
        <div class="card-header">
            <?php echo e(Auth()->user()->employee && Auth()->user()->employee->branch ? Auth()->user()->employee->branch->name : ''); ?> Due Payments
        </div>
        <div class="card-body">
            <table class="table table-striped table-hover table-bordered zero-configuration text-center">
                <thead class="thead-light">
                    <tr>
                        <th class="text-dark">#</th>
                        <th class="text-dark"><?php echo e(trans('global.name')); ?></th>
                        <th class="text-dark"><?php echo e(trans('global.total')); ?></th>
                        <th class="text-dark"><?php echo e(trans('global.count')); ?></th>
                        <th class="text-dark"><?php echo e(trans('global.actions')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="font-weight-bold"><?php echo e($loop->iteration); ?></td>
                            <td class="font-weight-bold"><?php echo e($sale->name ?? '-'); ?></td>
                            <td class="font-weight-bold"><?php echo e(number_format($sale->invoices->sum('rest'))); ?> EGP</td>
                            <td class="font-weight-bold"><?php echo e($sale->invoices_count); ?></td>
                            <td class="font-weight-bold">
                                <a href="<?php echo e(route('admin.invoice.duePayments',$sale->id)); ?>" class="btn font-weight-bold btn-primary btn-sm">
                                    <i class="fa fa-eye"></i> <?php echo e(trans('cruds.invoice.title')); ?>

                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div class="card">
    <div class="card-header">
        <h5><i class="fa fa-file"></i> <?php echo e(trans('global.today_reminders')); ?></h5>
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered text-center table-striped table-hover zero-configuration">
                <thead class="thead-light">
                    <tr>
                        <th>#</th>
                        <th><?php echo e(trans('cruds.user.title_singular')); ?></th>
                        <th><?php echo e(trans('global.today_reminders')); ?></th>
                        <th><?php echo e(trans('global.branch')); ?></th>
                        <th><?php echo e(trans('global.pending')); ?></th>
                        <th><?php echo e(trans('global.action')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $sales_reminders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($sale->name); ?></td>
                            <td><?php echo e($sale->reminders_count + $sale->reminders_histories_count); ?></td>
                            <td><?php echo e($sale->employee->branch->name); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.reminders.index',[
                                        'user_id[]' => $sale->id,
                                        'due_date' => request('due_date') ?? date('Y-m-d')
                                    ])); ?>">
                                    <?php echo e($sale->reminders_count); ?>

                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.remindersHistory.index',['user_id[]' => $sale->id])); ?>">
                                    <?php echo e($sale->reminders_histories_count); ?>

                                </a>
                            </td>
                        </tr> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center"><?php echo e(trans('global.no_data_available')); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<hr>


<div class="card">
    <div class="card-header">
        <h5><i class="fa fa-file"></i> <?php echo e(trans('global.sales_report')); ?></h5>
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered text-center table-striped table-hover zero-configuration">
                <thead class="thead-light">
                    <tr>
                        <th>#</th>
                        <th><?php echo e(trans('global.name')); ?></th>
                        <th><?php echo e(trans('global.memberships')); ?></th>
                        <th><?php echo e(trans('global.target')); ?></th>
                        <th><?php echo e(trans('cruds.payment.title')); ?></th>
                        <th><?php echo e(trans('global.achieved')); ?></th>
                        <th><?php echo e(trans('global.commission')); ?> ( A )</th>
                        <th><?php echo e(trans('global.commission')); ?> ( % )</th>
                        <th><?php echo e(trans('global.actions')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($sale->name); ?></td>
                            <td><?php echo e($sale->memberships_count); ?></td>
                            <td><?php echo e(number_format($sale->employee->target_amount ?? 0)); ?> EGP</td>
                            <td>
                                <?php echo e(number_format($sale->payments->sum('amount')) ?? 0); ?> EGP (<?php echo e($sale->payments->count()); ?>)
                            </td>
                            <td>
                                <?php if(isset($sale->payments) && $sale->employee->target_amount > 0): ?>
                                    <?php if(isset($sale->sales_tier->sales_tier)): ?>
                                    <?php echo e(round(($sale->payments->sum('amount') / $sale->employee->target_amount) * 100)); ?>

                                        %
                                    <?php else: ?>
                                        <?php echo e(trans('global.there_is_no_sales_tier')); ?>

                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                
                                <?php if(isset($sale->payments)): ?>
                                    <?php if(isset($sale->sales_tier->sales_tier)): ?>
                                    <?php
                                        $sales_payments = $sale->payments->sum('amount');
                                        if ($sales_payments && $sale->employee->target_amount > 0) 
                                        {
                                            $achieved = ($sales_payments / $sale->employee->target_amount) *100;
                                            
                                            $sales_sales_tier_amount = ($sales_payments * $sale->sales_tier->sales_tier->sales_tiers_ranges()->where('range_from', '<=', $achieved)->orderBy('range_from','desc')->first()->commission) / 100;
                                        }
                                    ?>
                                    <?php echo e($sales_payments ? $sales_sales_tier_amount : 0); ?> EGP
                                    <?php else: ?>
                                        <?php echo e(trans('global.there_is_no_sales_tier')); ?>

                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(isset($sale->payments)): ?>
                                    <?php if(isset($sale->sales_tier->sales_tier)): ?>
                                        <?php
                                            $sales_payments = $sale->payments->sum('amount');
                                            if ($sales_payments && $sale->employee->target_amount > 0) 
                                            {
                                                $achieved = ($sales_payments / $sale->employee->target_amount) *100;
                                                $sales_sales_tier_commission = ($sale->sales_tier->sales_tier->sales_tiers_ranges()->where('range_from', '<=', $achieved)->orderBy('range_from','desc')->first()->commission ?? 0);
                                            }
                                            
                                        ?>
                                        <?php echo e($sales_payments ? $sales_sales_tier_commission  : 0); ?> %
                                    <?php else: ?>
                                        <?php echo e(trans('global.there_is_no_sales_tier')); ?>

                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.reports.sales-report.view',[$sale->id,'date='.request()->date])); ?>" class="btn btn-info btn-xs"><i class="fa fa-eye"></i> <?php echo e(trans('global.view')); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center"><?php echo e(trans('global.no_data_available')); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<hr>

<div class="row">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-header">
                <h5><i class="fa fa-file"></i> <?php echo e(trans('global.offers_report')); ?></h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered text-center table-striped table-hover zero-configuration">
                        <thead class="thead-light">
                            <tr>
                                <th>#</th>
                                <th class="text-dark"><?php echo e(trans('cruds.service.fields.name')); ?></th>
                                <th class="text-dark"><?php echo e(trans('global.count')); ?></th>
                                <th class="text-dark"><?php echo e(trans('global.amount')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($key); ?></td>
                                    <td><?php echo e($offer->count()); ?></td>
                                    <td><?php echo e(number_format($offer->sum('amount'))); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                Chart
            </div>
            <div class="card-body">
                <canvas id="myChart" width="400" height="400"></canvas>
            </div>
        </div>
    </div>
</div>

    <?php if($latest_leads->isNotEmpty()): ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="nav nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                            <?php $__currentLoopData = $latest_leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="nav-link <?php echo e($loop->iteration == 1 ? 'active' : ''); ?>"
                                    id="<?php echo e(str_replace(' ', '_', $key)); ?>-tab" data-toggle="pill"
                                    href="#<?php echo e(str_replace(' ', '_', $key)); ?>" role="tab"
                                    aria-controls="<?php echo e(str_replace(' ', '_', $key)); ?>" aria-selected="true">
                                    <?php echo e($key); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="tab-content" id="v-pills-tabContent">
                            <?php $__currentLoopData = $latest_leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tab-pane fade <?php echo e($loop->iteration == 1 ? 'show active' : ''); ?>"
                                    id="<?php echo e(str_replace(' ', '_', $key)); ?>" role="tabpanel"
                                    aria-labelledby="<?php echo e($key); ?>-tab">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <table
                                                class="table table-bordered table-striped table-hover zero-configuration">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Name</th>
                                                        <th>Type</th>
                                                        <th>Sales By</th>
                                                        <th>Source</th>
                                                        <th>Membership</th>
                                                        <th>Paid</th>
                                                        <th>Rest</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <tr>
                                                            <td><?php echo e($loop->iteration); ?></td>
                                                            <td>
                                                                <a href="<?php echo e($lead->type == 'member' ? route('admin.members.show', $lead->id) : route('admin.leads.show', $lead->id)); ?>"
                                                                    target="_blank">
                                                                    <?php echo e($lead->last_membership ? App\Models\Setting::first()->member_prefix . $lead->member_code : ' '); ?>

                                                                    <br>
                                                                    <?php echo e($lead->name); ?> <br>
                                                                    <?php echo e($lead->phone); ?> <br>
                                                                </a>
                                                            </td>
                                                            <td><?php echo e($lead->type); ?></td>
                                                            <td>
                                                                <?php echo e($lead->sales_by->name ?? '-'); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e($lead->source->name ?? '-'); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e($lead->last_membership->service_pricelist->name ?? '-'); ?>

                                                                <br>
                                                                <?php echo e($lead->last_membership ? number_format($lead->last_membership->invoice->net_amount) : ' '); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e($lead->last_membership ? number_format($lead->last_membership->invoice->payments->sum('amount')) : 0); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e($lead->last_membership ? number_format($lead->last_membership->invoice->rest) : '-'); ?>

                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        NOT FOUND 2
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    
    const ctx = document.getElementById('myChart').getContext('2d');
    const myChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: [
                <?php 
                    foreach($offers as $key => $offer){
                        echo "'".$key."'" . ',';
                    }
                ?>
            ],
            datasets: [{
                label: '# of Votes',
                data: [<?php 
                    foreach($offers as $key => $offer){
                        echo "'".$offer->sum('amount')."'" . ',';
                    }
                ?>],
                
                backgroundColor: [
                    
                    <?php 
                    function random_color_part() {
                        return str_pad( dechex( mt_rand( 0, 255 ) ), 2, '0', STR_PAD_LEFT);
                    }

                    function random_color() {
                        return random_color_part() . random_color_part() . random_color_part();
                    }

                    foreach($offers as $key => $offer){
                           echo "'#" . random_color() . "',";
                        }
                    ?>
                ],
                
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script><?php /**PATH E:\projects\gymapp\resources\views/dashboard/sales_manager.blade.php ENDPATH**/ ?>