
<?php $__env->startSection('content'); ?>
    <div class="card shadow-sm">
        <div class="card-header font-weight-bold bg-default text-white">
            <i class="fa fa-calendar"></i> <?php echo e(trans('global.calendar')); ?>

        </div>
        <div class="card-body pb-3">
            <div class="row">
                <div class="col-md-6">
                    <h4 class="datee font-weight-bold"></h4>
                </div>
                <div class="col-md-6">
                    <div class="digital-time text-success">
                        <h4 class="font-weight-bold hours">00</h4>
                        <h4>:</h4>
                        <h4 class="font-weight-bold minutes">00</h4>
                        <h4>:</h4>
                        <h4 class="font-weight-bold seconds">00</h4>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <?php switch(auth()->user()->roles[0]->title):
        case ('Super Admin'): ?>
            <?php echo $__env->make('dashboard.super_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('Partner'): ?>
            <?php echo $__env->make('dashboard.super_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('Admin'): ?>
            <?php echo $__env->make('dashboard.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('Developer'): ?>
            <?php echo $__env->make('dashboard.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('Accountant'): ?>
            <?php echo $__env->make('dashboard.accountant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('Sales'): ?>
            <?php echo $__env->make('dashboard.sales', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('Trainer'): ?>
            <?php echo $__env->make('dashboard.trainer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('Receptionist'): ?>
            <?php echo $__env->make('dashboard.receptionist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('Super Visor'): ?>
            <?php echo $__env->make('dashboard.supervisor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        
        <?php case ('Sales manager'): ?>
            <?php echo $__env->make('dashboard.sales_manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('Sales Director'): ?>
            <?php echo $__env->make('dashboard.sales_director', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('Fitness Manager'): ?>
            <?php echo $__env->make('admin.memberships.assign_coach', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('dashboard.fitnessManager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php default: ?>
            <?php echo $__env->make('dashboard.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endswitch; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        setInterval(setDigitalClock, 1000);

        function setDigitalClock() {
            const today = new Date();
            const timeOptions = {
                minimumIntegerDigits: 2,
                useGrouping: false,
            };
            const dateOptions = {
                weekday: 'long',
                month: 'long',
                day: 'numeric',
                year: 'numeric'
            };

            let getSeconds = today.getSeconds().toLocaleString("en-US", timeOptions);
            let getMinutes = today.getMinutes().toLocaleString("en-US", timeOptions);
            let getHours = today.getHours().toLocaleString("en-US", timeOptions);

            let getDate = today.toLocaleDateString("en-US", dateOptions);

            if (getHours > 12) {
                getHours = (getHours - 12).toLocaleString("en-US", timeOptions);;
            }

            const seconds = document.querySelector(".seconds");
            const minutes = document.querySelector(".minutes");
            const hours = document.querySelector(".hours");
            const date = document.querySelector(".datee");

            setTime(seconds, getSeconds);
            setTime(minutes, getMinutes);
            setTime(hours, getHours);
            setTime(date, getDate);
        }

        function setTime(element, operator) {
            element.innerHTML = operator;
        }
        setDigitalClock();
    </script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Gym-System\resources\views/home.blade.php ENDPATH**/ ?>