
<?php $__env->startSection('content'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_create')): ?>
        <div style="margin-bottom: 10px;" class="row">
            <div class="col-lg-12">
                <a class="btn btn-success" href="<?php echo e(route('admin.tasks.create')); ?>">
                    <?php echo e(trans('global.add')); ?> Task
                </a>
            </div>
        </div>
    <?php endif; ?>
    <div class="card">
        <form method="get" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="form-group col-lg-4" style="padding:50px;">
                    <div class="row">
                    <label for="" ><?php echo e(trans('global.employee')); ?></label>
                    <div class="col-lg-10">
                        <select name="employee_id" class="form-control select2" id="">
                            <option value="" selected><?php echo e(trans('global.select_employee')); ?></option> 
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(isset($tasks[0])): ?>
                            <option value="<?php echo e($employee->user_id); ?>" <?php echo e($tasks[0]->to_user_id == $employee->user_id ? 'selected' : ' '); ?>><?php echo e($employee->name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($employee->user_id); ?>" ><?php echo e($employee->name); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-lg-2">
                    <button type="submit" class="btn btn-primary"><?php echo e(trans('global.submit')); ?></button>

                    </div>
                    </div>
                    
                </div>
             
            </div>
           
        </form>
        <div class="card-header">
            <h5>Tasks<?php echo e(trans('global.list')); ?></h5>
        </div>

        <div class="card-body">
            <table class=" table table-bordered table-striped table-hover ajaxTable datatable datatable-Task">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.source.fields.id')); ?>

                        </th>
                        <th>
                            Title
                        </th>
                        <th>
                            Description
                        </th>
                        <th>
                            Created By
                        </th>
                        <th>
                            To User
                        </th>
                        <th>
                            To Role
                        </th>
                        <th>
                            Status
                        </th>
                        <th>
                            Task Date
                        </th>
                        <th>
                            Supervisor
                        </th>
                        <th>
                            Done At
                        </th>
                        <th>
                            Confirmation At
                        </th>

                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <script>
        $(function() {
            let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
          

            const urlParams = new URLSearchParams(window.location.search);
            const emp_id = urlParams.get('employee_id') ?? '';
            let dtOverrideGlobals = {
            buttons: [dtButtons],
            processing: true,
            serverSide: true,
            retrieve: true,
            searching: true,
            aaSorting: [],
            ajax: "<?php echo e(route('admin.tasks.index')); ?>?employee_id="+emp_id,
                columns: [{
                        data: 'placeholder',
                        name: 'placeholder'
                    },
                    {
                        data: 'id',
                        name: 'id'
                    },
                    {
                        data: 'title',
                        name: 'title'
                    },
                    {
                        data: 'description',
                        name: 'description'
                    },
                    {
                        data: 'created_by',
                        name: 'created_by'
                    },
                    {
                        data: 'to_user',
                        name: 'to_user'
                    },
                    {
                        data: 'to_role',
                        name: 'to_role'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                    {
                        data: 'task_date',
                        name: 'task_date'
                    },
                    {
                        data: 'supervisor_name',
                        name: 'supervisor_name'
                    },
                    {
                        data: 'done_at',
                        name: 'done_at'
                    },
                    {
                        data: 'confirmation_at',
                        name: 'confirmation_at'
                    },
                    {
                        data: 'actions',
                        name: '<?php echo e(trans('global.actions')); ?>'
                    }
                ],
                orderCellsTop: true,
                order: [
                    [1, 'desc']
                ],
                pageLength: 50,
            };
            let table = $('.datatable-Task').DataTable(dtOverrideGlobals);
            $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e) {
                $($.fn.dataTable.tables(true)).DataTable()
                    .columns.adjust();
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Gym-System\resources\views/admin/tasks/index.blade.php ENDPATH**/ ?>