<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h5><?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.lead.title_singular')); ?></h5>
        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.leads.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <?php if(config('domains')[config('app.url')]['minor'] == true): ?>
                    <div class="row form-group">
                        <div class="col-md-2">
                            <?php echo e(trans('global.minor')); ?>

                        </div>
                        <div class="col-md-1 text-right">
                            <label class="c-switch c-switch-3d c-switch-success">
                                <input type="checkbox" name="minor" id="minor" value="yes" class="c-switch-input">
                                <span class="c-switch-slider shadow-none"></span>
                            </label>
                        </div>
                    </div>

                    <div class="row form-group" id="parent" style="display: none">
                        <div class="col-md-3">
                            <label for=""><?php echo e(trans('global.parent_phone')); ?></label>
                            <input type="text" class="form-control" name="parent_phone"
                                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                        </div>
                        <div class="col-md-3">
                            <label for=""><?php echo e(trans('global.parent_phone')); ?> 2</label>
                            <input type="text" class="form-control" name="parent_phone_two"
                                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                        </div>
                        <div class="col-md-6">
                            <label for=""><?php echo e(trans('global.parent_details')); ?></label>
                            <input type="text" class="form-control" name="parent_details">
                        </div>
                    </div>
                <?php endif; ?>

                <div class="row form-group">
                    <div class="col-md-3">
                        <label class="required" for="name"><?php echo e(trans('cruds.lead.fields.name')); ?></label>
                        <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text"
                            name="name" id="name" value="<?php echo e(old('name', '')); ?>" required>
                        <?php if($errors->has('name')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('name')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.lead.fields.name_helper')); ?></span>
                    </div>
                    <div class="col-md-3">
                        <label class="required" for="phone"><?php echo e(trans('cruds.lead.fields.phone')); ?></label>
                        <input class="form-control <?php echo e($errors->has('phone') ? 'is-invalid' : ''); ?>" type="text"
                            name="phone" id="phone" value="<?php echo e(old('phone', '')); ?>" required
                            oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"
                            min="11" max="11">
                        <?php if($errors->has('phone')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('phone')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.lead.fields.phone_helper')); ?></span>
                    </div>

                    <div class="col-md-3">
                        <label class="required" for="branch">Branch</label>
                        <select name="branch_id" id="branch_id"
                            class="form-control <?php echo e($errors->has('branch_id') ? 'is-invalid' : ''); ?>"
                            <?php echo e(is_null($selectedBranch) ? '' : 'disabled'); ?> required>
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e($selectedBranch == $id ? 'selected' : ''); ?>>
                                    <?php echo e($entry); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('branch_id')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('branch_id')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.lead.fields.address_helper')); ?></span>
                    </div>

                    <div class="col-md-3">
                        <label for="address"><?php echo e(trans('cruds.lead.fields.address')); ?></label>
                        <select name="address_id" id="address_id"
                            class="form-control select2 <?php echo e($errors->has('address_id') ? 'is-invalid' : ''); ?>">
                            <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e(old('address_id') == $id ? 'selected' : ''); ?>>
                                    <?php echo e($entry); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('address_id')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('address')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.lead.fields.address_helper')); ?></span>
                    </div>
                </div>

                <div class="row form-group">
                    <div class="col-md-3">
                        <label for="referral_member"><?php echo e(trans('cruds.lead.fields.referral_member')); ?></label>
                        <input type="text" class="form-control"
                            placeholder="<?php echo e(trans('cruds.lead.fields.referral_member')); ?>" name="referral_member"
                            id="referral_member" onblur="referralMember()">
                        <small class="text-danger" id="referral_member_msg"></small>
                    </div>

                    <div class="col-md-3">
                        <label for="national"
                            class="<?php echo e(config('domains')[config('app.url')]['national_id'] == true ? 'required' : ''); ?>"><?php echo e(trans('cruds.lead.fields.national')); ?></label>
                        <input class="form-control <?php echo e($errors->has('national') ? 'is-invalid' : ''); ?>" type="text"
                            name="national" id="national" value="<?php echo e(old('national')); ?>"
                            oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"
                            <?php echo e(config('domains')[config('app.url')]['national_id'] == true ? 'min="14" max="14" required' : ''); ?>>
                        <?php if($errors->has('national')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('national')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.lead.fields.national_helper')); ?></span>
                    </div>

                    <div class="col-md-3">
                        <label class="required" for="source_id"><?php echo e(trans('cruds.lead.fields.source')); ?></label>
                        <select class="form-control select2 <?php echo e($errors->has('source') ? 'is-invalid' : ''); ?>"
                            name="source_id" id="source_id" required>
                            <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e(old('source_id') == $id ? 'selected' : ''); ?>>
                                    <?php echo e($entry); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('source')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('source')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.lead.fields.source_helper')); ?></span>
                    </div>

                    <div class="col-md-3">
                        <label for="dob"><?php echo e(trans('cruds.lead.fields.dob')); ?></label>
                        <input class="form-control <?php echo e($errors->has('dob') ? 'is-invalid' : ''); ?>" type="date"
                            name="dob" id="dob" value="<?php echo e(old('dob') ?? date('1990-01-01')); ?>"
                            max="<?php echo e(date('Y-m-d')); ?>">
                        <?php if($errors->has('dob')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('dob')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.lead.fields.dob_helper')); ?></span>
                    </div>

                </div>

                <div class="row form-group">
                    <div class="col-md-3">
                        <label for="whatsapp_number"><?php echo e(trans('global.whatsapp')); ?></label>
                        <input class="form-control <?php echo e($errors->has('whatsapp_number') ? 'is-invalid' : ''); ?>"
                            type="text" name="whatsapp_number" id="whatsapp_number"
                            value="<?php echo e(old('whatsapp_number')); ?>"
                            oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                        <?php if($errors->has('whatsapp_number')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('whatsapp_number')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-3">
                        <label class="required"><?php echo e(trans('cruds.lead.fields.gender')); ?></label>
                        <select class="form-control <?php echo e($errors->has('gender') ? 'is-invalid' : ''); ?>" name="gender"
                            id="gender" required>
                            <option value disabled <?php echo e(old('gender', null) === null ? 'selected' : ''); ?>>
                                <?php echo e(trans('global.pleaseSelect')); ?></option>
                            <?php $__currentLoopData = App\Models\Lead::GENDER_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"
                                    <?php echo e(old('gender', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('gender')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('gender')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.lead.fields.gender_helper')); ?></span>
                    </div>

                    <?php if(config('domains')[config('app.url')]['sports_option'] == true): ?>
                        <div class="col-md-3">
                            <label><?php echo e(trans('global.sport')); ?></label>
                            <select name="sport_id" id="sport_id" class="form-control select2">
                                <option value="<?php echo e(null); ?>" selected hidden><?php echo e(trans('global.pleaseSelect')); ?>

                                </option>
                                <?php $__currentLoopData = $sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e(old('sport_id') == $id ? 'selected' : ''); ?>>
                                        <?php echo e($name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('sport_id')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('sport_id')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.lead.fields.followup_helper')); ?></span>
                        </div>
                    <?php endif; ?>

                    <div class="col-md-3">
                        <label class="required"><?php echo e(trans('cruds.lead.fields.followup')); ?></label>
                        <input class="form-control date <?php echo e($errors->has('followup') ? 'is-invalid' : ''); ?>"
                            type="text" name="followup" id="followup"
                            value="<?php echo e(old('followup') ?? date('Y-m-d')); ?>" required>
                        <?php if($errors->has('followup')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('followup')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.lead.fields.followup_helper')); ?></span>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label class="required" for="sales_by_id"><?php echo e(trans('cruds.lead.fields.sales_by')); ?></label>
                        <select class="form-control select2 <?php echo e($errors->has('sales_by') ? 'is-invalid' : ''); ?>"
                            name="sales_by_id" id="sales_by_id" required>
                            <?php $__currentLoopData = $sales_bies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e(old('sales_by_id') == $id ? 'selected' : ''); ?>>
                                    <?php echo e($entry); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('sales_by')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('sales_by')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.lead.fields.sales_by_helper')); ?></span>
                    </div>

                    <div class="col-md-2 mt-4">
                        <h5>Invitation</h5>
                    </div>
                    <div class="col-md-1">
                        <label class="c-switch c-switch-3d c-switch-success my-4">
                            <input type="checkbox" name="invitation" id="invitation" value="true"
                                class="c-switch-input">
                            <span class="c-switch-slider shadow-none"></span>
                        </label>
                    </div>

                    <div class="col-md-3" id="trainer_div" style="display:none">
                        <label for="trainer_id" class="required">Coach</label>
                        <select name="trainer_id" id="trainer_id" class="form-control select2">
                            <?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e(old('trainer_id') == $id ? 'selected' : ''); ?>>
                                    <?php echo e($name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-6">
                        <label for="address_details"><?php echo e(trans('cruds.lead.fields.address_details')); ?></label>
                        <textarea class="form-control <?php echo e($errors->has('address_details') ? 'is-invalid' : ''); ?>" name="address_details"
                            id="address_details"><?php echo e(old('address_details')); ?></textarea>
                        <?php if($errors->has('address_details')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('address_details')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.lead.fields.address_details_helper')); ?></span>
                    </div>
                    <div class="col-md-6">
                        <label for="notes"><?php echo e(trans('cruds.lead.fields.notes')); ?></label>
                        <textarea class="form-control <?php echo e($errors->has('notes') ? 'is-invalid' : ''); ?>" name="notes" id="notes"><?php echo e(old('notes')); ?></textarea>
                        <?php if($errors->has('notes')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('notes')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.lead.fields.notes_helper')); ?></span>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-12">
                        <label for="medical_background"><?php echo e(trans('cruds.lead.fields.medical_background')); ?></label>
                        <textarea class="form-control <?php echo e($errors->has('medical_background') ? 'is-invalid' : ''); ?>"
                            name="medical_background" id="medical_background" rows="3"><?php echo e(old('medical_background')); ?></textarea>
                        <?php if($errors->has('medical_background')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('medical_background')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.lead.fields.medical_background_helper')); ?></span>
                    </div>
                </div>
                <div class="form-group">
                    <button class="btn btn-danger" type="submit">
                        <?php echo e(trans('global.save')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        Dropzone.options.photoDropzone = {
            url: '<?php echo e(route('admin.leads.storeMedia')); ?>',
            maxFilesize: 5, // MB
            acceptedFiles: '.jpeg,.jpg,.png,.gif',
            maxFiles: 1,
            addRemoveLinks: true,
            headers: {
                'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
            },
            params: {
                size: 5,
                width: 4096,
                height: 4096
            },
            success: function(file, response) {
                $('form').find('input[name="photo"]').remove()
                $('form').append('<input type="hidden" name="photo" value="' + response.name + '">')
            },
            removedfile: function(file) {
                file.previewElement.remove()
                if (file.status !== 'error') {
                    $('form').find('input[name="photo"]').remove()
                    this.options.maxFiles = this.options.maxFiles + 1
                }
            },
            init: function() {
                <?php if(isset($lead) && $lead->photo): ?>
                    var file = <?php echo json_encode($lead->photo); ?>

                    this.options.addedfile.call(this, file)
                    this.options.thumbnail.call(this, file, file.preview)
                    file.previewElement.classList.add('dz-complete')
                    $('form').append('<input type="hidden" name="photo" value="' + file.file_name + '">')
                    this.options.maxFiles = this.options.maxFiles - 1
                <?php endif; ?>
            },
            error: function(file, response) {
                if ($.type(response) === 'string') {
                    var message = response //dropzone sends it's own error messages in string
                } else {
                    var message = response.errors.file
                }
                file.previewElement.classList.add('dz-error')
                _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
                _results = []
                for (_i = 0, _len = _ref.length; _i < _len; _i++) {
                    node = _ref[_i]
                    _results.push(node.textContent = message)
                }

                return _results
            }
        }
    </script>

    <script>
        function getStatus() {
            var status_id = $('#status_id').val();
            var url = "<?php echo e(route('admin.getStatus', [':id', ':date'])); ?>",
                url = url.replace(':id', status_id);
            url = url.replace(':date', "<?php echo e(date('Y-m-d')); ?>");

            $.ajax({
                method: 'GET',
                url: url,
                success: function(response) {
                    $('#followup').val(response.followup_date);
                }
            });
        }

        function referralMember() {
            var referral_member = $('#referral_member').val();
            var url = "<?php echo e(route('admin.referralMember')); ?>";
            $.ajax({
                method: 'POST',
                url: url,
                _token: $('meta[name="csrf-token"]').attr('content'),
                data: {
                    referral_member: referral_member,
                    _token: _token
                },
                success: function(data) {
                    $('#referral_member').attr('readonly', true);
                    $('#referral_member_msg').text(data.member.name);
                },
                error: function(error) {
                    $('#referral_member').attr('readonly', false);
                    $('#referral_member_msg').text("<?php echo e(trans('global.member_is_not_found')); ?>");
                },
            })
        }

        $("#minor").change(function() {
            if (this.checked == true) {
                $(".hideMe").slideDown();
                $('#parent').slideDown();
                $('#phone').attr('disabled', true);
                $('#national').attr('disabled', true);
            } else {
                $(".hideMe").slideUp();
                $('#parent').slideUp();
                $('#phone').attr('disabled', false);
                $('#national').attr('disabled', false);
            }
        });

        $("#invitation").change(function() {
            if (this.checked == true) {
                $("#trainer_div").slideDown();
            } else {
                $("#trainer_div").slideUp();
            }
        });

        $('#phone').on('keyup', function() {
            if ($('#phone').val().length == 11) {
                $('#phone').removeClass('is-invalid').addClass('is-valid');
            } else {
                $('#phone').removeClass('is-valid').addClass('is-invalid');
            }
        })
    </script>

    <?php if(config('domains')[config('app.url')]['national_id'] == true): ?>
        <script>
            $('#national').on('keyup', function() {
                if ($('#national').val().length == 14) {
                    $('#national').removeClass('is-invalid').addClass('is-valid');
                } else {
                    $('#national').removeClass('is-valid').addClass('is-invalid');
                }
            })
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\gymapp\resources\views/admin/leads/create.blade.php ENDPATH**/ ?>