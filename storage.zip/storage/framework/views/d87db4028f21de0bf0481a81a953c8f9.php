<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 text-right">
        <button class="btn btn-primary mb-2" type="button" data-toggle="modal" data-target="#sendSMSModal">
            <i class="fa fa-paper-plane"></i> <?php echo e(trans('global.send_sms')); ?>

        </button>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header">
        <h5><i class="fa fa-comments"></i> <?php echo e(trans('global.send_sms')); ?></h5>
    </div>
    <div class="card-body">
        <table class="table text-center shadow-sm table-bordered table-hover table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th><?php echo e(trans('global.message')); ?></th>
                    <th><?php echo e(trans('global.sent_by')); ?></th>
                    <th><?php echo e(trans('global.created_at')); ?></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $sms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($msg->message); ?></td>
                    <td><?php echo e($msg->user->name); ?></td>
                    <td><?php echo e($msg->created_at->toFormattedDateString()); ?></td>
                    <td>

                        <a href="<?php echo e(route('admin.marketing.sms.show', $msg->id)); ?>" class="btn btn-sm btn-primary">
                            <i class="fa fa-eye"></i> <?php echo e(trans('global.view')); ?>

                        </a>
                        <button data-toggle="modal" data-target="#deleteModal" data-id="<?php echo e($msg->id); ?>" onclick="deleteRecord(this)" class="btn btn-sm btn-danger">
                            <i class="fa fa-trash"></i> <?php echo e(trans('global.delete')); ?>

                        </button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5"><?php echo e(trans('global.no_data_available')); ?></td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <?php echo e($sms->links()); ?>

    </div>
</div>
<?php echo $__env->make('admin.marketing.sms.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        // The DOM element you wish to replace with Tagify
        var input = document.querySelector('#numbers');
        // initialize Tagify on the above input node reference
        new Tagify(input)

        function deleteRecord(button) {
            let wp_id = $(button).data('id');
            let url = "<?php echo e(route('admin.marketing.sms.destroy', ':id')); ?>";
            url = url.replace(':id', wp_id);
            $("#delete_form").attr('action', url);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\gymapp\resources\views/admin/marketing/sms/index.blade.php ENDPATH**/ ?>