
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <?php echo e(trans('global.attendance_data')); ?> | <?php echo e(Auth()->user()->employee && Auth()->user()->employee->branch_id ? Auth()->user()->employee->branch->name : ''); ?>

            </div>
            <div class="card-body">
                <?php if(Session::has('user_invalid')): ?>
                    <div class="alert alert-danger font-weight-bold text-center">
                       <i class="fa fa-user-times"></i> <?php echo e(session('user_invalid')); ?>

                    </div>
                <?php endif; ?>
                <?php if(\App\Models\Setting::first()->has_lockers): ?>
                    <div class="row form-group">
                        <div class="col-12">
                            <label for=""><?php echo e(trans('global.take_attendance')); ?></label>
                            <input type="hidden" name="membership_id" >
                            <input type="hidden" name="member_id" >
                            <input type="hidden" name="branch_id" value="<?php echo e(Auth()->user()->employee && Auth()->user()->employee->branch_id ? Auth()->user()->employee->branch_id : NULL); ?>">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <select name="member_branch_id" id="member_branch_id" class="form-control">
                                        <?php $__currentLoopData = \App\Models\Branch::pluck('member_prefix','id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($id); ?>" <?php echo e(Auth()->user()->employee &&  Auth()->user()->employee->branch_id == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <input type="text" class="form-control" name="card_number" value="" id="member_code" autofocus ondragenter="getMember()" onfocus="this.setSelectionRange(this.value.length,this.value.length);">
                            </div>
                        </div>
                    </div>
                    <br>

                <?php else: ?>
                    <form action="<?php echo e(route('admin.take.attend')); ?>" method="post" id="memberAttendanceForm">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="row form-group">
                            <div class="col-12">
                                <label for=""><?php echo e(trans('global.take_attendance')); ?></label>
                                <input type="hidden" name="membership_id" value="">
                                <input type="hidden" name="member_id" value="">
                                <input type="hidden" name="branch_id" value="<?php echo e(Auth()->user()->employee && Auth()->user()->employee->branch_id ? Auth()->user()->employee->branch_id : NULL); ?>">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <select name="member_branch_id" id="member_branch_id" class="form-control">
                                            <?php $__currentLoopData = \App\Models\Branch::pluck('member_prefix','id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($id); ?>" <?php echo e(Auth()->user()->employee &&  Auth()->user()->employee->branch_id == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <input type="text" class="form-control" name="card_number" value="" id="member_code" autofocus  ondragenter="getMember()" onfocus="this.setSelectionRange(this.value.length,this.value.length);" >
                                </div>
                            </div>
                        </div>
                    </form>

                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function() {
    $('#memberAttendanceForm').submit(function(event) {
        event.preventDefault(); // Prevent the form from submitting immediately

        // Get the values from the input fields
        var memberBranchId = $('input[name="member_branch_id"]').val();
        var cardNumber = $('input[name="card_number"]').val();
        var csrfToken = $('meta[name="csrf-token"]').attr('content');

        // Check if the membership_id is not recorded before in the database
        $.ajax({
            url: '/admin/check-membership-attendance',
            type: 'POST',
            data: {
                _token: csrfToken,
                membership_id: cardNumber
            },
            headers: {
                'X-CSRF-TOKEN': csrfToken
            },
            success: function(response) {
                if (!response.exists) {
                    // If the membership_id is not recorded, show the SweetAlert confirmation dialog
                    Swal.fire({
                        title: 'Confirm Attendance',
                        text: 'Are you sure you want to mark attendance for card number: ' + cardNumber + '?',
                        icon: 'question',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, confirm'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $.ajax({
                                url: '/admin/take_attend',
                                type: 'POST',
                                data: {
                                    member_branch_id: memberBranchId,
                                    card_number: cardNumber,
                                    _token: csrfToken
                                },
                                headers: {
                                    'X-CSRF-TOKEN': csrfToken
                                },
                                success: function(data) {
                                    console.log(data.message);
                                },
                                error: function(error) {
                                    console.error('Error:', error);
                                }
                            });
                        }
                    });
                } else {
                    $.ajax({
                        url: '/admin/take_attend',
                        type: 'POST',
                        data: {
                            member_branch_id: memberBranchId,
                            card_number: cardNumber,
                            _token: csrfToken
                        },
                        headers: {
                            'X-CSRF-TOKEN': csrfToken
                        },
                        success: function(data) {
                            console.log(data.message);
                        },
                        error: function(error) {
                            console.error('Error:', error);
                        }
                    });
                }
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    });
});
</script>
<?php /**PATH E:\projects\gymapp\resources\views/partials/profile_attendance.blade.php ENDPATH**/ ?>