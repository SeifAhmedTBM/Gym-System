<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route("admin.member.storeTransfer", [$lead->id])); ?>" enctype="multipart/form-data">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="card">
            <div class="card-header">
                <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.member.title_singular')); ?>

            </div>

            <div class="card-body">

                <div class="form-group">
                    <label for="photo"><?php echo e(trans('cruds.member.fields.photo')); ?></label>
                    <div class="needsclick dropzone <?php echo e($errors->has('photo') ? 'is-invalid' : ''); ?>" id="photo-dropzone">
                    </div>
                    <?php if($errors->has('photo')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('photo')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.member.fields.photo_helper')); ?></span>
                </div>

                <div class="row form-group">
                    <div class="col-md-3">
                        <label class="required" for="name"><?php echo e(trans('cruds.member.fields.name')); ?></label>
                        <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name"
                            id="name" value="<?php echo e(old('name', $lead->name)); ?>" required>
                        <?php if($errors->has('name')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('name')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.name_helper')); ?></span>
                    </div>

                    <div class="col-md-3">
                        <label class="required" for="phone"><?php echo e(trans('cruds.member.fields.phone')); ?></label>
                        <input class="form-control <?php echo e($errors->has('phone') ? 'is-invalid' : ''); ?>" type="text"
                            name="phone" id="phone" value="<?php echo e(old('phone', $lead->phone)); ?>" required>
                        <?php if($errors->has('phone')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('phone')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.phone_helper')); ?></span>
                    </div>

                    <div class="col-md-3">
                        <label class="<?php echo e(config('domains')[config('app.url')]['national_id'] == true ? 'required' :''); ?>" for="national"><?php echo e(trans('cruds.member.fields.national')); ?></label>
                        <input class="form-control <?php echo e($errors->has('national') ? 'is-invalid' : ''); ?>" type="text"
                            name="national" id="national" value="<?php echo e(old('national', $lead->national)); ?>" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" <?php echo e(config('domains')[config('app.url')]['national_id'] == true ? 'min="14" max="14" required' :''); ?>>
                        <?php if($errors->has('national')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('national')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.email_helper')); ?></span>
                    </div>

                    <div class="col-md-3">
                        <label class="<?php echo e(config('domains')[config('app.url')]['email'] == true ? 'required' :''); ?>" for="email"><?php echo e(trans('cruds.member.fields.email')); ?></label>
                        <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="email"
                            name="email" id="email" value="<?php echo e(old('email', $lead->email)); ?>" <?php echo e(config('domains')[config('app.url')]['email'] == true ? 'required' :''); ?>>
                        <?php if($errors->has('email')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('email')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.national_helper')); ?></span>
                    </div>
                </div>

                <div class="row form-group">
                    <div class="col-md-3">
                        <label class="required"
                            for="member_code"><?php echo e(trans('cruds.member.fields.member_code')); ?></label>
                        <input class="form-control <?php echo e($errors->has('member_code') ? 'is-invalid' : ''); ?>" type="text"
                            name="member_code" id="member_code" value="<?php echo e($last_member_code + 001); ?>" required  
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('edit_member_code')): ?> 
                                readonly
                            <?php endif; ?>
                            >
                        <?php if($errors->has('member_code')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('member_code')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.member_code_helper')); ?></span>
                    </div>

                    <div class="col-md-3">
                        <label class="required" for="status_id"><?php echo e(trans('cruds.member.fields.status')); ?></label>
                        <select class="form-control select2 <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>"
                            name="status_id" id="status_id" required>
                            <option><?php echo e(trans('global.pleaseSelect')); ?></option>
                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e((old('status_id') ? old('status_id') : $lead->status->id ?? '') == $id ? 'selected' : ''); ?>>
                                    <?php echo e($entry); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('status')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('status')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.status_helper')); ?></span>
                    </div>

                    <div class="col-md-3">
                        <label class="required" for="source_id"><?php echo e(trans('cruds.member.fields.source')); ?></label>
                        <select class="form-control select2 <?php echo e($errors->has('source') ? 'is-invalid' : ''); ?>"
                            name="source_id" id="source_id" required>
                            <option><?php echo e(trans('global.pleaseSelect')); ?></option>
                            <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e((old('source_id') ? old('source_id') : $lead->source->id ?? '') == $id ? 'selected' : ''); ?>>
                                    <?php echo e($entry); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('source')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('source')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.source_helper')); ?></span>
                    </div>

                    <div class="col-md-3">
                        <label class="required" for="address">Area</label>
                        <select name="address_id" id="address_id" class="form-control select2 <?php echo e($errors->has('address_id') ? 'is-invalid' : ''); ?>" required>
                            <option><?php echo e(trans('global.pleaseSelect')); ?></option>
                            <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e((old('address_id') ? old('address_id') : $lead->address->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('address_id')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('address')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.lead.fields.address_helper')); ?></span>
                    </div>
                </div>

                <div class="row form-group">
                    <div class="col-md-3">
                        <label  for="card_number"><?php echo e(trans('cruds.member.fields.card_number')); ?></label>
                        <input class="form-control  <?php echo e($errors->has('card_number') ? 'is-invalid' : ''); ?>" type="text"
                            name="card_number" id="card_number" value="<?php echo e(old('card_number')); ?>" >
                        <?php if($errors->has('card_number')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('card_number')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-3">
                        <label class="required" for="dob"><?php echo e(trans('cruds.member.fields.dob')); ?></label>
                        <input class="form-control date <?php echo e($errors->has('dob') ? 'is-invalid' : ''); ?>" type="text"
                            name="dob" id="dob" value="<?php echo e(old('dob') ?? date('1990-01-01')); ?>" required>
                        <?php if($errors->has('dob')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('dob')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.dob_helper')); ?></span>
                    </div>
                    <div class="col-md-3">
                        <label class="required"><?php echo e(trans('cruds.member.fields.gender')); ?></label>
                        <select class="form-control <?php echo e($errors->has('gender') ? 'is-invalid' : ''); ?>" name="gender"
                            id="gender" required>
                            <option value disabled <?php echo e(old('gender', null) === null ? 'selected' : ''); ?>>
                                <?php echo e(trans('global.pleaseSelect')); ?></option>
                                <?php $__currentLoopData = App\Models\Lead::GENDER_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"
                                        <?php echo e(old('gender', $lead->gender) === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('gender')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('gender')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.gender_helper')); ?></span>
                    </div>

                    
                </div>
                <input type="hidden" id="sales_by_id" name="sales_by_id" value="<?php echo e($lead->sales_by_id); ?>" />
                <div class="form-group">
                    <label for="notes"><?php echo e(trans('cruds.member.fields.notes')); ?></label>
                    <textarea class="form-control <?php echo e($errors->has('notes') ? 'is-invalid' : ''); ?>" name="notes"
                        id="notes"><?php echo e(old('notes',$lead->notes)); ?></textarea>
                    <?php if($errors->has('notes')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('notes')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.member.fields.notes_helper')); ?></span>
                </div>
            </div>
        </div>

    
    <?php echo $__env->make('partials.subscription_details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('partials.invoices_details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
    <?php echo $__env->make('partials.payments_details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('partials.invoice_reminder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="card-footer">
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </div>
    </form>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
     <?php echo $__env->make('partials.create_member_transfer_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\gymapp\resources\views/admin/members/transfer.blade.php ENDPATH**/ ?>