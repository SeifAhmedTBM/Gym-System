
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <h5><?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.refund.title_singular')); ?></h5>
    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.refunds.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="refund_reason_id"><?php echo e(trans('cruds.refund.fields.refund_reason')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('refund_reason') ? 'is-invalid' : ''); ?>" name="refund_reason_id" id="refund_reason_id" required>
                    <?php $__currentLoopData = $refund_reasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('refund_reason_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('refund_reason')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('refund_reason')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.refund.fields.refund_reason_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="invoice_id"><?php echo e(trans('cruds.refund.fields.invoice')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('invoice') ? 'is-invalid' : ''); ?>" name="invoice_id" id="invoice_id" required>
                    <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('invoice_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('invoice')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('invoice')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.refund.fields.invoice_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="amount"><?php echo e(trans('cruds.refund.fields.amount')); ?></label>
                <input class="form-control <?php echo e($errors->has('amount') ? 'is-invalid' : ''); ?>" type="number" name="amount" id="amount" value="<?php echo e(old('amount', '0')); ?>" step="0.01" required>
                <?php if($errors->has('amount')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('amount')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.refund.fields.amount_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Gym-System\resources\views/admin/refunds/create.blade.php ENDPATH**/ ?>