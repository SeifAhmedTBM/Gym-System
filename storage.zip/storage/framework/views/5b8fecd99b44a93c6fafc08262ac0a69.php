
<?php $__env->startSection('content'); ?>
    
        <div class="row form-group">
            <div class="col-lg-6">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('external_payment_create')): ?>
                    <a class="btn btn-success" href="<?php echo e(route('admin.external-payments.create')); ?>">
                        <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.externalPayment.title_singular')); ?>

                    </a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('external_payment_filter')): ?>

                    <?php echo $__env->make('admin_includes.filters', [
                        'columns' => [
                        'title'         => ['label' => 'Title', 'type' => 'text'],
                        // 'name'          => ['label' => 'Name', 'type' => 'text', 'related_to' => 'lead'],
                        // 'phone'         => ['label' => 'Phone', 'type' => 'number', 'related_to' => 'lead'],
                        'amount'        => ['label' => 'Amount', 'type' => 'number'],
                        'account_id'    => ['label' => 'Account', 'type' => 'select' , 'data' => $accounts , 'related_to' => 'account'],
                        'branch_id'     => ['label' => 'Branch', 'type' => 'select', 'data' => $branches,'related_to' => 'account'],
                        'external_payment_category_id'    => ['label' => 'External Payment Category', 'type' => 'select' , 'data' => $external_payment_categories , 'related_to' => 'external_payment_category'],
                        'invoice_id'    => ['label' => 'Invoice', 'type' => 'number'],
                        'created_by_id' => ['label' => 'Created By', 'type' => 'select' , 'data' => $created_bies],
                        'created_at'    => ['label' => 'Created at', 'type' => 'date', 'from_and_to' => true]
                    ],
                        'route' => 'admin.external-payments.index'
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('csvImport.modal', ['model' => 'ExternalPayment', 'route' => 'admin.external-payments.parseCsvImport'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('external_payment_counter')): ?>
                <div class="col-lg-3 col-md-2 col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <h2 class="text-center"><?php echo e(trans('cruds.externalPayment.title_singular')); ?></h2>
                            <h2 class="text-center"><?php echo e($externalPayments->count()); ?></h2>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-2 col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <h2 class="text-center"><?php echo e(trans('cruds.externalPayment.fields.amount')); ?></h2>
                            <h2 class="text-center"><?php echo e(number_format($externalPayments->sum('amount')) ?? 0); ?></h2>
                        </div>    
                    </div>    
                </div>    
            <?php endif; ?>
        </div>
    
    <div class="card">
        <div class="card-header">
            <h5><?php echo e(trans('cruds.externalPayment.title_singular')); ?> <?php echo e(trans('global.list')); ?></h5>
        </div>

        <div class="card-body">
            <table class=" table table-bordered table-striped table-hover ajaxTable datatable datatable-ExternalPayment">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.externalPayment.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.externalPayment.fields.title')); ?>

                        </th>
                        <th>
                            Other Revenue Category
                        </th>
                        <th>
                            <?php echo e(trans('cruds.branch.title_singular')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.lead.title_singular')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.externalPayment.fields.amount')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.externalPayment.fields.notes')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.externalPayment.fields.account')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.externalPayment.fields.created_by')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.externalPayment.fields.created_at')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <script>
        $(function() {
            let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)

            let dtOverrideGlobals = {
                buttons:dtButtons,
                processing: true,
                serverSide: true,
                retrieve: true,
                searching:true,
                aaSorting: [],
                ajax: "<?php echo e(route('admin.external-payments.index',request()->all())); ?>",
                columns: [{
                        data: 'placeholder',
                        name: 'placeholder'
                    },
                    {
                        data: 'id',
                        name: 'id'
                    },
                    {
                        data: 'title',
                        name: 'title'
                    },
                    {
                        data: 'external_payment_category_name',
                        name: 'external_payment_category.name'
                    },
                    {
                        data: 'branch_name',
                        name: 'branch_name'
                    },
                    {
                        data: 'lead_name',
                        name: 'lead.name'
                    },
                    {
                        data: 'amount',
                        name: 'amount'
                    },
                    {
                        data: 'notes',
                        name: 'notes'
                    },
                    {
                        data: 'account_name',
                        name: 'account.name'
                    },
                    {
                        data: 'created_by_name',
                        name: 'created_by.name'
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                    {
                        data: 'actions',
                        name: '<?php echo e(trans('global.actions')); ?>'
                    }
                ],
                orderCellsTop: true,
                order: [
                    [1, 'desc']
                ],
                pageLength: 50,
            };
            let table = $('.datatable-ExternalPayment').DataTable(dtOverrideGlobals);
            $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e) {
                $($.fn.dataTable.tables(true)).DataTable()
                    .columns.adjust();
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Gym-System\resources\views/admin/externalPayments/index.blade.php ENDPATH**/ ?>