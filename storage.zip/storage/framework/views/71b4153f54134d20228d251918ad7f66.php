<div class="tab-pane fade" id="invoices" role="tabpanel" aria-labelledby="invoices-tab">
    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered table-striped table-hover zero-configuration">
                <thead>
                    <tr>
                        <th></th>
                        <th><?php echo e(trans('cruds.invoice.title')); ?></th>
                        <th><?php echo e(trans('cruds.membership.title')); ?></th>
                        <th><?php echo e(trans('cruds.invoice.fields.discount')); ?></th>
                        <th><?php echo e(trans('cruds.invoice.title_singular')); ?></th>
                        <th><?php echo e(trans('cruds.status.title_singular')); ?></th>
                        <th><?php echo e(trans('cruds.invoice.fields.sales_by')); ?></th>
                        <th><?php echo e(trans('cruds.bonu.fields.created_by')); ?></th>
                        <th><?php echo e(trans('cruds.invoice.fields.created_at')); ?></th>
                        <th><?php echo e(trans('cruds.action.title')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $member->invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.invoices.show', $invoice->id)); ?>">
                                    <?php echo e($invoice->invoicePrefix()); ?><?php echo e($invoice->id); ?>

                                </a>
                            </td>
                            <td>
                                <span class="d-block">
                                    <?php echo e($invoice->membership->service_pricelist->name ?? '-'); ?>

                                </span>
                                <span class="d-block">
                                    <?php echo e(trans('cruds.invoice.fields.service_fee')); ?> :
                                    <?php echo e(number_format($invoice->service_fee) ?? '-'); ?>

                                </span>
                                <span
                                    class="badge badge-<?php echo e(\App\Models\Membership::MEMBERSHIP_STATUS_COLOR[$invoice->membership->membership_status]); ?> p-2">
                                    <?php echo e(\App\Models\Membership::MEMBERSHIP_STATUS[$invoice->membership->membership_status]); ?>

                                </span>
                            </td>
                            <td>
                                <span class="d-block">
                                    <?php echo e($invoice->discount); ?>

                                </span>
                                <span class="d-block">
                                    <?php echo e($invoice->discount_notes); ?>

                                </span>
                            </td>
                            <td>
                                <span class="d-block text-success font-weight-bold">
                                    <?php echo e(trans('global.net')); ?> : <?php echo e(number_format($invoice->net_amount)); ?>

                                </span>
                                <span class="d-block text-primary font-weight-bold">
                                    <?php echo e(trans('invoices::invoice.paid')); ?> :
                                    <?php echo e(number_format($invoice->payments_sum_amount)); ?>

                                </span>
                                <span class="d-block text-danger font-weight-bold">
                                    <?php echo e(trans('global.rest')); ?> :
                                    <?php echo e(number_format($invoice->rest)); ?>

                                </span>
                            </td>
                            <td>
                                <span
                                    class="badge p-2 badge-<?php echo e(\App\Models\Invoice::STATUS_COLOR[$invoice->status]); ?>">
                                    <?php echo e(\App\Models\Invoice::STATUS_SELECT[$invoice->status]); ?>

                                </span>
                            </td>
                            <td>
                                <?php echo e($invoice->sales_by->name ?? '-'); ?>

                            </td>
                            <td>
                                <?php echo e($invoice->created_by->name ?? '-'); ?>

                            </td>
                            <td><?php echo e($invoice->created_at->toFormattedDateString()); ?></td>
                            <td>
                                <div class="dropdown">
                                    <a class="btn btn-primary dropdown-toggle" href="#" role="button"
                                        id="dropdownMenuLink" data-toggle="dropdown" aria-expanded="false">
                                        <?php echo e(trans('global.action')); ?>

                                    </a>

                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment_create')): ?>
                                            <?php if($invoice->status == 'partial'): ?>
                                                <a href="<?php echo e(route('admin.invoice.payment', $invoice->id)); ?>"
                                                    class="dropdown-item">
                                                    <i class="fa fa-plus-circle"></i>&nbsp;
                                                    <?php echo e(trans('cruds.payment.title_singular')); ?>

                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php if($invoice->status == 'partial'): ?>
                                            <a href="javascript:void(0)" onclick="setSettlementInvoice(this)"
                                                data-toggle="modal" data-target="#settlement_invoice"
                                                data-url="<?php echo e(route('admin.settlement.invoice', $invoice->id)); ?>"
                                                class="dropdown-item"><i class="fas fa-check-circle"></i> &nbsp;
                                                <?php echo e(trans('global.settlement')); ?></a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice_show')): ?>
                                            <a href="<?php echo e(route('admin.invoices.show', $invoice->id)); ?>"
                                                class="dropdown-item">
                                                <i class="fa fa-eye"></i>&nbsp;
                                                <?php echo e(trans('global.view')); ?>

                                            </a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice_edit')): ?>
                                            <a href="<?php echo e(route('admin.invoices.edit', $invoice->id)); ?>"
                                                class="dropdown-item">
                                                <i class="fa fa-pencil"></i>&nbsp;
                                                Edit
                                            </a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment_show')): ?>
                                            <a href="<?php echo e(route('admin.payments.index')); ?>?invoice_id=<?php echo e($invoice->id); ?>"
                                                class="dropdown-item">
                                                <i class="fa fa-money"></i>&nbsp;
                                                Show Payments
                                            </a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice_delete')): ?>
                                            <form action="<?php echo e(route('admin.invoices.destroy', $invoice->id)); ?>"
                                                method="POST"onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');"
                                                style="display: inline-block;">
                                                <input type="hidden" name="_method" value="DELETE">
                                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                <button type="submit" class="dropdown-item">
                                                    <i class="fa fa-times"></i> &nbsp;
                                                    <?php echo e(trans('global.delete')); ?>

                                                </button>
                                            </form>
                                        <?php endif; ?>

                                        <form action="<?php echo e(route('admin.invoice.download', $invoice->id)); ?>"
                                            method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="dropdown-item">
                                                <i class="fa fa-download"></i> &nbsp;
                                                <?php echo e(trans('global.downloadFile')); ?>

                                            </button>
                                        </form>


                                        <form action="<?php echo e(route('admin.invoice.send', $invoice->id)); ?>" method="POST"
                                            class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="dropdown-item">
                                                <i class="fab fa-whatsapp"></i> &nbsp;
                                                <?php echo e(trans('global.whatsapp')); ?>

                                            </button>
                                        </form>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('refund_create')): ?>
                                            <?php if($invoice->status !== 'refund'): ?>
                                                <a href="<?php echo e(route('admin.invoice.refund', $invoice->id)); ?>"
                                                    class="dropdown-item"><i class="fas fa-exchange-alt"></i>&nbsp;
                                                    &nbsp; <?php echo e(trans('cruds.refund.title')); ?></a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td colspan="11" class="text-center">No data Available</td>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="settlement_invoice" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Settlement
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php echo Form::open(['method' => 'POST', 'id' => 'settlement_invoice_form']); ?>

            <div class="modal-body">
                <h4 class="text-warning font-weight-bold text-center">
                    <?php echo e(trans('global.settlement_invoice')); ?>

                </h4>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">
                    <?php echo e(trans('global.close')); ?>

                </button>
                <button type="submit" class="btn btn-success"><?php echo e(trans('global.yes')); ?></button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<script>
    function setSettlementInvoice(button) {
        let formURL2 = $(button).data('url');
        $("#settlement_invoice_form").attr('action', formURL2);
    }
</script>
<?php /**PATH E:\projects\gymapp\resources\views/admin/members/tabs/invoices.blade.php ENDPATH**/ ?>