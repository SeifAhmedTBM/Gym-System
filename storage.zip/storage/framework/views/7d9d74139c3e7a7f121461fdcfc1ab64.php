   
   <div class="card">
    <div class="card-header">
        ENTER DETAILS OF THE PAYMENT
    </div>
    <div class="card-body">
        <div class="row form-group">
            <div class="col-md-4">
                <label class="required" for="net_amount"><?php echo e(trans('cruds.invoice.fields.net_amount')); ?></label>
                <input type="text" class="form-control" name="net_amount" id="net_amount" value="<?php echo e(old('net_amount') ?? 0); ?>" readonly required>
                <?php if($errors->has('net_amount')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('net_amount')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.invoice.fields.net_amount_helper')); ?></span>
            </div>

            <div class="col-md-4">
                <label class="required" for="received_amount"><?php echo e(trans('cruds.invoice.fields.received_amount')); ?></label>
                <input type="text" class="form-control" name="received_amount" id="received_amount" value="<?php echo e(old('received_amount') ?? 0); ?>" readonly required>
                <?php if($errors->has('received_amount')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('received_amount')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.invoice.fields.received_amount_helper')); ?></span>
            </div>

            <div class="col-md-4">
                <label class="required" for="amount_pending"><?php echo e(trans('cruds.payment.fields.amount_pending')); ?></label>
                <input class="form-control <?php echo e($errors->has('amount_pending') ? 'is-invalid' : ''); ?>" type="number"
                    name="amount_pending" id="amount_pending" value="<?php echo e(old('amount_pending') ?? 0); ?>" required readonly>
                <?php if($errors->has('amount_pending')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('amount_pending')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.payment.fields.amount_pending_helper')); ?></span>
            </div>
        </div>
        <div class="form-group row">
            <div class="col-md-6">
                <label class="required"><?php echo e(trans('cruds.branch.title_singular')); ?></label>
                <select class="form-control <?php echo e($errors->has('branch_id') ? 'is-invalid' : ''); ?>" name="branch_id" id="branch_id" 
                    onchange="getBranch()"  <?php echo e(is_null($selected_branch) ? '' : 'readonly'); ?> required >
                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e($selected_branch != NULL && $selected_branch->id == $id ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('branch_id')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('branch_id')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.invoice.fields.account_helper')); ?></span>
            </div>

            <div class="col-md-6">
                <label class="required"><?php echo e(trans('cruds.member.fields.payment_method')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('account_id') ? 'is-invalid' : ''); ?>" id="account_id" multiple="multiple" onchange="getAccounts()" required>
                    <?php if($selected_branch != NULL): ?>
                        <?php $__currentLoopData = $selected_branch->accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($account->id); ?>"><?php echo e($account->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
                <?php if($errors->has('account_id')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('account_id')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.invoice.fields.account_helper')); ?></span>
            </div>
        </div>

        <div class="row form-group" id="accounts_div">
            <?php if($selected_branch != NULL): ?>
                <?php $__currentLoopData = $selected_branch->accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="hidden" name="account_ids[]" value="<?php echo e($account->id); ?>">
                    <div class="col-md-3">
                        <label class="required" for="<?php echo e($account->name); ?>"><?php echo e($account->name); ?></label>
                        <input class="form-control accounts <?php echo e($errors->has('cash_amount') ? 'is-invalid' : ''); ?>" type="number"
                            name="account_amount[]" id="<?php echo e($account->id); ?>" required readonly>
                        <span class="help-block"><?php echo e(trans('cruds.payment.fields.cash_amount_helper')); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH E:\projects\gymapp\resources\views/partials/payments_details.blade.php ENDPATH**/ ?>