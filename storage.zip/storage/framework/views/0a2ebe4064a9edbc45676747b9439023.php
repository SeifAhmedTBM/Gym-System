<div class="tab-pane fade" id="trainer_reminders" role="tabpanel" aria-labelledby="reminder-tab">
    <h4 class="py-2">Trainer Reminders</h4>
    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered table-striped table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>
                            <?php echo e(trans('global.type')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('global.details')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.reminder.fields.next_due_date')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.reminder.fields.user')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('global.actions')); ?>

                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $member->trainer_reminders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer_reminder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php echo e(\App\Models\Reminder::TYPE[$trainer_reminder->type] ?? ''); ?>

                            </td>
                            <td>
                                <span class="d-block">
                                    <?php echo e($trainer_reminder->membership->service_pricelist->name ?? '-'); ?>

                                </span>
                                <?php if($trainer_reminder->type == 'due_payment'): ?>
                                    <span class="d-block">
                                        <?php echo e(trans('global.total')); ?> :
                                        <?php echo e($trainer_reminder->membership->invoice->net_amount ?? 0); ?>

                                    </span>
                                    <span class="d-block">
                                        <?php echo e(trans('invoices::invoice.paid')); ?> :
                                        <?php echo e($trainer_reminder->membership->invoice->payments->sum('amount') ?? 0); ?>

                                    </span>
                                    <span class="d-block">
                                        <?php echo e(trans('global.rest')); ?> :
                                        <?php echo e($trainer_reminder->membership->invoice->rest ?? 0); ?>

                                    </span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($trainer_reminder->due_date ?? ''); ?></td>
                            <td><?php echo e($trainer_reminder->user->name ?? '-'); ?></td>
                            <td>
                                <div class="btn-group">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reminder_create')): ?>
                                        <button type="button" data-toggle="modal" data-target="#takeMemberAction"
                                            onclick="takeMemberAction(<?php echo e($trainer_reminder->id); ?>)" class="btn btn-dark btn-sm"><i
                                                class="fa fa-phone"></i>
                                            &nbsp; <?php echo e(trans('cruds.reminder.fields.action')); ?>

                                        </button>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assign_reminder')): ?>
                                        <button type="button" data-toggle="modal" data-target="#assignReminder"
                                            class="btn btn-sm btn-success shadow-none text-white"
                                            onclick="assignReminder(<?php echo e($trainer_reminder->id . ',' . $trainer_reminder->user_id); ?>)"><i
                                                class="fa fa-user"></i>
                                            Assign
                                        </button>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reminder_delete')): ?>
                                        <form action="<?php echo e(route('admin.reminders.destroy', $trainer_reminder->id)); ?>" method="POST"
                                            onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');"
                                            style="display: inline-block;">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">
                                                <i class="fa fa-trash"></i> &nbsp;
                                                <?php echo e(trans('global.delete')); ?>

                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td colspan="7" class="text-center">No data Available</td>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <hr>
    <h4 class="py-2"><?php echo e(trans('global.reminders_history')); ?></h4>

    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered table-striped table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>
                            <?php echo e(trans('global.type')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.action.title_singular')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('global.details')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('global.due_date')); ?>

                        </th>
                        <th><?php echo e(trans('global.notes')); ?></th>
                        <th><?php echo e(trans('cruds.reminder.fields.user')); ?></th>
                        <th><?php echo e(trans('global.action_date')); ?></th>
                        <th><?php echo e(trans('global.action')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $member->trainer_reminder_histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer_reminder_history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php echo e(\App\Models\LeadRemindersHistory::TYPE[$trainer_reminder_history->type] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(\App\Models\LeadRemindersHistory::ACTION[$trainer_reminder_history->action] ?? ''); ?>

                            </td>
                            <td>
                                <span class="d-block">
                                    <?php echo e($trainer_reminder_history->membership->service_pricelist->name ?? '-'); ?>

                                </span>
                                <?php if($trainer_reminder_history->type == 'due_payment'): ?>
                                    <span class="d-block">
                                        <?php echo e(trans('global.total')); ?> :
                                        <?php echo e($trainer_reminder_history->membership->invoice->net_amount ?? 0); ?>

                                    </span>
                                    <span class="d-block">
                                        <?php echo e(trans('invoices::invoice.paid')); ?> :
                                        <?php echo e($trainer_reminder_history->membership->invoice->payments->sum('amount') ?? 0); ?>

                                    </span>
                                    <span class="d-block">
                                        <?php echo e(trans('global.rest')); ?> :
                                        <?php echo e($trainer_reminder_history->membership->invoice->rest ?? 0); ?>

                                    </span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($trainer_reminder_history->due_date ?? ''); ?></td>
                            <td><?php echo e($trainer_reminder_history->notes); ?></td>
                            <td><?php echo e($trainer_reminder_history->user->name ?? '-'); ?></td>
                            <td><?php echo e($trainer_reminder_history->created_at); ?></td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reminder_delete')): ?>
                                    <form action="<?php echo e(route('admin.reminderHistory.destroy', $trainer_reminder_history->id)); ?>"
                                        method="post" onsubmit="return confirm('Are you sure?');"
                                        style="display: inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-sm" type="submit">
                                            <i class="fa fa-trash"></i> <?php echo e(trans('global.delete')); ?>

                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td colspan="8" class="text-center">No data Available</td>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH E:\projects\gymapp\resources\views/admin/members/tabs/trainer_reminders.blade.php ENDPATH**/ ?>