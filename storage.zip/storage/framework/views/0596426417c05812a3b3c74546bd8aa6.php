<div class="tab-pane fade" id="invitations" role="tabpanel" aria-labelledby="invitations-tab">
    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered table-striped table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo e(trans('cruds.lead.title_singular')); ?></th>
                        <th><?php echo e(trans('cruds.lead.fields.phone')); ?></th>
                        <th><?php echo e(trans('cruds.membership.title_singular')); ?></th>
                        <th><?php echo e(trans('global.created_at')); ?></th>
                        <th><?php echo e(trans('global.actions')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $member->invitations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.leads.show', $invite->lead_id)); ?>"
                                    target="_blank"><?php echo e($invite->lead->name ?? '-'); ?></a>
                            </td>
                            <td><?php echo e($invite->lead->phone ?? '-'); ?></td>
                            <td><?php echo e($invite->membership->service_pricelist->name ?? '-'); ?></td>
                            <td><?php echo e($invite->created_at->toFormattedDateString() . ' , ' . $invite->created_at->format('g:i A')); ?>

                            </td>
                            <td>
                                <a class="btn btn-xs btn-success"
                                    href="<?php echo e(route('admin.member.transfer', $invite->lead_id)); ?>">
                                    <i class="fa fa-exchange"></i> <?php echo e(trans('global.transfer')); ?>

                                </a>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_invitations')): ?>
                                    <form
                                        action="<?php echo e(route('admin.invitation.destroy', $invite->id)); ?>"
                                        method="post" onsubmit="return confirm('Are you sure?');"
                                        style="display: inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-xs" type="submit">
                                            <i class="fa fa-trash"></i> <?php echo e(trans('global.delete')); ?>

                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td colspan="6" class="text-center">No data Available</td>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div><?php /**PATH E:\projects\gymapp\resources\views/admin/members/tabs/invitations.blade.php ENDPATH**/ ?>