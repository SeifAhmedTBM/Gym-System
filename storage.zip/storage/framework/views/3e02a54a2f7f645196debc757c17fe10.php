<?php $__env->startSection('content'); ?>

    <div class="row form-group">
        <div class="col-md-4">
            <form action="<?php echo e(route('admin.reports.due-payments-report')); ?>" method="get">
                <div class="input-group">
                    <select name="branch_id" id="branch_id" class="form-control" <?php echo e($employee && $employee->branch_id != NULL ? 'readonly' : ''); ?>>
                        <option value="<?php echo e(NULL); ?>" selected hidden disabled>Branch</option>
                        <?php $__currentLoopData = \App\Models\Branch::pluck('name','id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e($branch_id == $id ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="input-group-prepend">
                        <button class="btn btn-primary" type="submit" ><?php echo e(trans('global.submit')); ?></button>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-md-8 text-right">
            <h3 class="font-weight-bold">
                <?php echo e(trans('global.due_payments')); ?> : <span class="text-danger"><?php echo e(number_format($counter)); ?> EGP</span>
            </h3>
        </div>
    </div>
    <div class="card">
        <div class="card-header font-weight-bold">
            <i class="fa fa-file"></i> <?php echo e(trans('global.due_payments_report')); ?>

        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered text-center table-outline table-striped table-hover zero-configuration">
                    <thead class="thead-light">
                        <tr>
                            <th class="text-dark">#</th>
                            <th class="text-dark"><?php echo e(trans('global.name')); ?></th>
                            <th class="text-dark">Total Collected</th>
                            <th class="text-dark">Total Remaining</th>
                            <th class="text-dark"><?php echo e(trans('global.count')); ?></th>
                            <th class="text-dark"><?php echo e(trans('global.actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="font-weight-bold"><?php echo e($loop->iteration); ?></td>
                                <td class="font-weight-bold"><?php echo e($sale->name ?? '-'); ?></td>
                                <td class="font-weight-bold"><?php echo e(number_format($sale->invoices->sum('payments_sum_amount'))); ?> EGP</td>
                                <td class="font-weight-bold"><?php echo e(number_format($sale->invoices->sum('rest'))); ?> EGP</td>
                                <td class="font-weight-bold"><?php echo e($sale->invoices_count); ?></td>
                                <td class="font-weight-bold">
                                    <a href="<?php echo e(route('admin.invoice.duePayments',$sale->id)); ?>" class="btn font-weight-bold btn-primary btn-sm">
                                        <i class="fa fa-eye"></i> <?php echo e(trans('cruds.invoice.title')); ?>

                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td colspan="5" class="text-center"><?php echo e(trans('global.no_data_available')); ?></td>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer">
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\gymapp\resources\views/admin/reports/due_payments.blade.php ENDPATH**/ ?>