<?php $__env->startSection('content'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice.index')): ?>
        <div class="form-group">
            <a class="btn btn-danger" href="<?php echo e(route('admin.invoices.index')); ?>">
                <i class="fa fa-arrow-circle-left"></i> <?php echo e(trans('global.back_to_list')); ?>

            </a>
        </div>
    <?php endif; ?>


    <div class="card">
        <div class="card-header">
            <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.invoice.title')); ?>

            <?php if(auth()->user()->roles[0]->title == 'Super Visor'): ?>
                <form action="<?php echo e(route('admin.printInvoiceSupervisor', [$invoice->id,$alt_id])); ?>" class="d-inline float-right" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-primary btn-xs">
                        <i class="fa fa-print"></i> <?php echo e(trans('global.print')); ?>

                    </button>
                </form>
            <?php else: ?>
                <form action="<?php echo e(route('admin.invoice.print', $invoice->id)); ?>" class="d-inline float-right" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-primary btn-xs">
                        <i class="fa fa-print"></i> <?php echo e(trans('global.print')); ?>

                    </button>
                </form>
            <?php endif; ?>
            
        </div>

        <div class="card-body">
            <img src="<?php echo e(asset('images/'. $setting->menu_logo)); ?>" alt="Logo" width="100" class="mb-4">
            <div class="form-group">
                <div class="row" style="line-height: 32px !important;">
                    <div class="col-md-6">
                        <?php echo $invoice_tmp['left_section']; ?>

                    </div>
                    <div class="col-md-6 text-right">
                        <?php echo $invoice_tmp['right_section']; ?>

                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-6">
                        <div class="row my-2">
                            <div class="col-md-6">
                                <h6><?php echo e(trans('cruds.membership.title_singular')); ?></h6>
                            </div>

                            <div class="col-md-6">
                                <span class="d-block"><?php echo e($invoice->membership->service_pricelist->name ?? ''); ?> </span>
                                <span class="badge p-2 badge-<?php echo e(\App\Models\Membership::MEMBERSHIP_STATUS_COLOR[$invoice->membership->membership_status]); ?>">
                                    <?php echo e(\App\Models\Membership::MEMBERSHIP_STATUS[$invoice->membership->membership_status]); ?>

                                </span>
                            </div>
                        </div>
                        <?php if($invoice->membership->service_pricelist->serviceOptionsPricelist): ?>
                            <?php $__currentLoopData = $invoice->membership->service_pricelist->serviceOptionsPricelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($option->count>0): ?>
                                <div class="row my-2">
                                    <div class="col-md-6">
                                        <h6><?php echo e($option->service_option->name ?? '-'); ?></h6>
                                    </div>

                                    <div class="col-md-6">
                                    <span><?php echo e($option->service_option ? $option->count ?? '0' : '-'); ?></span>
                                    </div>
                                </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <div class="row my-2">
                            <div class="col-md-6">
                                <h6><?php echo e(trans('cruds.invoice.fields.service_fee')); ?></h6>
                            </div>

                            <div class="col-md-6">
                               <span><?php echo e($invoice->service_fee ?? ''); ?></span>
                            </div>
                        </div>

                        <div class="row my-2">
                            <div class="col-md-6">
                                <h6><?php echo e(trans('cruds.invoice.fields.discount')); ?></h6>
                            </div>

                            <div class="col-md-6">
                                <span><?php echo e($invoice->discount ?? ''); ?></span>
                            </div>
                        </div>

                        <div class="row my-2">
                            <div class="col-md-6">
                                <h6><?php echo e(trans('cruds.invoice.fields.net_amount')); ?></h6>
                            </div>

                            <div class="col-md-6">
                                <span><?php echo e($invoice->net_amount ?? ''); ?></span>
                            </div>
                        </div>

                        <div class="row my-2">
                            <div class="col-md-6">
                                <h6><?php echo e(trans('cruds.invoice.fields.paid_amount')); ?></h6>
                            </div>

                            <div class="col-md-6">
                                <span><?php echo e($invoice->payments_sum_amount ?? ''); ?></span>
                            </div>
                        </div>

                        <div class="row my-2">
                            <div class="col-md-6">
                                <h6><?php echo e(trans('global.rest')); ?></h6>
                            </div>

                            <div class="col-md-6">
                                <span><?php echo e($invoice->rest ?? ''); ?></span>
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.payment.fields.id')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(trans('cruds.account.title')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(trans('cruds.payment.fields.amount')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(trans('cruds.invoice.fields.sales_by')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(trans('cruds.bonu.fields.created_by')); ?>

                                     </th>
                                    <th>
                                       <?php echo e(trans('global.created_at')); ?>

                                    </th>
                                </tr>
                            </thead>
                            
                            <tbody>
                                <?php $__currentLoopData = $invoice->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($payment->id); ?></td>
                                        <td><?php echo e($payment->account->name ?? ''); ?></td>
                                        <td><?php echo e($payment->amount); ?></td>
                                        <td><?php echo e($payment->sales_by->name ?? ''); ?></td>
                                        <td><?php echo e($payment->created_by->name ?? ''); ?></td>
                                        <td><?php echo e($payment->created_at ?? ''); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12 <?php echo e(app()->isLocale('ar') ? 'text-right' : 'text-left'); ?>">
                        <?php echo $invoice_tmp['footer']; ?>

                    </div>
                </div>

            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\gymapp\resources\views/admin/invoices/show.blade.php ENDPATH**/ ?>