<div class="tab-pane fade" id="sales_reminders" role="tabpanel" aria-labelledby="sales-reminders-tab">
    <h4 class="py-2">Sales Reminders</h4>
    <div class="form-group">
        <button type="button" data-toggle="modal" data-target="#takeAction" onclick="takeAction(<?php echo e($member->id); ?>)"
            class="btn btn-info btn-xs"><i class="fa fa-plus"></i>
            &nbsp; <?php echo e(trans('global.add_reminder')); ?>

        </button>
    </div>
    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered table-striped table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>
                            <?php echo e(trans('global.type')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('global.details')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.reminder.fields.next_due_date')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.reminder.fields.user')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('global.actions')); ?>

                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $member->sales_reminders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sales_reminder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php echo e(\App\Models\Reminder::TYPE[$sales_reminder->type] ?? ''); ?>

                            </td>
                            <td>
                                <span class="d-block">
                                    <?php echo e($sales_reminder->membership->service_pricelist->name ?? '-'); ?>

                                </span>
                                <?php if($sales_reminder->type == 'due_payment'): ?>
                                    <span class="d-block">
                                        <?php echo e(trans('global.total')); ?> :
                                        <?php echo e($sales_reminder->membership->invoice->net_amount ?? 0); ?>

                                    </span>
                                    <span class="d-block">
                                        <?php echo e(trans('invoices::invoice.paid')); ?> :
                                        <?php echo e($sales_reminder->membership->invoice->payments->sum('amount') ?? 0); ?>

                                    </span>
                                    <span class="d-block">
                                        <?php echo e(trans('global.rest')); ?> :
                                        <?php echo e($sales_reminder->membership->invoice->rest ?? 0); ?>

                                    </span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($sales_reminder->due_date ?? ''); ?></td>
                            <td><?php echo e($sales_reminder->user->name ?? '-'); ?></td>
                            <td>
                                <div class="btn-group">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reminder_create')): ?>
                                        <button type="button" data-toggle="modal" data-target="#takeMemberAction"
                                            onclick="takeMemberAction(<?php echo e($sales_reminder->id); ?>)"
                                            class="btn btn-dark btn-sm"><i class="fa fa-phone"></i>
                                            &nbsp; <?php echo e(trans('cruds.reminder.fields.action')); ?>

                                        </button>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assign_reminder')): ?>
                                        <button type="button" data-toggle="modal" data-target="#assignReminder"
                                            class="btn btn-sm btn-success shadow-none text-white"
                                            onclick="assignReminder(<?php echo e($sales_reminder->id . ',' . $sales_reminder->user_id); ?>)"><i
                                                class="fa fa-user"></i>
                                            Assign
                                        </button>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reminder_delete')): ?>
                                        <form action="<?php echo e(route('admin.reminders.destroy', $sales_reminder->id)); ?>"
                                            method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');"
                                            style="display: inline-block;">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">
                                                <i class="fa fa-trash"></i> &nbsp;
                                                <?php echo e(trans('global.delete')); ?>

                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td colspan="7" class="text-center">No data Available</td>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <hr>
    <h4 class="py-2"><?php echo e(trans('global.reminders_history')); ?></h4>

    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered table-striped table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>
                            <?php echo e(trans('global.type')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.action.title_singular')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('global.details')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('global.due_date')); ?>

                        </th>
                        <th><?php echo e(trans('global.notes')); ?></th>
                        <th><?php echo e(trans('cruds.reminder.fields.user')); ?></th>
                        <th><?php echo e(trans('global.action_date')); ?></th>
                        <th><?php echo e(trans('global.action')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $member->sales_reminder_histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sales_reminder_history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php echo e(\App\Models\LeadRemindersHistory::TYPE[$sales_reminder_history->type] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(\App\Models\LeadRemindersHistory::ACTION[$sales_reminder_history->action] ?? ''); ?>

                            </td>
                            <td>
                                <span class="d-block">
                                    <?php echo e($sales_reminder_history->membership->service_pricelist->name ?? '-'); ?>

                                </span>
                                <?php if($sales_reminder_history->type == 'due_payment'): ?>
                                    <span class="d-block">
                                        <?php echo e(trans('global.total')); ?> :
                                        <?php echo e($sales_reminder_history->membership->invoice->net_amount ?? 0); ?>

                                    </span>
                                    <span class="d-block">
                                        <?php echo e(trans('invoices::invoice.paid')); ?> :
                                        <?php echo e($sales_reminder_history->membership->invoice->payments->sum('amount') ?? 0); ?>

                                    </span>
                                    <span class="d-block">
                                        <?php echo e(trans('global.rest')); ?> :
                                        <?php echo e($sales_reminder_history->membership->invoice->rest ?? 0); ?>

                                    </span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($sales_reminder_history->due_date ?? ''); ?></td>
                            <td><?php echo e($sales_reminder_history->notes); ?></td>
                            <td><?php echo e($sales_reminder_history->user->name ?? '-'); ?></td>
                            <td><?php echo e($sales_reminder_history->created_at); ?></td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reminder_delete')): ?>
                                    <form
                                        action="<?php echo e(route('admin.reminderHistory.destroy', $sales_reminder_history->id)); ?>"
                                        method="post" onsubmit="return confirm('Are you sure?');"
                                        style="display: inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-sm" type="submit">
                                            <i class="fa fa-trash"></i> <?php echo e(trans('global.delete')); ?>

                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td colspan="8" class="text-center">No data Available</td>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<div class="modal fade" id="takeAction" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo e(trans('cruds.reminder.fields.action')); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="" method="post" class="modalForm3">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="alert alert-info font-weight-bold">
                        <i class="fa fa-exclamation-circle"></i> <?php echo e(trans('global.if_empty_due_date')); ?> .
                    </div>
                    <div class="form-group">
                        <label for="due_date"><?php echo e(trans('global.due_date')); ?></label>
                        <input type="date" class="form-control" name="due_date" id="due_date">
                    </div>

                    <div class="form-group">
                        <label for="notes"><?php echo e(trans('cruds.lead.fields.notes')); ?></label>
                        <textarea name="notes" id="notes" rows="7" class="form-control"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function takeAction(id) {
        var id = id;
        var url = '<?php echo e(route('admin.reminders.takeMemberAction', ':id')); ?>';
        url = url.replace(':id', id);
        $(".modalForm3").attr('action', url);
    }
</script>
<?php /**PATH E:\projects\gymapp\resources\views/admin/members/tabs/sales_reminders.blade.php ENDPATH**/ ?>