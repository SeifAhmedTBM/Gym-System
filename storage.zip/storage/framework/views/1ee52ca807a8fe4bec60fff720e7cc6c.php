
<?php $__env->startSection('content'); ?>
    
    <div class="form-group">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(URL::current()); ?>" method="get">
                    <div class="form-group">
                        <label for="date"><?php echo e(trans('global.date')); ?></label>
                        <div class="input-group">
                            <input type="date" class="form-control" name="from"
                                value="<?php echo e(request('from') ?? date('Y-m-01')); ?>">
                            <input type="date" class="form-control" name="to"
                                value="<?php echo e(request('to') ?? date('Y-m-t')); ?>">
                            <select name="branch_id" id="branch_id" class="form-control"
                                <?php echo e($employee && $employee->branch_id != null ? 'readonly' : ''); ?>>
                                <option value="<?php echo e(null); ?>" selected hidden disabled>Branch</option>
                                <?php $__currentLoopData = \App\Models\Branch::pluck('name', 'id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e($branch_id == $id ? 'selected' : ''); ?>>
                                        <?php echo e($name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="input-group-prepend">
                                <button class="btn btn-primary" type="submit"><?php echo e(trans('global.submit')); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    

    
    <div class="form-group row">
        <div class="col-sm-4 col-lg-4">
            <div class="card mb-2">
                <div class="card-body text-center text-white bg-primary">
                    <div>
                        <h3><?php echo e(number_format($invoices)); ?></h3>
                        <div>Invoices</div>
                        <strong>( total net amount )</strong>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-4 col-lg-4">
            <div class="card mb-2 text-center text-white bg-success">
                <div class="card-body">
                    <div>
                        <h3><?php echo e(number_format($payments_sum_amount)); ?></h3>
                        <div>Payments</div>
                        <strong>( total payments for invoices this month )</strong>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-4 col-lg-4">
            <div class="card mb-2 text-center text-white bg-warning">
                <div class="card-body">
                    <div>
                        <h3><?php echo e(number_format($pending)); ?></h3>
                        <div>Pending</div>
                        <strong>( Pending amounts this month )</strong>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-4 col-lg-4">
            <div class="card mb-2 text-center text-white bg-success">
                <div class="card-body">
                    <div>
                        <h3><?php echo e(number_format($payments)); ?></h3>
                        <div>All Payments</div>
                        <strong>( total payments collected this month )</strong>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-4 col-lg-4">
            <div class="card mb-2 text-center text-white bg-danger">
                <div class="card-body">
                    <div>
                        <h3><?php echo e(number_format($refunds)); ?></h3>
                        <div>Refunds</div>
                        <strong>( total refunds this month )</strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    
    <?php $__currentLoopData = $service_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-group">
            <div class="card">
                <div class="card-header">
                    <strong><?php echo e($key); ?> - <?php echo e(trans('global.income')); ?> : <span
                            class="text-white"><?php echo e(number_format($payment->sum('amount'))); ?> EGP
                            (<?php echo e($payment->count() . ' Payment'); ?>)
                        </span> </strong>
                </div>
                <div class="card-body table-responsive">
                    <table class="table table-striped table-hover table-bordered zero-configuration">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Member</th>
                                <th>Service</th>
                                <th>Service Type</th>
                                <th><?php echo e(trans('global.payments.amount')); ?></th>
                                <th>Sales By</th>
                                <th>Created at</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(route('admin.invoices.show', $pay->invoice_id)); ?>">
                                            <?php echo e($pay->invoice->membership->member->branch->invoice_prefix . $pay->invoice_id); ?>

                                            <br>
                                            <?php echo e($pay->invoice->created_at->format('Y-m-d')); ?>

                                        </a>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.members.show', $pay->invoice->membership->member_id)); ?>">
                                            <b class="d-block">
                                                <?php echo e($pay->invoice->membership->member->branch->member_prefix . $pay->invoice->membership->member->member_code ?? ''); ?>

                                                (<?php echo e($pay->invoice->membership->member->name); ?>)
                                            </b>
                                        </a>
                                    </td>
                                    <td>
                                        <div class="p-2 badge badge-success">
                                            <?php echo e($pay->invoice->membership->service_pricelist->name); ?>

                                            <?php echo e($pay->invoice->membership->service_pricelist->session_count != 0 ? $pay->invoice->membership->service_pricelist->session_count . ' Session/s ' : ''); ?>

                                        </div>
                                    </td>
                                    <td>
                                        <span
                                            class="p-2 badge badge-<?php echo e(\App\Models\Membership::MEMBERSHIP_STATUS_COLOR[$pay->invoice->membership->membership_status]); ?>">
                                            <?php echo e(\App\Models\Membership::MEMBERSHIP_STATUS[$pay->invoice->membership->membership_status]); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e(number_format($pay->amount)); ?> - <?php echo e($pay->account->name ?? ''); ?></td>
                                    
                                    <td><?php echo e($pay->invoice->sales_by->name ?? '-'); ?></td>
                                    <td><?php echo e($pay->created_at); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

    
    <?php $__currentLoopData = $service_refunds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $refund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-group">
            <div class="card">
                <div class="card-header bg-danger">
                    <strong>
                        <?php echo e($key); ?> - <?php echo e(trans('global.outcome')); ?> : <span><?php echo e(number_format($refund->sum('amount'))); ?> EGP (<?php echo e($refund->count() . ' Refund'); ?>)</span> 
                    </strong>
                </div>
                <div class="card-body table-responsive">
                    <table class="table table-striped table-hover table-bordered zero-configuration">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th><?php echo e(trans('cruds.refund.fields.invoice')); ?></th>
                                <th>Service</th>
                                <th><?php echo e(trans('cruds.refund.fields.refund_reason')); ?></th>
                                <th><?php echo e(trans('cruds.externalPayment.fields.amount')); ?></th>
                                <th><?php echo e(trans('cruds.externalPayment.fields.created_by')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $refund; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ref): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(route('admin.invoices.show', $ref->invoice_id)); ?>"
                                            target="_blank"><?php echo e($ref->invoice->branch->invoice_prefix . $ref->invoice_id); ?>

                                        </a>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.members.show', $ref->invoice->membership->member_id)); ?>">
                                            <b class="d-block">
                                                <?php echo e($ref->invoice->branch->member_prefix . $ref->invoice->membership->member->member_code ?? ''); ?>

                                                (<?php echo e($ref->invoice->membership->member->name); ?>)
                                            </b>
                                        </a>
                                    </td>
                                    <td>
                                        <div class="p-2 badge badge-success">
                                            <?php echo e($ref->invoice->membership->service_pricelist->name); ?>

                                            <?php echo e($ref->invoice->membership->service_pricelist->session_count != 0 ? $ref->invoice->membership->service_pricelist->session_count . ' Session/s ' : ''); ?>

                                        </div>
                                    </td>
                                    <td><?php echo e($ref->refund_reason->name ?? '-'); ?></td>
                                    <td><?php echo e(number_format($ref->amount)); ?> - <?php echo e($ref->account->name ?? '-'); ?></td>
                                    <td><?php echo e($ref->created_by->name ?? '-'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Gym-System\resources\views/admin/reports/sales_daily.blade.php ENDPATH**/ ?>