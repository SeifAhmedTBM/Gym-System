
<button class="btn btn-primary" data-target="#filterModal" data-toggle="modal" type="button">
    <i class="fa fa-filter"></i> Filter
</button>

<!-- Filter Modal -->
<div class="modal fade bd-example-modal-lg" id="filterModal" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"> <?php echo e(trans('global.filter')); ?> </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php echo Form::open(['method' => 'GET', 'route' => $route]); ?>

            <div class="modal-body">
                <?php if(isset($columns)): ?>
                    <div class="form-row">
                        <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column_name => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($data['filter_by'])): ?>
                            <input type="hidden" name="filter_by" value="<?php echo e($data['filter_by']); ?>">
                        <?php endif; ?>
                        <div class="form-group col-md-4">
                            <?php if($data['type'] != 'select' && $data['type'] != 'date'): ?>
                                <?php echo Form::label($column_name, Str::ucfirst($data['label']), ['class' => 'font-weight-bold']); ?>

                                <?php if(isset($data['related_to'])): ?>
                                    <input type="<?php echo e($data['type']); ?>" value="<?php echo e(request()->get('relations')[$data['related_to']][$column_name] ?? ''); ?>" name="relations[<?php echo e($data['related_to']); ?>][<?php echo e($column_name); ?>]" class="form-control" placeholder="Type here">
                                <?php else: ?>
                                    <input type="<?php echo e($data['type']); ?>" value="<?php echo e(request()->get($column_name)); ?>" name="<?php echo e($column_name); ?>" class="form-control" placeholder="Type here">
                                <?php endif; ?>
                            <?php elseif($data['type'] == 'select' && !isset($data['related_to'])): ?>
                            
                            <?php echo Form::label($column_name, Str::ucfirst($data['label']), ['class' => 'font-weight-bold']); ?>

                            <select name="<?php echo e($column_name); ?>[]" id="<?php echo e($column_name); ?>" class="form-control select2" <?php echo e($column_name == 'trainer_id' && Auth()->user()->roles[0]->title == 'Trainer' ? 'readonly' : ''); ?> multiple>
                                
                                <?php $__currentLoopData = $data['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option  value="<?php echo e($id); ?>" <?php echo e((request()->get($column_name) ? in_array($id,request()->get($column_name)) : NULL) ? 'selected' : ''); ?>><?php echo e($col); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            <?php elseif($data['type'] == 'select' && isset($data['related_to'])): ?>
                                
                                <?php echo Form::label($column_name, Str::ucfirst($data['label']), ['class' => 'font-weight-bold']); ?>

                                
                                <select name="relations[<?php echo e($data['related_to']); ?>][<?php echo e($column_name); ?>][]" id="<?php echo e($column_name); ?>" class=" form-control select2" <?php echo e($column_name == 'trainer_id' && Auth()->user()->roles[0]->title == 'Trainer' ? 'readonly' : ''); ?> multiple>
                                    <?php $__currentLoopData = $data['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($id); ?>" <?php echo e((request()->get('relations') && isset(request()->get('relations')[$data['related_to']][$column_name]) ? in_array($id,request()->get('relations')[$data['related_to']][$column_name]) : '') ? 'selected' : ''); ?>>
                                            <?php echo e($col); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col_name => $col_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($col_data['type'] == 'date' && $col_data['from_and_to'] == true): ?>
                            <?php if(isset($data['related_to'])): ?>
                                <?php echo Form::label($col_name, Str::ucfirst($col_data['label']), ['class' => 'font-weight-bold']); ?>

                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <small class="text-success font-weight-bold">
                                                <i class="fa fa-exclamation-triangle"></i> From
                                            </small>
                                            <input type="date" value="<?php echo e(request()->get('relations')[$data['related_to']][$column_name]['from'] ?? ''); ?>" name="relations[<?php echo e($data['related_to']); ?>][<?php echo e($column_name); ?>][from]" id="date_from" class="form-control">
                                        </div>
                                        <div class="form-group col-md-6">
                                            <small class="text-success font-weight-bold">
                                                <i class="fa fa-exclamation-triangle"></i> To
                                            </small>
                                            <input type="date" value="<?php echo e(request()->get('relations')[$data['related_to']][$column_name]['to'] ?? ''); ?>" name="relations[<?php echo e($data['related_to']); ?>][<?php echo e($column_name); ?>][to]" id="date_to" class="form-control">
                                        </div>
                                    </div>
                            <?php else: ?>
                                <?php echo Form::label($col_name, Str::ucfirst($col_data['label']), ['class' => 'font-weight-bold']); ?>

                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <small class="text-success font-weight-bold">
                                                <i class="fa fa-exclamation-triangle"></i> From
                                            </small>
                                            <input type="date" value="<?php echo e(request()->get($col_name)['from'] ?? ''); ?>" name="<?php echo e($col_name); ?>[from]" id="date_from" class="form-control">
                                        </div>
                                        <div class="form-group col-md-6">
                                            <small class="text-success font-weight-bold">
                                                <i class="fa fa-exclamation-triangle"></i> To
                                            </small>
                                            <input type="date" value="<?php echo e(request()->get($col_name)['to'] ?? ''); ?>" name="<?php echo e($col_name); ?>[to]" id="date_to" class="form-control">
                                        </div>
                                    </div>
                            <?php endif; ?>
                            
                        <?php elseif($col_data['type'] == 'date' && $col_data['from_and_to'] == false): ?>
                            <?php echo Form::label($col_name, Str::ucfirst($col_data['label']), ['class' => 'font-weight-bold']); ?>

                            <div class="form-group">
                                <input type="date" value="<?php echo e(request()->get($col_name)['to'] ?? ''); ?>" name="<?php echo e($col_name); ?>" id="<?php echo e(Str::ucfirst($col_data['label'])); ?>" class="form-control">
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <div class="text-center alert alert-danger font-weight-bold">
                    Please , send " <code>columns</code> " parameter to the include directive
                </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                
                <a href="<?php echo e(route($route)); ?>" class="btn btn-warning">
                    <i class="fa fa-arrow-circle-left"></i> Reset
                </a>
                <button type="button" class="btn btn-danger" data-dismiss="modal"> 
                    <i class="fa fa-times"></i> <?php echo e(trans('global.cancel')); ?> 
                </button>
                <?php if(isset($columns)): ?>
                    <button type="submit" class="btn btn-primary"> 
                        <i class="fa fa-check"></i> <?php echo e(trans('global.filter')); ?>

                    </button>
                <?php endif; ?>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div><?php /**PATH E:\projects\Gym-System\resources\views/admin_includes/filters.blade.php ENDPATH**/ ?>