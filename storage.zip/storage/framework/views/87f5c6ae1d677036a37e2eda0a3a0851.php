<div class="tab-pane fade" id="member_notes" role="tabpanel" aria-labelledby="notes-tab">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_notes')): ?>
        <div class="form-group">
            <a href="<?php echo e(route('admin.note.create', $member->id)); ?>" class="btn btn-info btn-xs">
                <i class="fas fa-plus"></i> &nbsp; <?php echo e(trans('cruds.lead.fields.notes')); ?>

            </a>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered table-striped table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo e(trans('global.notes')); ?></th>
                        <th><?php echo e(trans('cruds.bonu.fields.created_by')); ?></th>
                        <th><?php echo e(trans('global.created_at')); ?></th>
                        <th><?php echo e(trans('global.actions')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $member->Notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($note->notes ?? '-'); ?></td>
                            <td><?php echo e($note->created_by->name ?? '-'); ?></td>
                            <td><?php echo e($note->created_at); ?></td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_notes')): ?>
                                    <a href="javascript:void(0)" data-target="#editNotesModal"
                                        class="btn btn-sm btn-success" data-toggle="modal" data-note="<?php echo e($note->notes); ?>"
                                        data-route="<?php echo e(route('admin.note.update', $note->id)); ?>"
                                        onclick="updateNote(this)">
                                        <i class="fa fa-edit"></i> &nbsp; <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_notes')): ?>
                                    <form action="<?php echo e(route('admin.note.destroy', $note->id)); ?>" method="POST"
                                        onsubmit="return confirm('Are you sure?');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">
                                            <i class="fa fa-trash"></i> &nbsp; Delete
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td colspan="46" class="text-center">No data Available</td>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<!-- Edit Notes Modal -->
<div class="modal fade" id="editNotesModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo e(trans('global.edit')); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php echo Form::open(['method' => 'PUT', 'id' => 'editNotesForm']); ?>

            <div class="modal-body">
                <div class="form-group">
                    <?php echo Form::label('edit_note', trans('global.notes'), ['class' => 'required']); ?>

                    <?php echo Form::textarea('edit_note', null, ['class' => 'form-control']); ?>

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">
                    <?php echo e(trans('global.close')); ?>

                </button>
                <button type="submit" class="btn btn-success"><?php echo e(trans('global.update')); ?></button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<script>
    function updateNote(button) 
    {
        $("#edit_note").text($(button).data('note'));
        $("#editNotesForm").attr('action', $(button).data('route'));
    }
</script><?php /**PATH E:\projects\gymapp\resources\views/admin/members/tabs/notes.blade.php ENDPATH**/ ?>