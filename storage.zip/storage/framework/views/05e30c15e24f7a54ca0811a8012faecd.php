
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <div class=" float-right">
                <form action="<?php echo e(route('admin.reports.print.monthlyReport')); ?>" method="get">
                    <input type="hidden" name="date" value="<?php echo e(request()->get('date') ?? date('Y-m')); ?>">
                    <button type="submit" class="btn btn-sm btn-info btn-block"><i class="fa fa-print"></i> <?php echo e(trans('global.print')); ?></button>
                </form>
            </div>

            <form action="<?php echo e(route('admin.reports.monthly.report')); ?>" method="get">
                <div class="row">
                    <div class="col-md-8">
                        <label for="date"><?php echo e(trans('global.date')); ?></label>
                        <div class="input-group">
                            <input type="date" class="form-control" name="from" value="<?php echo e(request('from') ?? date('Y-m-01')); ?>">
                            <input type="date" class="form-control" name="to" value="<?php echo e(request('to') ?? date('Y-m-t')); ?>">
                            <select name="branch_id" id="branch_id" class="form-control" <?php echo e($employee && $employee->branch_id != NULL ? 'readonly' : ''); ?>>
                                <option value="<?php echo e(NULL); ?>" selected hidden disabled>Branch</option>
                                <?php $__currentLoopData = \App\Models\Branch::pluck('name','id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e($branch_id == $id ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="input-group-prepend">
                                <button class="btn btn-primary" type="submit" ><?php echo e(trans('global.submit')); ?></button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
    <div id="DivIdToPrint">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h6 class="text-center"> <?php echo e(request('from') ?? date('Y-m-01')); ?> : <?php echo e(request('to') ?? date('Y-m-t')); ?></h6>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-4 col-lg-4">
                        <div class="card mb-2">
                            <div class="card-body text-center text-white bg-primary">
                                <div>
                                    <h3 id="total_income_card"></h3>
                                    <div><?php echo e(trans('global.total_income')); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>

        
                    <div class="col-sm-4 col-lg-4">
                        <div class="card mb-2 text-center text-white bg-danger">
                            <div class="card-body">
                                <div>
                                    <h3 id="total_outcome_card"></h3>
                                    <div><?php echo e(trans('global.total_outcome')); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4 col-lg-4">
                        <div class="card mb-2 text-center text-white bg-success">
                            <div class="card-body">
                                <div>
                                    <h3 id="net_income_card"></h3>
                                    <div><?php echo e(trans('global.net_income')); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
        
        
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row form-group">
                            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $tran_payments = $account->transactions->where('transactionable_type', 'App\Models\Payment')->sum('amount');
            
                                    $tran_externalPayments = $account->transactions->where('transactionable_type', 'App\Models\ExternalPayment')->sum('amount');
            
                                    $tran_refunds = $account->transactions->where('transactionable_type', 'App\Models\Refund')->sum('amount');

                                    $tran_loans = $account->transactions->where('transactionable_type', 'App\Models\Loan')->sum('amount');
            
                                    $tran_expenses = $account->transactions->where('transactionable_type', 'App\Models\Expense')->sum('amount');
            
                                    $total = ($tran_payments + $tran_externalPayments) - ($tran_refunds + $tran_expenses + $tran_loans); 
                                ?>
            
                                <div class="col-12 col-lg-4 col-xl-3">
                                    <div class="card mb-2">
                                        <div class="card-body text-center  bg-secondary">
                                            <div>
                                                <h3><?php echo e(number_format($total)); ?> EGP</h3>
                                                <div><?php echo e($account->name); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">
                                <div class="table-responsive">
                                    <table class=" table table-bordered table-striped table-hover datatable datatable-statement">
                                        <thead>
                                            <tr>
                                                <th>
                                                    <?php echo e(trans('cruds.transactions.fields.id')); ?>

                                                </th>
                                                <th>
                                                    <?php echo e(trans('cruds.transactions.fields.account')); ?>

                                                </th>
                                                <?php $__currentLoopData = $service_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th class="bg-primary">
                                                    <?php echo e($key); ?> Payments
                                                </th>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <th class="bg-primary">
                                                    <?php echo e(trans('cruds.externalPayment.title')); ?>

                                                </th>
                                                <th class="bg-primary">
                                                    Total Income
                                                </th>
                                                <?php $__currentLoopData = $service_refunds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $refund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <th class="bg-danger"> <?php echo e($key); ?> Refunds</th>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <th class="bg-danger">
                                                    Commission Fees
                                                </th>
                                                <th class="bg-danger">
                                                    <?php echo e(trans('cruds.expense.title')); ?>

                                                </th>
                                                <th class="bg-danger">
                                                    <?php echo e(trans('cruds.loan.title')); ?>

                                                </th>
                                                <th class="bg-danger">
                                                    Total Outcome
                                                </th>
                                                <th class="bg-success">
                                                    <?php echo e(trans('cruds.account.fields.balance')); ?>

                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $total_payments = 0;
                                                $total_revenues = 0;
                                                $total_refunds = 0;
                                                $total_expenses = 0;
                                                $total_loans = 0;
                                                $total_balance = 0;
                                                $total_commission_fees = 0;
                                            ?>
                                            <?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <?php
                                                        $tran_payments = $acc->transactions->where('transactionable_type', 'App\Models\Payment')->sum('amount');
                                                        
                                                        $tran_externalPayments = $acc->transactions->where('transactionable_type', 'App\Models\ExternalPayment')->sum('amount');
                                                        
                                                        $income = ($tran_payments + $tran_externalPayments);

                                                        $tran_refunds = $acc->transactions->where('transactionable_type', 'App\Models\Refund')->sum('amount');

                                                        $tran_loans = $acc->transactions->where('transactionable_type', 'App\Models\Loan')->sum('amount');

                                                        $tran_expenses = $acc->transactions->where('transactionable_type', 'App\Models\Expense')->sum('amount');

                                                        $commission_fees = ($income * $acc->commission_percentage) / 100;

                                                        $outcome = ($tran_refunds + $tran_loans + $tran_expenses + $commission_fees);

                                                        $total_commission_fees += $commission_fees;
                                                        $total_expenses += $tran_expenses;
                                                        $total_payments += $tran_payments;
                                                        $total_revenues += $tran_externalPayments;
                                                        $total_refunds += $tran_refunds;
                                                        $total_loans += $tran_loans;
                                                        $total_income = ($total_payments + $total_revenues);
                                                        $total_outcome = ($total_refunds + $total_loans + $total_expenses + $total_commission_fees);
        
                                                        $total = $income - $outcome;
                                                        $total_balance += $total;

                                                    ?>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($acc->name ?? ''); ?> (<?php echo e($acc->commission_percentage .'%'); ?>)</td>
                                                    <?php $__currentLoopData = $service_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td>
                                                            <?php echo e(number_format($payment->where('account_id',$acc->id)->sum('amount'))); ?></td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <td>
                                                        <?php echo e($tran_externalPayments); ?>

                                                    </td>
                                                    <td class="bg-primary">
                                                        <?php echo e(number_format($tran_payments + $tran_externalPayments)); ?>

                                                    </td>
                                                    <?php $__currentLoopData = $service_refunds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $refund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td><?php echo e(number_format($refund->where('account_id',$acc->id)->sum('amount'))); ?></td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <td>
                                                        <?php echo e(number_format($commission_fees,1)); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e(number_format($tran_expenses)); ?>

                                                    </td>

                                                    <td>
                                                        <?php echo e(number_format($tran_loans)); ?>

                                                    </td>
                                                    <td class="bg-danger">
                                                        <?php echo e(number_format($tran_refunds + $tran_loans + $tran_expenses + $commission_fees)); ?>

                                                    </td>
                                                    <td class="bg-success">
                                                        <?php echo e(number_format($total) ?? 0); ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <td colspan="7" class="text-center"><?php echo e(trans('global.no_data_available')); ?></td>
                                            <?php endif; ?>
                                            <tr>
                                                <td colspan="2"></td>
                                                <?php $__currentLoopData = $service_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td><?php echo e(number_format($payment->sum('amount'))); ?> EGP</td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <td><?php echo e(number_format($total_revenues)); ?> EGP</td>
                                                <td class="bg-primary" id="total_income"><?php echo e(number_format($total_income)); ?> EGP</td>
                                                <?php $__currentLoopData = $service_refunds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $refund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td><?php echo e(number_format($refund->sum('amount'))); ?> EGP</td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <td><?php echo e(number_format($total_commission_fees,1)); ?> EGP</td>
                                                <td><?php echo e(number_format($total_expenses)); ?> EGP</td>
                                                <td><?php echo e(number_format($total_loans)); ?> EGP</td>
                                                <td class="bg-danger" id="total_outcome"><?php echo e(number_format($total_outcome)); ?> EGP</td>
                                                <td class="bg-success" id="net_income"><?php echo e(number_format($total_balance)); ?> EGP</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
        
        <div class="row">
            <?php if($expenses->count() > 0): ?>
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong><?php echo e(trans('cruds.expense.title')); ?> : <span class="text-white"><?php echo e(number_format($expenses->sum('amount'))); ?> EGP (<?php echo e($expenses->count()); ?>)</span> </strong>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped table-hover table-bordered zero-configuration">
                                <thead>
                                    <tr>
                                        <th><?php echo e(trans('cruds.expense.fields.expenses_category')); ?></th>
                                        <th><?php echo e(trans('cruds.expense.fields.name')); ?></th>
                                        <th><?php echo e(trans('cruds.expense.fields.amount')); ?></th>
                                        <th><?php echo e(trans('cruds.expense.fields.created_by')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($expense->expenses_category->name ?? '-'); ?></td>
                                            <td><?php echo e($expense->name); ?></td>
                                            <td><?php echo e($expense->amount); ?> - <?php echo e($expense->account->name ?? '-'); ?></td>
                                            <td><?php echo e($expense->created_by->name ?? '-'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>    

            <?php if($loans->count() > 0): ?>
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong><?php echo e(trans('cruds.loan.title')); ?> : <span class="text-white"><?php echo e(number_format($loans->sum('amount'))); ?> EGP (<?php echo e($loans->count()); ?>)</span> </strong>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped table-hover table-bordered zero-configuration">
                                <thead>
                                    <tr>
                                        <th><?php echo e(trans('cruds.loan.fields.name')); ?></th>
                                        <th><?php echo e(trans('cruds.loan.fields.employee')); ?></th>
                                        <th><?php echo e(trans('cruds.loan.fields.amount')); ?></th>
                                        <th><?php echo e(trans('cruds.loan.fields.created_by')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loan->name ?? '-'); ?></td>
                                            <td><?php echo e($loan->employee->name ?? '-'); ?></td>
                                            <td><?php echo e($loan->amount); ?></td>
                                            <td><?php echo e($loan->created_by->name ?? '-'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if($external_payments->count() > 0): ?>
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong><?php echo e(trans('cruds.externalPayment.title')); ?> : <span class="text-white"><?php echo e(number_format($external_payments->sum('amount'))); ?> EGP (<?php echo e($external_payments->count()); ?>)</span> </strong>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped table-hover table-bordered zero-configuration">
                                <thead>
                                    <tr>
                                        <th><?php echo e(trans('cruds.externalPayment.title')); ?></th>
                                        <th><?php echo e(trans('cruds.externalPayment.fields.amount')); ?></th>
                                        <th><?php echo e(trans('cruds.externalPayment.fields.created_by')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $external_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $externalPayment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($externalPayment->title); ?></td>
                                            <td>
                                                <?php echo e($externalPayment->amount); ?> -
                                                <?php echo e($externalPayment->account->name ?? '-'); ?>

                                            </td>
                                            <td><?php echo e($externalPayment->created_by->name ?? '-'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php $__currentLoopData = $service_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong><?php echo e($key); ?> - <?php echo e(trans('global.income')); ?> : <span class="text-white"><?php echo e(number_format($payment->sum('amount'))); ?> EGP (<?php echo e($payment->count().' Payment'); ?>)</span> </strong> 
                        </div>
                        <div class="card-body table-responsive">
                            <table class="table table-striped table-hover table-bordered zero-configuration">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo e(trans('cruds.payment.fields.invoice')); ?></th>
                                        <th>Service</th>
                                        <th>Service Type</th>
                                        <th><?php echo e(trans('global.payments.amount')); ?></th>
                                        <th><?php echo e(trans('cruds.bonu.fields.created_by')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <a href="<?php echo e(route('admin.invoices.show', $pay->invoice_id)); ?>">
                                                    <?php echo e($pay->invoice->membership->member->branch->invoice_prefix . ' ' . $pay->invoice_id); ?>

                                                </a>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('admin.members.show',$pay->invoice->membership->member_id)); ?>">
                                                    <b class="d-block">
                                                        <?php echo e($pay->invoice->membership->member->branch->member_prefix . $pay->invoice->membership->member->member_code ?? ''); ?>

                                                        (<?php echo e($pay->invoice->membership->member->name); ?> )
                                                    </b>
                                                </a>
                                            </td>
                                            <td>
                                                <div class="p-2 badge badge-success">
                                                    <?php echo e($pay->invoice->membership->service_pricelist->name); ?>

                                                    <?php echo e($pay->invoice->membership->service_pricelist->session_count != 0 ? $pay->invoice->membership->service_pricelist->session_count . ' Session/s ' : ''); ?>

                                                </div>
                                            </td>
                                            <td>
                                                <span class="p-2 badge badge-<?php echo e(\App\Models\Membership::MEMBERSHIP_STATUS_COLOR[$pay->invoice->membership->membership_status]); ?>">
                                                    <?php echo e(\App\Models\Membership::MEMBERSHIP_STATUS[$pay->invoice->membership->membership_status]); ?>

                                                </span>
                                            </td>
                                            <td><?php echo e($pay->amount); ?> - <?php echo e($pay->account->name ?? ''); ?></td>
                                            <td><?php echo e($pay->created_by->name ?? '-'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $service_refunds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $refund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong><?php echo e($key); ?> - <?php echo e(trans('global.outcome')); ?> : <span class="text-white"><?php echo e(number_format($refund->sum('amount'))); ?> EGP (<?php echo e($refund->count().' Refund'); ?>)</span> </strong>
                        </div>
                        <div class="card-body table-responsive">
                            <table class="table table-striped table-hover table-bordered zero-configuration">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo e(trans('cruds.refund.fields.invoice')); ?></th>
                                        <th>Service</th>
                                        <th><?php echo e(trans('cruds.refund.fields.refund_reason')); ?></th>
                                        <th><?php echo e(trans('cruds.externalPayment.fields.amount')); ?></th>
                                        <th><?php echo e(trans('cruds.externalPayment.fields.created_by')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $refund; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ref): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <a href="<?php echo e(route('admin.invoices.show', $ref->invoice_id)); ?>"
                                                    target="_blank"><?php echo e($ref->invoice->membership->member->branch->invoice_prefix . ' ' . $ref->invoice_id); ?>

                                                </a>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('admin.members.show',$ref->invoice->membership->member_id)); ?>">
                                                    <b class="d-block">
                                                        <?php echo e($ref->invoice->membership->member->branch->member_prefix . $ref->invoice->membership->member->member_code ?? ''); ?>

                                                        (<?php echo e($ref->invoice->membership->member->name); ?> )
                                                    </b>
                                                </a>
                                            </td>
                                            <td>
                                                <div class="p-2 badge badge-success">
                                                    <?php echo e($ref->invoice->membership->service_pricelist->name); ?>

                                                    <?php echo e($ref->invoice->membership->service_pricelist->session_count != 0 ? $ref->invoice->membership->service_pricelist->session_count . ' Session/s ' : ''); ?>

                                                </div>
                                            </td>
                                            <td><?php echo e($ref->refund_reason->name ?? '-'); ?></td>
                                            <td><?php echo e($ref->amount); ?> - <?php echo e($ref->account->name ?? '-'); ?></td>
                                            <td><?php echo e($ref->created_by->name ?? '-'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function printFunction()
        {
            var divToPrint=document.getElementById('DivIdToPrint');

            var newWin=window.open('','Print-Window');

            newWin.document.open();

            newWin.document.write('<html><link href="<?php echo e(asset("css/coreui.min.css")); ?>" rel="stylesheet" type="text/css" /><style> th{font-size:21px;} td{font-size:21px;} h6{font-size:21px;} h5{font-size:21px;} </style><body onload="window.print()">'+divToPrint.innerHTML+'</body></html>');

            newWin.document.close();

            setTimeout(function(){newWin.close();},100);
        }

        $(document).ready(function(){
            $('#total_income_card').text($('#total_income').text());
            $('#total_outcome_card').text($('#total_outcome').text());
            $('#net_income_card').text($('#net_income').text());
        })
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Gym-System\resources\views/admin/reports/monthly.blade.php ENDPATH**/ ?>