<form action="<?php echo e(route('admin.home')); ?>" method="get">
    <div class="form-group row">
        <div class="col-md-6">
            <div class="input-group">
                <input type="month" class="form-control" name="date" value="<?php echo e(request('date') ?? date('Y-m')); ?>">
                <div class="input-group-prepend">
                    <button class="btn btn-primary" type="submit"><?php echo e(trans('global.submit')); ?></button>
                </div>
            </div>
        </div>
    </div>
</form>
<div class="form-group">
    <div class="card">
        <div class="card-header">
            Branches
        </div>
        <div class="card-body">
            <div class="form-group">
                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                    <div class="progress-group">
                        <div class="progress-group-header align-items-end">
                            <i class="cil-globe-alt progress-group-icon me-2"></i>
                            <div><?php echo e($branch->name); ?></div>
                            <div class="ms-auto font-weight-bold me-2">
                                <!-- <?php echo e(number_format($branch->sales_manager->employee->target_amount ?? 0).' EGP'); ?> -->
                                <?php echo e(number_format($branch->payments_sum_amount).' EGP'); ?>

                            </div>
                            <div class="text-white small">
                                (<?php echo e($branch->sales_manager && $branch->sales_manager->employee && $branch->sales_manager->employee->target_amount != 0 ? number_format(($branch->payments_sum_amount / $branch->sales_manager->employee->target_amount) * 100,2).' %' : '0 %'); ?>)
                            </div>
                        </div>
                        <div class="progress-group-bars">
                            <div class="progress progress-xs">
                                <div class="progress-bar bg-success progress-bar-striped progress-bar-animated" role="progressbar" style="width: <?php echo e($branch->sales_manager && $branch->sales_manager->employee && $branch->sales_manager->employee->target_amount != 0 ? number_format(($branch->payments_sum_amount / $branch->sales_manager->employee->target_amount) * 100,2) : '0'); ?>%" aria-valuenow="<?php echo e($branch->sales_manager && $branch->sales_manager->employee && $branch->sales_manager->employee->target_amount != 0 ? number_format(($branch->payments_sum_amount / $branch->sales_manager->employee->target_amount) * 100,2) : '0'); ?>" aria-valuemin="0" aria-valuemax="100"><strong><?php echo e(number_format($branch->payments_sum_amount).' EGP'); ?></strong></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="form-group">
                <table class="table table-bordered table-striped table-hover zero-configuration text-center">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Branch</th>
                            <th>Target</th>
                            <th>Collected</th>
                            <th>Percentage</th>
                            <!-- <th>Remaining</th> -->
                            <th>Options</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <?php echo e($branch->name); ?> <br> 
                                    Sales Manager : <?php echo $branch->sales_manager->name ?? '<span class="badge badge-danger">Not found !</span>'; ?>

                                </td>
                                <td><?php echo e(number_format($branch->sales_manager->employee->target_amount ?? 0)); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.payments.index',[
                                        'created_at[from]'  => date('Y-m-01'),
                                        'created_at[to]'    => date('Y-m-t'),
                                        'relations[account][branch_id]' => $branch->id
                                    ])); ?>" target="_blank">
                                        <?php echo e(number_format($branch->payments_sum_amount)); ?>

                                    </a>
                                </td>
                                <td>
                                    <?php echo e($branch->sales_manager && $branch->sales_manager->employee && $branch->sales_manager->employee->target_amount != 0 ? number_format(($branch->payments_sum_amount / $branch->sales_manager->employee->target_amount) * 100,2).' %' : '0 %'); ?>

                                </td>
                                <!-- <td><?php echo e(number_format($branch->remaining)); ?></td> -->
                                <td>
                                    <a href="<?php echo e(route('admin.reports.sales_details',[$branch->id,request('date') ?? date('Y-m')])); ?>" class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> Details</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\projects\gymapp\resources\views/dashboard/sales_director.blade.php ENDPATH**/ ?>