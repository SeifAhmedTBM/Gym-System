<div class="tab-pane fade" id="attendances" role="tabpanel" aria-labelledby="attendances-tab">
    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered table-striped table-hover zero-configuration">
                <thead>
                    <tr>
                        <th></th>
                        <th><?php echo e(trans('cruds.membership.title')); ?></th>
                        <th><?php echo e(trans('cruds.membershipAttendance.fields.sign_in')); ?></th>
                        
                        <th><?php echo e(trans('cruds.membershipAttendance.fields.sign_out')); ?></th>
                        
                        <th><?php echo e(trans('cruds.membershipAttendance.fields.date')); ?></th>
                        <th> Status </th>
                        
                        <?php if(\App\Models\Setting::first()->has_lockers == true): ?>
                            <th><?php echo e(trans('cruds.membershipAttendance.fields.locker')); ?></th>
                        <?php endif; ?>
                        <th> Options </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $member->membership_attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.memberships.show', $attend->membership->id)); ?>">
                                    <?php echo e($attend->membership->service_pricelist->name ?? '-'); ?>

                                    -
                                    <?php echo e($attend->membership->service_pricelist->service->name ?? '-'); ?>

                                </a>
                            </td>
                            <td><?php echo e(date('g:i A', strtotime($attend->sign_in))); ?></td>
                            <td>
                                <?php echo !is_null($attend->sign_out)
                                    ? date('g:i A', strtotime($attend->sign_out))
                                    : '<span class="badge badge-danger">Not Found</span>'; ?>

                            </td>
                            <td><?php echo e(date('Y-m-d', strtotime($attend->created_at))); ?></td>
                            <td>
                                <span
                                    class="badge badge-<?php echo e(\App\Models\Membership::STATUS[$attend->membership_status]); ?> p-2">
                                    <i class="fa fa-recycle"></i>
                                    <?php echo e(ucfirst($attend->membership_status) ?? '-'); ?>

                                </span>
                            </td>
                            <?php if(\App\Models\Setting::first()->has_lockers == true): ?>
                                <td><?php echo $attend->locker ?? '<span class="badge badge-danger">Not Found</span>'; ?></td>
                            <?php endif; ?>
                            <td>
                                <div class="dropdown">
                                    <a class="btn btn-primary dropdown-toggle" href="#" role="button"
                                        id="dropdownMenuLink" data-toggle="dropdown" aria-expanded="false">
                                        <?php echo e(trans('global.action')); ?>

                                    </a>

                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('membership_attendance_edit')): ?>
                                            
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('membership_attendance_delete')): ?>
                                            <form action="<?php echo e(route('admin.membership-attendances.destroy', $attend->id)); ?>"
                                                method="POST" onsubmit="return confirm('Are you sure?');"
                                                style="display: inline-block;">
                                                <input type="hidden" name="_method" value="DELETE">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="fa fa-trash"></i> &nbsp; Delete
                                                </button>
                                            </form>
                                        <?php endif; ?>

                                        <a class="dropdown-item" data-target="#editSigninAndSignoutModal"
                                            data-toggle="modal" href="javascript:void(0)"
                                            onclick="editSigninAndSignout(this)" data-locker="<?php echo e($attend->locker); ?>"
                                            data-sign-in="<?php echo e($attend->sign_in); ?>"
                                            data-sign-out="<?php echo e($attend->sign_out); ?>"
                                            data-update="<?php echo e(route('admin.membership-attendances.update', $attend->id)); ?>"
                                            data-get-url="<?php echo e(route('admin.membership-attendances.edit', $attend->id)); ?>">
                                            <i class="fa fa-edit"></i> &nbsp;
                                            <?php echo e(trans('global.edit_sign_in_and_out')); ?>

                                        </a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<!-- Edit Modal -->
<div class="modal fade" id="editSigninAndSignoutModal" tabindex="-1" aria-labelledby="editSigninAndSignoutModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editSigninAndSignoutModalLabel"><?php echo e(trans('global.edit')); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php echo Form::open(['method' => 'PUT', 'id' => 'editSigninAndSignoutForm']); ?>

            <div class="modal-body">
                <div class="form-row">
                    <div class="col-md-4 form-group">
                        <?php echo Form::label('sign_in', trans('cruds.membershipAttendance.fields.sign_in')); ?>

                        <?php echo Form::time('sign_in', null, ['class' => 'form-control', 'id' => 'edit_sign_in']); ?>

                    </div>
                    <div class="col-md-4 form-group">
                        <?php echo Form::label('sign_out', trans('cruds.membershipAttendance.fields.sign_out')); ?>

                        <?php echo Form::time('sign_out', null, ['class' => 'form-control', 'id' => 'edit_sign_out']); ?>

                    </div>
                    <div class="col-md-4 form-group">
                        <?php echo Form::label('locker', trans('cruds.membershipAttendance.fields.locker')); ?>

                        <?php echo Form::text('locker', null, ['class' => 'form-control', 'id' => 'edit_locker']); ?>

                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">
                    <?php echo e(trans('global.close')); ?>

                </button>
                <button type="submit" class="btn btn-success"><?php echo e(trans('global.update')); ?></button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<script>
    function editSigninAndSignout(button) 
    {
        let sign_in = $(button).data('sign-in');
        let sign_out = $(button).data('sign-out');
        let locker = $(button).data('locker');
        let formURL = $(button).data('update');
        let getURL = $(button).data('get-url');
        $("#editSigninAndSignoutForm").attr('action', formURL);
        $.ajax({
            method: "GET",
            url: getURL,
            success: function(response) {
                $("#edit_sign_in").val(response.sign_in);
                $("#edit_sign_out").val(response.sign_out);
                $("#edit_locker").val(response.membership_attendances.locker);
            }
        })
    }
</script>
<?php /**PATH E:\projects\gymapp\resources\views/admin/members/tabs/attendances.blade.php ENDPATH**/ ?>