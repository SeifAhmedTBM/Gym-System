<?php $__env->startSection('content'); ?>
    <div class="modal fade" id="settlement_invoice" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Settlement
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php echo Form::open(['method' => 'POST', 'id' => 'settlement_invoice_form']); ?>

                <div class="modal-body">
                    <h4 class="text-warning font-weight-bold text-center">
                        <?php echo e(trans('global.settlement_invoice')); ?>

                    </h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">
                        <?php echo e(trans('global.close')); ?>

                    </button>
                    <button type="submit" class="btn btn-success"><?php echo e(trans('global.yes')); ?></button>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
    <div class="form-group row">
        <div class="col-md-3 offset-9">
            <div class="card">
                <div class="card-body">
                    <h3 class="text-center"><?php echo e(trans('global.total')); ?></h3>
                    <h3 class="text-center"><?php echo e(number_format($sale->invoices->sum('rest'))); ?></h3>
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-header">
            <h5><i class="fa fa-file"></i> <?php echo e(trans('cruds.invoice.title')); ?> </h5>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered text-center table-striped table-hover zero-configuration">
                    <thead class="thead-light">
                        <tr>
                            <th>#</th>
                            <th>Invoice Number</th>
                            <th><?php echo e(trans('cruds.member.fields.name')); ?></th>
                            <th>Service</th>
                            <th><?php echo e(trans('cruds.invoice.fields.net_amount')); ?></th>
                            <th><?php echo e(trans('cruds.invoice.fields.paid_amount')); ?></th>
                            <th><?php echo e(trans('global.rest')); ?></th>
                            <th><?php echo e(trans('cruds.payment.fields.created_at')); ?></th>
                            <th><?php echo e(trans('global.actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $sale->invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($invoice->id ?? '-'); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.members.show', $invoice->membership->member_id)); ?>"
                                        target="_blank">
                                        <?php echo e($invoice->membership->member->member_code ?? '-'); ?>

                                        <br>
                                        <?php echo e($invoice->membership->member->name ?? '-'); ?>

                                        <br>
                                        <?php echo e($invoice->membership->member->phone ?? '-'); ?>

                                    </a>
                                </td>
                                <td><?php echo e($invoice->membership->service_pricelist->name ?? '-'); ?> </td>
                                <td><?php echo e(number_format($invoice->net_amount) ?? '-'); ?> EGP</td>
                                <td><?php echo e(number_format($invoice->payments_sum_amount) ?? '-'); ?> EGP</td>
                                <td><?php echo e(number_format($invoice->rest) ?? '-'); ?> EGP</td>
                                <td><?php echo e($invoice->created_at ?? '-'); ?></td>
                                <td>
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('admin.invoice.payments', $invoice->id)); ?>"
                                            class="btn btn-info btn-sm"><i class="fa fa-eye"></i>
                                            <?php echo e(trans('cruds.payment.title')); ?></a>

                                        <a href="<?php echo e(route('admin.invoice.payment', $invoice->id)); ?>"
                                            class="btn btn-success btn-sm"><i class="fa fa-plus-circle"></i>
                                            <?php echo e(trans('cruds.payment.title_singular')); ?>

                                        </a>
                                        <?php if(config('domains')[config('app.url')]['settlement_invoices'] == true): ?>
                                            <a href="javascript:void(0)" onclick="setSettlementInvoice(this)"
                                                data-toggle="modal" data-target="#settlement_invoice"
                                                data-url="<?php echo e(route('admin.settlement.invoice', $invoice->id)); ?>"
                                                class="btn btn-info"><i class="fas fa-check-circle"></i> &nbsp;
                                                <?php echo e(trans('global.settlement')); ?></a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td colspan="8" class="text-center"><?php echo e(trans('global.no_data_available')); ?></td>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer">
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function setSettlementInvoice(button) {
            let formURL2 = $(button).data('url');
            $("#settlement_invoice_form").attr('action', formURL2);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\gymapp\resources\views/admin/reports/due_payments_invoice.blade.php ENDPATH**/ ?>