<div class="tab-pane fade" id="session_attendances" role="tabpanel" aria-labelledby="session_attendances-tab">
    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered table-striped table-hover zero-configuration">
                <thead>
                    <tr>
                        <th></th>
                        <th><?php echo e(trans('cruds.membership.title')); ?></th>
                        <th><?php echo e(trans('cruds.membershipAttendance.fields.date')); ?></th>
                        <th> Options </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $member->trainer_attendants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t_attend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.memberships.show', $t_attend->membership_id)); ?>">
                                    <?php echo e($t_attend->membership->service_pricelist->name ?? '-'); ?>

                                    -
                                    <?php echo e($t_attend->membership->service_pricelist->service->name ?? '-'); ?>

                                </a>
                            </td>
                            <td><?php echo e(date('Y-m-d', strtotime($t_attend->created_at))); ?></td>
                            <td>
                                <div class="dropdown">
                                    <a class="btn btn-primary dropdown-toggle" href="#" role="button"
                                        id="dropdownMenuLink" data-toggle="dropdown" aria-expanded="false">
                                        <?php echo e(trans('global.action')); ?>

                                    </a>

                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('membership_attendance_delete')): ?>
                                            <form action="<?php echo e(route('admin.trainer-attendances.destroy', $t_attend->id)); ?>"
                                                method="POST" onsubmit="return confirm('Are you sure?');"
                                                style="display: inline-block;">
                                                <input type="hidden" name="_method" value="DELETE">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="dropdown-item">
                                                    <i class="fa fa-trash"></i> &nbsp; Delete
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH E:\projects\gymapp\resources\views/admin/members/tabs/session_attendances.blade.php ENDPATH**/ ?>