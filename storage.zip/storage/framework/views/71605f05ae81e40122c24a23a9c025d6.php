<div>
    <div class="form-group">
        <label for="action">Action</label>
        <select name="action" id="action" class="form-control" wire:model.live="action">
            <option value="<?php echo e(null); ?>">Select Action</option>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = App\Models\Reminder::ACTION; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!--[if BLOCK]><![endif]--><?php if(auth()->user()->roles[0]->title == 'Trainer'): ?>
                    <!--[if BLOCK]><![endif]--><?php if($key == 'done' || $key == 'appointment' || $key == 'not_interested'): ?>
                        <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php else: ?>
                    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

        </select>
    </div>
    <!--[if BLOCK]><![endif]--><?php if($due_date_active == true): ?>
        <div class="form-group">
            <label for="due_date"><?php echo e(trans('cruds.reminder.fields.next_due_date')); ?></label>
            <input type="date" name="due_date" id="due_date" class="form-control" value="<?php echo e($due_date); ?>">
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH E:\projects\Gym-System\resources\views/livewire/reminder-actions.blade.php ENDPATH**/ ?>