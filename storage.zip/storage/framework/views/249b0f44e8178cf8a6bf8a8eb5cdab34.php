<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('admin.members.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="card">
            <div class="card-header">
                <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.member.title_singular')); ?>

            </div>
            <div class="card-body">
                <div class="form-group">
                    <label for="photo"><?php echo e(trans('cruds.member.fields.photo')); ?></label>
                    <div class="needsclick dropzone <?php echo e($errors->has('photo') ? 'is-invalid' : ''); ?>"
                         id="photo-dropzone">
                    </div>
                    <?php if($errors->has('photo')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('photo')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.member.fields.photo_helper')); ?></span>
                </div>

                <?php if(config('domains')[config('app.url')]['minor'] == true): ?>
                    <div class="row form-group">
                        <div class="col-md-2">
                            <?php echo e(trans('global.minor')); ?>

                        </div>
                        <div class="col-md-1 text-right">
                            <label class="c-switch c-switch-3d c-switch-success">
                                <input type="checkbox" name="minor" id="minor" value="yes" class="c-switch-input">
                                <span class="c-switch-slider shadow-none"></span>
                            </label>
                        </div>
                    </div>

                    <div class="row form-group" id="parent" style="display: none">
                        <div class="col-md-3">
                            <label for=""><?php echo e(trans('global.parent_phone')); ?></label>
                            <input type="text" class="form-control" name="parent_phone"
                                   oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                        </div>
                        <div class="col-md-6">
                            <label for=""><?php echo e(trans('global.parent_details')); ?></label>
                            <input type="text" class="form-control" name="parent_details">
                        </div>
                    </div>
                <?php endif; ?>

                <div class="row form-group">
                    <div class="col-md-3">
                        <label class="required" for="name"><?php echo e(trans('cruds.member.fields.name')); ?></label>
                        <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text"
                               name="name"
                               id="name" value="<?php echo e(old('name', '')); ?>" required>
                        <?php if($errors->has('name')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('name')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.name_helper')); ?></span>
                    </div>

                    <div class="col-md-3">
                        <label class="required" for="phone"><?php echo e(trans('cruds.member.fields.phone')); ?></label>
                        <input class="form-control <?php echo e($errors->has('phone') ? 'is-invalid' : ''); ?>" type="text"
                               name="phone" id="phone" value="<?php echo e(old('phone', '')); ?>" required
                               oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"
                               min="11" max="11">

                        <?php if($errors->has('phone')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('phone')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.phone_helper')); ?></span>
                    </div>

                    


                    
                        <div class="col-md-3">
                            <label class="required" for="branch">Branch</label>
                            <select name="branch_id" id="branch_id"
                                    class="form-control <?php echo e($errors->has('branch_id') ? 'is-invalid' : ''); ?>"
                                    <?php echo e(is_null($selected_branch) ? '' : 'disabled'); ?> required>
                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e(($selected_branch ? $selected_branch->id == $id : '') ? 'selected' : ''); ?> >
                                        <?php echo e($entry); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('branch_id')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('branch_id')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.lead.fields.address_helper')); ?></span>
                        </div>
                    

                    <div class="col-md-3">
                        <label class="<?php echo e(config('domains')[config('app.url')]['email'] == true ? 'required' :''); ?>"
                               for="email"><?php echo e(trans('cruds.member.fields.email')); ?></label>
                        <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="email"
                               name="email" id="email"
                               value="<?php echo e(old('email', '')); ?>" <?php echo e(config('domains')[config('app.url')]['email'] == true ? 'required' :''); ?>>
                        <?php if($errors->has('email')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('email')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.email_helper')); ?></span>
                    </div>
                </div>

                <div class="row form-group">
                    <div class="col-md-3">
                        <label for="referral_member"><?php echo e(trans('cruds.lead.fields.referral_member')); ?></label>
                        <input type="text" class="form-control"
                               placeholder="<?php echo e(trans('cruds.lead.fields.referral_member')); ?>" name="referral_member"
                               id="referral_member" onblur="referralMember()" value="<?php echo e(old('referral_member')); ?>">
                        <small class="text-danger" id="referral_member_msg"></small>
                    </div>

                    <div class="col-md-3">
                        <label class="required"
                               for="member_code"><?php echo e(trans('cruds.member.fields.member_code')); ?></label>
                        <input class="form-control <?php echo e($errors->has('member_code') ? 'is-invalid' : ''); ?>" type="text"
                               name="member_code" id="member_code" value="<?php echo e($last_member_code + 1); ?>" required
                               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('edit_member_code')): ?>
                                   readonly
                                <?php endif; ?>>
                        <?php if($errors->has('member_code')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('member_code')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.member_code_helper')); ?></span>
                    </div>
                    <input type="hidden" value="<?php echo e(\App\Models\Status::first() ? \App\Models\Status::first()->id : 1); ?>"
                           id="status_id" name="status_id">
                    <div class="col-md-3">
                        <label class="required" for="source_id"><?php echo e(trans('cruds.member.fields.source')); ?></label>
                        <select class="form-control select2 <?php echo e($errors->has('source') ? 'is-invalid' : ''); ?>"
                                name="source_id" id="source_id" required>
                            <option disabled selected hidden><?php echo e(trans('global.pleaseSelect')); ?></option>
                            <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e(old('source_id') == $id ? 'selected' : ''); ?>>
                                    <?php echo e($entry); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('source')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('source')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.source_helper')); ?></span>
                    </div>

                    <div class="col-md-3">
                        <label for="whatsapp_number"><?php echo e(trans('global.whatsapp')); ?></label>
                        <input class="form-control <?php echo e($errors->has('whatsapp_number') ? 'is-invalid' : ''); ?>"
                               type="text"
                               name="whatsapp_number" id="whatsapp_number" value="<?php echo e(old('whatsapp_number')); ?>"
                               oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                        <?php if($errors->has('whatsapp_number')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('whatsapp_number')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row form-group">
                    <div class="col-md-3">
                        <label class="<?php echo e(config('domains')[config('app.url')]['national_id'] == true ? 'required' :''); ?>"
                               for="national"><?php echo e(trans('cruds.member.fields.national')); ?></label>
                        <input class="form-control <?php echo e($errors->has('national') ? 'is-invalid' : ''); ?>" type="text"
                               name="national" id="national" value="<?php echo e(old('national', '')); ?>"
                               oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" <?php echo e(config('domains')[config('app.url')]['national_id'] == true ? 'min="14" max="14" required' :''); ?>>
                        <?php if($errors->has('national')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('national')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.national_helper')); ?></span>
                    </div>
                    <div class="col-md-3">
                        <label class="required" for="dob"><?php echo e(trans('cruds.member.fields.dob')); ?></label>
                        <input class="form-control <?php echo e($errors->has('dob') ? 'is-invalid' : ''); ?>" type="date"
                               name="dob" id="dob" value="<?php echo e(old('dob') ?? date('1990-01-01')); ?>" required
                               max="<?php echo e(date('Y-m-d')); ?>">
                        <?php if($errors->has('dob')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('dob')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.dob_helper')); ?></span>
                    </div>
                    <div class="col-md-3">
                        <label class="required"><?php echo e(trans('cruds.member.fields.gender')); ?></label>
                        <select class="form-control <?php echo e($errors->has('gender') ? 'is-invalid' : ''); ?>" name="gender"
                                id="gender" required>
                            <option value disabled <?php echo e(old('gender', null) === null ? 'selected' : ''); ?>>
                                <?php echo e(trans('global.pleaseSelect')); ?></option>
                            <?php $__currentLoopData = App\Models\Lead::GENDER_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"
                                        <?php echo e(old('gender', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('gender')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('gender')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.gender_helper')); ?></span>
                    </div>

                    <div class="col-md-3">
                        <label class="required"
                               for="sales_by_id"><?php echo e(trans('cruds.member.fields.sales_by')); ?></label>
                        <select class="form-control select2 <?php echo e($errors->has('sales_by') ? 'is-invalid' : ''); ?>"
                                name="sales_by_id" id="sales_by_id" required>
                            <option disabled selected hidden><?php echo e(trans('global.pleaseSelect')); ?></option>
                            <?php $__currentLoopData = $sales_bies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e(old('sales_by_id') == $id ? 'selected' : ''); ?>>
                                    <?php echo e($entry); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('sales_by')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('sales_by')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.sales_by_helper')); ?></span>
                    </div>
                </div>


                <div class="form-group row">

                    <div class="col-md-6">
                        <label class="required" for="address">Area </label>
                        <select name="address_id" id="address_id"
                                class="form-control select2 <?php echo e($errors->has('address_id') ? 'is-invalid' : ''); ?>"
                                required>
                            <option disabled selected hidden><?php echo e(trans('global.pleaseSelect')); ?></option>
                            <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e(old('address_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('address_id')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('address')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.lead.fields.address_helper')); ?></span>
                    </div>

                    <div class="col-md-6">
                        <label for="address_details"><?php echo e(trans('cruds.lead.fields.address_details')); ?></label>
                        <input type="text"
                               class="form-control <?php echo e($errors->has('address_details') ? 'is-invalid' : ''); ?>"
                               name="address_details"
                               id="address_details" value="<?php echo e(old('address_details')); ?>"/>
                        <?php if($errors->has('address_details')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('address_details')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.lead.fields.address_details_helper')); ?></span>
                    </div>

                    <div class="col-md-12 mt-3">
                        <label for="notes"><?php echo e(trans('cruds.member.fields.notes')); ?></label>
                        <textarea class="form-control <?php echo e($errors->has('notes') ? 'is-invalid' : ''); ?>" name="notes"
                                  id="notes"><?php echo e(old('notes')); ?></textarea>
                        <?php if($errors->has('notes')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('notes')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.member.fields.notes_helper')); ?></span>
                    </div>
                </div>

            </div>
        </div>
        
        <?php echo $__env->make('partials.subscription_details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <?php echo $__env->make('partials.invoices_details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        
        <?php echo $__env->make('partials.payments_details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <?php echo $__env->make('partials.invoice_reminder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card-footer">
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo $__env->make('partials.create_member_transfer_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $("#minor").change(function () {
            if (this.checked == true) {
                $(".hideMe").slideDown();
                $('#parent').slideDown();
                $('#phone').attr('disabled', true);
                $('#national').attr('disabled', true);
            } else {
                $(".hideMe").slideUp();
                $('#parent').slideUp();
                $('#parent_phone').val(null);
                $('#parent_details').val(null);
                $('#phone').attr('disabled', false);
                $('#national').attr('disabled', false);
            }
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\gymapp\resources\views/admin/members/create.blade.php ENDPATH**/ ?>