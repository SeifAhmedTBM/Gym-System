<?php $__env->startSection('content'); ?>
    
    <form action="<?php echo e(route('admin.reports.sales-report')); ?>" method="get">
        <div class="row form-group">
            <div class="col-md-8">
                <label for="date"><?php echo e(trans('global.filter')); ?></label>
                <div class="input-group">
                    <select name="branch_id" class="form-control" <?php echo e($employee && $employee->branch_id != NULL ? 'readonly' : ''); ?>>
                        <option value="<?php echo e(NULL); ?>" selected>Branch</option>
                        <?php $__currentLoopData = \App\Models\Branch::pluck('name','id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e(request('branch_id') == $id ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <select name="sales_by_id" class="form-control">
                        <option value="<?php echo e(NULL); ?>" selected>Sales By</option>
                        <?php $__currentLoopData = \App\Models\User::whereRelation('roles','title','Sales')->pluck('name','id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sales_by_id => $sales_by_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sales_by_id); ?>" <?php echo e(request('sales_by_id') == $sales_by_id ? 'selected' : ''); ?>><?php echo e($sales_by_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <!-- <input type="date" class="form-control" name="start_date" value="<?php echo e(request('start_date')); ?>" >
                    <input type="date" class="form-control" name="end_date" value="<?php echo e(request('end_date')); ?>"> -->

                    <input type="month" class="form-control" name="date" value="<?php echo e(request('date') ?? date('Y-m')); ?>">
                    <div class="input-group-prepend">
                        <button class="btn btn-primary" type="submit"><?php echo e(trans('global.submit')); ?></button>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-2 col-sm-12 offset-md-1">
                <div class="card">
                    <div class="card-body">
                        <h2 class="text-center"><?php echo e(trans('global.total')); ?></h2>
                        <h2 class="text-center"><?php echo e(number_format($sales->sum('payments_sum_amount'))); ?></h2>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <div class="card">
        <div class="card-header">
            <h5><i class="fa fa-file"></i> <?php echo e(trans('global.sales_report')); ?></h5>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered text-center table-striped table-hover zero-configuration">
                    <thead class="thead-light">
                        <tr>
                            <th>#</th>
                            <th><?php echo e(trans('global.name')); ?></th>
                            <th><?php echo e(trans('cruds.branch.title_singular')); ?></th>
                            <th><?php echo e(trans('global.memberships')); ?></th>
                            <th><?php echo e(trans('global.target')); ?></th>
                            <th><?php echo e(trans('cruds.payment.title')); ?></th>
                            <th><?php echo e(trans('global.achieved')); ?></th>
                            <th><?php echo e(trans('global.commission')); ?> ( A )</th>
                            <th><?php echo e(trans('global.commission')); ?> ( % )</th>
                            <th><?php echo e(trans('global.actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if($sale->employee): ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($sale->name); ?></td>
                                <td><?php echo e($sale->employee->branch->name ?? '-'); ?></td>
                                <td><?php echo e($sale->memberships_count); ?></td>
                                <td><?php echo e(number_format($sale->employee->target_amount ?? 0)); ?> EGP</td>
                                <td>
                                    <?php echo e(number_format($sale->payments->sum('amount')) ?? 0); ?> EGP (<?php echo e($sale->payments->count()); ?>)
                                </td>
                                <td>
                                    <?php if(isset($sale->payments) && $sale->employee->target_amount > 0): ?>
                                        <?php if(isset($sale->sales_tier->sales_tier)): ?>
                                        <?php echo e(round(($sale->payments->sum('amount') / $sale->employee->target_amount) * 100)); ?>

                                            %
                                        <?php else: ?>
                                            <?php echo e(trans('global.there_is_no_sales_tier')); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    
                                    <?php if(isset($sale->payments)): ?>
                                        <?php if(isset($sale->sales_tier->sales_tier)): ?>
                                        <?php
                                            $sales_payments = $sale->payments->sum('amount');
                                            if ($sales_payments && $sale->employee->target_amount > 0) 
                                            {
                                                $achieved = ($sales_payments / $sale->employee->target_amount) *100;
                                                
                                                $sales_sales_tier_amount = ($sales_payments * $sale->sales_tier->sales_tier->sales_tiers_ranges()->where('range_from', '<=', $achieved)->orderBy('range_from','desc')->first()->commission) / 100;
                                            }
                                        ?>
                                        <?php echo e($sales_payments ? $sales_sales_tier_amount : 0); ?> EGP
                                        <?php else: ?>
                                            <?php echo e(trans('global.there_is_no_sales_tier')); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(isset($sale->payments)): ?>
                                        <?php if(isset($sale->sales_tier->sales_tier)): ?>
                                            <?php
                                                $sales_payments = $sale->payments->sum('amount');
                                                if ($sales_payments && $sale->employee->target_amount > 0) 
                                                {
                                                    $achieved = ($sales_payments / $sale->employee->target_amount) *100;
                                                    $sales_sales_tier_commission = ($sale->sales_tier->sales_tier->sales_tiers_ranges()->where('range_from', '<=', $achieved)->orderBy('range_from','desc')->first()->commission ?? 0);
                                                }
                                                
                                            ?>
                                            <?php echo e($sales_payments ? $sales_sales_tier_commission  : 0); ?> %
                                        <?php else: ?>
                                            <?php echo e(trans('global.there_is_no_sales_tier')); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.reports.sales-report.view',[$sale->id,'date='.request()->date])); ?>" class="btn btn-info btn-xs"><i class="fa fa-eye"></i> <?php echo e(trans('global.view')); ?></a>
                                </td>
                            </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center"><?php echo e(trans('global.no_data_available')); ?></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer">
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\gymapp\resources\views/admin/reports/sales.blade.php ENDPATH**/ ?>