
<?php $__env->startSection('styles'); ?>
    <style>
        .list-unstyled li {
            font-size: 18px;
            margin-bottom: 7px;
            font-weight: bold;
            padding-left: 20px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3>System reports</h3>
                </div>
                <div class="card-body">
                    <div class="row py-3">
                        <div class="col-md-4">
                            <h3>Members Reports</h3>
                            <ul class="list-unstyled mt-3">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_active_members')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.members.active')); ?>"><?php echo e(trans('global.active_members')); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_onhold_members')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.members.onhold')); ?>">On hold Members</a>
                                    </li>
                                <?php endif; ?>
                                

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_customer_invitations_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.customer-invitation')); ?>">
                                            Customer Invitation Report
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_inactive_members')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.members.inactive')); ?>"><?php echo e(trans('global.inactive_members')); ?></a>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_dayuse_members_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.dayuse')); ?>">Dayuse Members</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>

                        <div class="col-md-4">
                            <h3>Membership Reports</h3>
                            <ul class="list-unstyled mt-3">
                                
                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_main_expired_memberships_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.main-expired',[
                                            'relations[memberships][end_date][from]'    => date('Y-m-01'),
                                            'relations[memberships][end_date][to]'      => date('Y-m-t'),
                                        ])); ?>">
                                            Main <?php echo e(trans('global.expired_memberships')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_pt_expired_memberships_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.pt-expired',[
                                            'relations[memberships][end_date][from]'    => date('Y-m-01'),
                                            'relations[memberships][end_date][to]'      => date('Y-m-t'),
                                        ])); ?>">
                                            PT <?php echo e(trans('global.expired_memberships')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expiring_membership_access')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.membership.expiring-expired',[
                                            'end_date[from]'    => date('Y-m-01'),
                                            'end_date[to]'      => date('Y-m-t'),
                                        ])); ?>">
                                            Expiring & Expired Memberships
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_freezes')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.freeze.index')); ?>"><?php echo e(trans('global.freezes')); ?></a>
                                    </li>
                                <?php endif; ?>
                                
                            </ul>
                        </div>

                        <div class="col-md-4">
                            <h3>Sales Reports</h3>
                            <ul class="list-unstyled mt-3">
                                <li>
                                    <a href="<?php echo e(route('admin.reports.sales-daily-report')); ?>">
                                        Daily Sales Report
                                    </a>
                                    <span class="badge badge-danger">NEW</span>
                                </li>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_sales_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.sales-report')); ?>"><?php echo e(trans('global.sales_report')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_sales_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.previous-month-reports')); ?>"><?php echo e(trans('global.previous_month_report')); ?>

                                        </a>
                                        <span class="badge badge-danger">NEW</span>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_guest_log_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.guest-log-report')); ?>">Guest Log Report</a>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_daily_task_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.daily-task-report')); ?>">Daily Task Report</a>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_actions_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.actions-report')); ?>">Actions Report</a>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_reminders_report')): ?>
                                    <li>
                                        <a
                                            href="<?php echo e(route('admin.reports.reminders')); ?>"><?php echo e(trans('global.reminders_report')); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_reminders_actions_report')): ?>
                                    <li>
                                        <a
                                            href="<?php echo e(route('admin.reports.reminders.action')); ?>"><?php echo e(trans('global.reminders_action_report')); ?></a>
                                    </li>
                                <?php endif; ?>
                                
                                
                                
                                

                            </ul>
                        </div>
                    </div>

                    <div class="row py-3">
                        <div class="col-md-4">
                            <h3>Markting Reports</h3>
                            <ul class="list-unstyled mt-3">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_leads_source_report')): ?>
                                    <li>
                                        <a
                                            href="<?php echo e(route('admin.reports.leadsSource')); ?>"><?php echo e(trans('global.leads_source_report')); ?></a>
                                    </li>
                                <?php endif; ?>
                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_offers_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.offers')); ?>"><?php echo e(trans('global.offers_report')); ?></a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <div class="col-md-4">
                            <h3>Finance Analysis Reports</h3>
                            <ul class="list-unstyled mt-3">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_daily_report')): ?>
                                    <li>
                                        <a
                                            href="<?php echo e(route('admin.reports.daily.report')); ?>"><?php echo e(trans('global.daily_report')); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_monthly_report')): ?>
                                    <li>
                                        <a
                                            href="<?php echo e(route('admin.reports.monthly.report')); ?>"><?php echo e(trans('global.monthly_report')); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_yearly_finance_report')): ?>
                                    <li>
                                        <a
                                            href="<?php echo e(route('admin.reports.yearlyFinance.report')); ?>"><?php echo e(trans('global.yearly_finance_report')); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_monthly_finance_report')): ?>
                                    <li>
                                        <a
                                            href="<?php echo e(route('admin.reports.monthlyFinance.report')); ?>"><?php echo e(trans('global.monthly_finance_report')); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('due_payments_report')): ?>
                                    

                                    <li>
                                        <a href="<?php echo e(route('admin.reports.all-due-payments')); ?>">All Due Payments</a>
                                    </li>
                                <?php endif; ?>
                                
                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_other_revenue_categroies_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.external-payment-categories.report')); ?>">
                                            Other Revenue Categories Report</a>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_tax_accountant_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.tax-accountant')); ?>">Tax Accountant</a>
                                    </li>
                                <?php endif; ?>
                                
                                
                            </ul>
                        </div>

                        <div class="col-md-4">
                            <h3>Trainers Reports</h3>
                            <ul class="list-unstyled mt-3">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_daily_trainer_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.trainer-daily-report')); ?>">
                                            Daily Trainer Report
                                        </a>
                                        <span class="badge badge-danger">NEW</span>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_fitness_manager_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.fitness-manager-report')); ?>">
                                            Fitness Managers Report
                                        </a>
                                        <span class="badge badge-danger">NEW</span>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_trainers_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.trainers-report')); ?>">
                                            <?php echo e(trans('global.trainers_report')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_coaches_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.coaches')); ?>">Coaches Report</a>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_trainer_reminders_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.trainers-reminders')); ?>">
                                            Trainers Reminders
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_trainers_reminders_actions_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.trainers-reminder-actions')); ?>">
                                            Trainer Reminders Actions
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_trainer_reminders_histories_report')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.trainers-reminder-history-actions')); ?>">
                                            Trainer Reminders Histories
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_pt_attendances')): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.reports.pt-attendances-report')); ?>">
                                            PT Attendances Report
                                        </a>
                                        <span class="badge badge-danger">NEW</span>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Gym-System\resources\views/admin/sitemap.blade.php ENDPATH**/ ?>