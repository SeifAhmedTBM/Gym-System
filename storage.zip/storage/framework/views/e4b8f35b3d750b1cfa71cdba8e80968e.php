<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <h5><?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.account.title_singular')); ?></h5>
    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.accounts.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <div class="col-md-6">
                    <label class="required" for="name"><?php echo e(trans('cruds.account.fields.name')); ?></label>
                    <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', '')); ?>" required>
                    <?php if($errors->has('name')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('name')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.account.fields.name_helper')); ?></span>
                </div>
                <div class="col-md-6">
                    <label class="required" for="opening_balance"><?php echo e(trans('cruds.account.fields.opening_balance')); ?></label>
                    <input class="form-control <?php echo e($errors->has('opening_balance') ? 'is-invalid' : ''); ?>" type="number" name="opening_balance" id="opening_balance" value="<?php echo e(old('opening_balance', '0')); ?>" step="0.01" required>
                    <?php if($errors->has('opening_balance')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('opening_balance')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.account.fields.opening_balance_helper')); ?></span>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-6">
                    <label for="branch_id"><?php echo e(trans('cruds.branch.title_singular')); ?></label>
                    <select name="branch_id" id="branch_id" class="form-control select2">
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e(old('branch_id') == $id ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-6">
                    <label for="commission_percentage">Commission Percentage</label>
                    <div class="input-group">
                        <input type="number" class="form-control" step="0.01" name="commission_percentage" value="1" required>
                        <div class="input-group-append">
                            <span class="input-group-text" >%</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\gymapp\resources\views/admin/accounts/create.blade.php ENDPATH**/ ?>