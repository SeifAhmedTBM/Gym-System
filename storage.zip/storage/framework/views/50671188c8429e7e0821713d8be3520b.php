<div class="dropdown">
    <a class="btn btn-primary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown"
        aria-expanded="false">
        <?php echo e(trans('global.action')); ?>

    </a>

    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
        <?php if(request()->route()->getName() == 'admin.tasks.my-tasks'): ?>
            <?php if($row->status != 'done'): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_action')): ?>
                    <a href="<?php echo e(route('admin.tasks.done-tasks', $row->id)); ?>" class="dropdown-item">
                        <i class="fas fa-exchange-alt"></i> &nbsp; Done
                    </a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_action')): ?>
                    <a href="<?php echo e(route('admin.tasks.in-progress-tasks', $row->id)); ?>" class="dropdown-item">
                        <i class="fas fa-exchange-alt"></i> &nbsp; In Progress
                    </a>
                <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>

        <?php if(request()->route()->getName() == 'admin.tasks.index'): ?>
            <?php if($row->status == 'done' && $row->supervisor_id == auth()->id() || $row->status == 'done' && $row->supervisor_id == NULL || $row->status == 'done' && auth()->user()->roles[0]->title == 'Super Admin' || $row->status == 'done' && auth()->user()->roles[0]->title == 'Admin'): ?>
                <form action="<?php echo e(route('admin.tasks.confirm-task', $row->id)); ?>" method="POST"
                    onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                    <input type="hidden" name="_method" value="PUT">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <button type="submit" class="dropdown-item">
                            <i class="fa fa-check-circle"></i> &nbsp; <?php echo e(trans('global.confirm')); ?> 
                    </button>
                </form>
            <?php endif; ?>
        <?php endif; ?>

        <?php if(request()->route()->getName() == 'admin.leads.index'): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('transfer_to_member')): ?>
                <a href="<?php echo e(route('admin.member.transfer', $row->id)); ?>" class="dropdown-item">
                    <i class="fas fa-exchange-alt"></i> &nbsp; <?php echo e(trans('global.transfer_to_member')); ?>

                </a>
            <?php endif; ?>


            
            
            

            
            <a href="<?php echo e(route('admin.note.create', $row->id)); ?>" class="dropdown-item">
                <i class="fas fa-plus"></i> &nbsp; <?php echo e(trans('cruds.lead.fields.notes')); ?>

            </a>
            
        <?php endif; ?>

        <?php if(request()->route()->getName() == 'admin.services.index'): ?>
            <a href="<?php echo e(route('admin.service.pricelists', $row->id)); ?>" class="dropdown-item">
                <i class="fas fa-file"></i> &nbsp; <?php echo e(trans('cruds.pricelist.title')); ?>

            </a>
        <?php endif; ?>

        <?php if(request()->route()->getName() == 'admin.members.index'): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_membership')): ?>
                <a href="<?php echo e(route('admin.member.addMembership', $row->id)); ?>" class="dropdown-item"><i
                        class="fa fa-plus-circle"></i> &nbsp; <?php echo e(trans('global.add')); ?>

                    <?php echo e(trans('cruds.membership.title_singular')); ?></a>
            <?php endif; ?>

            
            <a href="<?php echo e(route('admin.note.create', $row->id)); ?>" class="dropdown-item">
                <i class="fas fa-plus"></i> &nbsp; <?php echo e(trans('cruds.lead.fields.notes')); ?>

            </a>
            

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('take_action')): ?>
                <button type="button" data-toggle="modal" data-target="#takeMemberAction"
                    onclick="takeMemberAction(<?php echo e($row->id); ?>)" class="dropdown-item"><i class="fa fa-phone"></i>
                    &nbsp; <?php echo e(trans('global.add_reminder')); ?></button>
            <?php endif; ?>

            <li>
                <a href="javascript:;" data-toggle="modal" data-target="#transfer_to_branch" class="dropdown-item" onclick="transfer_to_branch(<?php echo e($row->id); ?>)">
                    <i class="fa fa-exchange"></i> Transfer to Branch
                </a>
            </li>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('take_action')): ?>
                <button type="button" data-toggle="modal" data-target="#sendMessage"
                    onclick="sendMessage(<?php echo e($row->id); ?>)" class="dropdown-item"><i class="fa fa-paper-plane"></i>
                    &nbsp; <?php echo e(trans('global.send_sms')); ?></button>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_card_number')): ?>
                <a class="dropdown-item" href="<?php echo e(route('admin.cardNumber.edit', $row->id)); ?>">
                    <i class="fa fa-edit"></i> &nbsp;
                    <?php echo e(trans('global.edit') . ' ' . trans('cruds.member.fields.card_number')); ?>

                </a>
            <?php endif; ?>
        <?php endif; ?>

        <?php if(
            (request()->route()->getName() == 'admin.invoices.index' &&
                $row->status == 'partial') ||
                request()->route()->getName() == 'admin.invoices.partial'): ?>
            <a href="<?php echo e(route('admin.invoice.payment', $row->id)); ?>" class="dropdown-item">
                <i class="fa fa-plus-circle"></i> &nbsp; <?php echo e(trans('cruds.payment.title_singular')); ?></a>
        <?php endif; ?>

        <?php if(request()->route()->getName() == 'admin.sales-tiers.index'): ?>
            <a href="javascript:void(0)" data-toggle="modal"
                data-get="<?php echo e(route('admin.sales-tier.get_details', $row->id)); ?>"
                data-target="#transferToNextMonthModal"
                data-route="<?php echo e(route('admin.sales-tiers.transfer', $row->id)); ?>" onclick="getSalesTierName(this)"
                class="dropdown-item">
                <i class="fa fa-exchange"></i> &nbsp; <?php echo e(trans('global.transfer_to_next_month')); ?>

            </a>
        <?php endif; ?>


        <?php if(isset($viewGate)): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($viewGate)): ?>
                <a class="dropdown-item" href="<?php echo e(route('admin.' . $crudRoutePart . '.show', $row->id)); ?>">
                    <i class="fa fa-eye"></i> &nbsp; <?php echo e(trans('global.view')); ?>

                </a>
            <?php endif; ?>
        <?php endif; ?>

        <?php if(request()->route()->getName() == 'admin.members.index'): ?>
            <a class="dropdown-item" data-member-id="<?php echo e($row->id); ?>" data-toggle="modal"
                data-target="#memberRequestModal" onclick="createMemberRequest(this)" href="javascript:void(0)">
                <i class="fas fa-hand-paper"></i> &nbsp; <?php echo e(trans('global.member_request')); ?>

            </a>
        <?php endif; ?>

        <?php if(isset($editGate)): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($editGate)): ?>
                <?php switch(request()->route()->getName()):
                    case ('admin.freeze-requests.index'): ?>
                        <?php if($row->status == 'pending'): ?>
                            <a class="dropdown-item" href="<?php echo e(route('admin.' . $crudRoutePart . '.edit', $row->id)); ?>">
                                <i class="fa fa-edit"></i> &nbsp; <?php echo e(trans('global.edit')); ?>

                            </a>
                        <?php endif; ?>
                    <?php break; ?>

                    <?php case ('admin.memberships.index'): ?>
                        <?php if($row->status != 'refunded'): ?>
                            <a class="dropdown-item" href="<?php echo e(route('admin.' . $crudRoutePart . '.edit', $row->id)); ?>">
                                <i class="fa fa-edit"></i> &nbsp; <?php echo e(trans('global.edit')); ?>

                            </a>
                        <?php endif; ?>
                    <?php break; ?>

                    <?php case ('admin.refunds.index'): ?>
                        
                        <a class="dropdown-item" href="<?php echo e(route('admin.' . $crudRoutePart . '.edit', $row->id)); ?>">
                            <i class="fa fa-edit"></i> &nbsp; <?php echo e(trans('global.edit')); ?>

                        </a>
                        
                    <?php break; ?>

                    <?php default: ?>
                        <a class="dropdown-item" href="<?php echo e(route('admin.' . $crudRoutePart . '.edit', $row->id)); ?>">
                            <i class="fa fa-edit"></i> &nbsp; <?php echo e(trans('global.edit')); ?>

                        </a>
                <?php endswitch; ?>
            <?php endif; ?>
        <?php endif; ?>

        <?php if(isset($deleteGate)): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($deleteGate)): ?>
                <?php switch(request()->route()->getName()):
                    case ('admin.payments.index'): ?>
                        <?php if($row->account->balance >= $row->amount): ?>
                            <form action="<?php echo e(route('admin.' . $crudRoutePart . '.destroy', $row->id)); ?>" method="POST"
                                onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                <input type="hidden" name="_method" value="DELETE">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <button type="submit" class="dropdown-item">
                                    <i class="fa fa-trash"></i> &nbsp; <?php echo e(trans('global.delete')); ?>

                                </button>
                            </form>
                        <?php endif; ?>
                    <?php break; ?>

                    
                    <?php case ('admin.accounts.index'): ?>
                        <?php if(count($row->transactions) <= 0): ?>
                            <form action="<?php echo e(route('admin.' . $crudRoutePart . '.destroy', $row->id)); ?>" method="POST"
                                onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                <input type="hidden" name="_method" value="DELETE">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <button type="submit" class="dropdown-item">
                                    <i class="fa fa-trash"></i> &nbsp; <?php echo e(trans('global.delete')); ?>

                                </button>
                            </form>
                        <?php endif; ?>
                    <?php break; ?>

                    <?php case ('admin.freeze-requests.index'): ?>
                        <?php if($row->status == 'pending'): ?>
                            <form action="<?php echo e(route('admin.' . $crudRoutePart . '.destroy', $row->id)); ?>" method="POST"
                                onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                <input type="hidden" name="_method" value="DELETE">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <button type="submit" class="dropdown-item">
                                    <i class="fa fa-trash"></i> &nbsp; <?php echo e(trans('global.delete')); ?>

                                </button>
                            </form>
                        <?php endif; ?>
                    <?php break; ?>

                    <?php case ('admin.pricelists.index'): ?>
                        <?php if(!$row->has('memberships')): ?>
                            <form action="<?php echo e(route('admin.' . $crudRoutePart . '.destroy', $row->id)); ?>" method="POST"
                                onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                <input type="hidden" name="_method" value="DELETE">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <button type="submit" class="dropdown-item">
                                    <i class="fa fa-trash"></i> &nbsp; <?php echo e(trans('global.delete')); ?>

                                </button>
                            </form>
                        <?php endif; ?>
                    <?php break; ?>

                    <?php case ('admin.services.index'): ?>
                        <?php if($row->service_pricelist->count() <= 0): ?>
                            <form action="<?php echo e(route('admin.' . $crudRoutePart . '.destroy', $row->id)); ?>" method="POST"
                                onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                <input type="hidden" name="_method" value="DELETE">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <button type="submit" class="dropdown-item">
                                    <i class="fa fa-trash"></i> &nbsp; <?php echo e(trans('global.delete')); ?>

                                </button>
                            </form>
                        <?php endif; ?>
                    <?php break; ?>

                    <?php case ('admin.service-types.index'): ?>
                        <?php if(!$row->has('services')): ?>
                            <form action="<?php echo e(route('admin.' . $crudRoutePart . '.destroy', $row->id)); ?>" method="POST"
                                onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                <input type="hidden" name="_method" value="DELETE">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <button type="submit" class="dropdown-item">
                                    <i class="fa fa-trash"></i> &nbsp; <?php echo e(trans('global.delete')); ?>

                                </button>
                            </form>
                        <?php endif; ?>
                    <?php break; ?>

                    <?php case ('admin.memberships.index'): ?>
                        <?php if($row->status != 'refunded'): ?>
                            <form action="<?php echo e(route('admin.' . $crudRoutePart . '.destroy', $row->id)); ?>" method="POST"
                                onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                <input type="hidden" name="_method" value="DELETE">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <button type="submit" class="dropdown-item">
                                    <i class="fa fa-trash"></i> &nbsp; <?php echo e(trans('global.delete')); ?>

                                </button>
                            </form>
                        <?php endif; ?>
                    <?php break; ?>

                    <?php case ('admin.refunds.index'): ?>
                        <?php if($row->status == 'pending'): ?>
                            <form action="<?php echo e(route('admin.' . $crudRoutePart . '.destroy', $row->id)); ?>" method="POST"
                                onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                <input type="hidden" name="_method" value="DELETE">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <button type="submit" class="dropdown-item">
                                    <i class="fa fa-trash"></i> &nbsp; <?php echo e(trans('global.delete')); ?>

                                </button>
                            </form>
                        <?php endif; ?>
                    <?php break; ?>

                    <?php default: ?>
                        <form action="<?php echo e(route('admin.' . $crudRoutePart . '.destroy', $row->id)); ?>" method="POST"
                            onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                            <input type="hidden" name="_method" value="DELETE">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button type="submit" class="dropdown-item">
                                <i class="fa fa-trash"></i> &nbsp; <?php echo e(trans('global.delete')); ?>

                            </button>
                        </form>
                <?php endswitch; ?>
            <?php endif; ?>
        <?php endif; ?>

        <?php if(request()->route()->getName() == 'admin.memberships.index'): ?>
            <a href="<?php echo e(route('admin.memberships.manual_attend', $row->id)); ?>" class="dropdown-item">
                <i class="fas fa-fingerprint"></i>
                &nbsp; <?php echo e(trans('global.manual_attend')); ?>

            </a>

            <?php if($row->status == 'current' || $row->status == 'expiring' || $row->status == 'pending'): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('freeze_request_create')): ?>
                    <a href="<?php echo e(route('admin.membership.freezeRequests', $row->id)); ?>" class="dropdown-item">
                        <i class="fa fa-minus-circle"></i>
                        &nbsp; <?php echo e(trans('cruds.freezeRequest.title')); ?>

                    </a>
                <?php endif; ?>

                <?php
                    $a = date('Y-m-d', strtotime($row->start_date . '+ ' . $row->service_pricelist->upgrade_from . 'Days'));
                    $b = date('Y-m-d', strtotime($row->start_date . '+ ' . $row->service_pricelist->upgrade_to . 'Days'));
                ?>

                <?php if((date('Y-m-d') >= $a && date('Y-m-d') < $b) || (auth()->user()->roles[0]->title = 'Admin')): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('upgrade_membership')): ?>
                        <a href="<?php echo e(route('admin.membership.upgrade', $row->id)); ?>" class="dropdown-item">
                            <i class="fa fa-arrow-up"></i> &nbsp; <?php echo e(trans('cruds.membership.fields.upgrade')); ?>

                        </a>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('downgrade_membership')): ?>
                        <a href="<?php echo e(route('admin.membership.downgrade', $row->id)); ?>" class="dropdown-item">
                            <i class="fa fa-arrow-down"></i>
                            &nbsp; <?php echo e(trans('cruds.membership.fields.downgrade')); ?>

                        </a>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('transfer_membership')): ?>
                    <a href="<?php echo e(route('admin.membership.transfer', $row->id)); ?>" class="dropdown-item">
                        <i class="fa fa-exchange"></i>
                        <?php echo e(trans('global.transfer_membership')); ?>

                    </a>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($row->status == 'expiring' || $row->status == 'expired'): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('renew_membership')): ?>
                    <a href="<?php echo e(route('admin.membership.renew', $row->id)); ?>" class="dropdown-item">
                        <i class="fa fa-plus-circle"></i> &nbsp; <?php echo e(trans('cruds.membership.fields.renew')); ?>

                    </a>
                <?php endif; ?>
            <?php endif; ?>


            <?php if($row->invoice && $row->invoice->status !== 'refund'): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('refund_create')): ?>
                    <a href="<?php echo e(route('admin.invoice.refund', $row->invoice->id)); ?>" class="dropdown-item"> <i
                            class="fas fa-recycle"></i>
                        &nbsp; <?php echo e(trans('cruds.refund.title')); ?>

                    </a>
                <?php endif; ?>
            <?php endif; ?>

        <?php endif; ?>

        <?php if(request()->route()->getName() == 'admin.invoices.index'): ?>

            <a href="<?php echo e(route('admin.payments.index')); ?>?invoice_id=<?php echo e($row->id); ?>" class="dropdown-item">
                <i class="fa fa-money"></i>&nbsp;
                <?php echo e(trans('global.show') . ' ' . trans('cruds.payment.title')); ?>

            </a>

            



            

            <?php if($row->status !== 'refund'): ?>
                <a href="<?php echo e(route('admin.invoice.refund', $row->id)); ?>" class="dropdown-item"><i
                        class="fas fa-exchange-alt"></i>
                    &nbsp; <?php echo e(trans('cruds.refund.title')); ?></a>
            <?php endif; ?>

            <?php if(config('domains')[config('app.url')]['is_reviewed_invoices'] == true): ?>
                <a href="javascript:void(0)" onclick="getInvoiceDetails(this)" data-toggle="modal"
                    data-target="#updateInvoiceReviewedStatusModal"
                    data-url="<?php echo e(route('admin.invoice-reviewed-status.update', $row->id)); ?>" class="dropdown-item"><i
                        class="fas fa-check-circle"></i>
                    &nbsp; <?php echo e($row->is_reviewed ? trans('global.not_reviewed') : trans('global.is_reviewed')); ?></a>
            <?php endif; ?>

            <?php if($row->status == 'partial'): ?>
                <a href="javascript:void(0)" onclick="setSettlementInvoice(this)" data-toggle="modal"
                    data-target="#settlement_invoice" data-url="<?php echo e(route('admin.settlement.invoice', $row->id)); ?>"
                    class="dropdown-item"><i class="fas fa-check-circle"></i> &nbsp;
                    <?php echo e(trans('global.settlement')); ?></a>
            <?php endif; ?>
        <?php endif; ?>

        <?php if(request()->route()->getName() == 'admin.accounts.index'): ?>
            <a href="<?php echo e(route('admin.account.statement', $row->id)); ?>" class="dropdown-item"><i
                    class="fa fa-file"></i>
                &nbsp; <?php echo e(trans('cruds.account.fields.statement')); ?></a>

            <a href="<?php echo e(route('admin.account.transfer', $row->id)); ?>" class="dropdown-item">
                <i class="fa fa-recycle"></i>
                &nbsp; <?php echo e(trans('global.transfer')); ?>

            </a>
        <?php endif; ?>

        <?php if(request()->route()->getName() == 'admin.refunds.index'): ?>
            <?php if($row->status == 'approved'): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('approve_reject_refund')): ?>
                    <form action="<?php echo e(route('admin.refund.confirm', $row->id)); ?>" method="POST"
                        onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                        <input type="hidden" name="_method" value="PUT">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <button type="submit" class="dropdown-item">
                            <i class="fa fa-check"></i> &nbsp; <?php echo e(trans('global.confirm')); ?>

                        </button>
                    </form>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($row->status == 'pending'): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('approve_reject_refund')): ?>
                    <form action="<?php echo e(route('admin.refund.approve', $row->id)); ?>" method="POST"
                        onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                        <input type="hidden" name="_method" value="PUT">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <button type="submit" class="dropdown-item">
                            <i class="fa fa-check"></i> &nbsp; <?php echo e(trans('global.approve')); ?>

                        </button>
                    </form>

                    <form action="<?php echo e(route('admin.refund.reject', $row->id)); ?>" method="POST"
                        onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                        <input type="hidden" name="_method" value="PUT">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <button type="submit" class="dropdown-item">
                            <i class="fa fa-times"></i> &nbsp;<?php echo e(trans('global.reject')); ?>

                        </button>
                    </form>
                <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>

        <?php if(request()->route()->getName() == 'admin.freeze-requests.index'): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('approve_reject_freeze')): ?>
                <?php if($row->status == 'pending'): ?>
                    <form action="<?php echo e(route('admin.freeze-requests.confirm', $row->id)); ?>" method="POST"
                        onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                        <input type="hidden" name="_method" value="PUT">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <button type="submit" class="dropdown-item">
                            <i class="fa fa-check"></i> &nbsp; <?php echo e(trans('global.confirm')); ?>

                        </button>
                    </form>

                    <form action="<?php echo e(route('admin.freeze-requests.reject', $row->id)); ?>" method="POST"
                        onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                        <input type="hidden" name="_method" value="PUT">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <button type="submit" class="dropdown-item">
                            <i class="fa fa-times"></i> &nbsp;<?php echo e(trans('global.reject')); ?>

                        </button>
                    </form>
                <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>

        <?php if(request()->route()->getName() == 'admin.membership-attendances.index'): ?>
            <a class="dropdown-item" data-target="#editSigninAndSignoutModal" data-toggle="modal"
                href="javascript:void(0)" onclick="editSigninAndSignout(this)" data-locker="<?php echo e($row->locker); ?>"
                data-sign-in="<?php echo e($row->sign_in); ?>" data-sign-out="<?php echo e($row->sign_out); ?>"
                data-update="<?php echo e(route('admin.membership-attendances.update', $row->id)); ?>"
                data-get-url="<?php echo e(route('admin.membership-attendances.edit', $row->id)); ?>">
                <i class="fa fa-edit"></i> &nbsp;
                <?php echo e(trans('global.edit_sign_in_and_out')); ?>

            </a>
        <?php endif; ?>

        <?php if(request()->route()->getName() == 'admin.employees.index'): ?>
            <form action="<?php echo e(route('admin.employees.change_status', $row->id)); ?>" method="POST"
                onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                <input type="hidden" name="_method" value="PUT">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <button type="submit" class="dropdown-item">
                    <?php echo $row->status == 'active'
                        ? '<i class="fa fa-times-circle"></i> &nbsp; Inactive '
                        : '<i class="fa fa-check-circle"></i> &nbsp; Active '; ?>

                </button>
            </form>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH E:\projects\gymapp\resources\views/partials/datatablesActions.blade.php ENDPATH**/ ?>