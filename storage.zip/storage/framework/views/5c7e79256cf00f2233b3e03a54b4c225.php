    <?php if(config('domains')[config('app.url')]['employees_schedule'] == true): ?>
        <?php echo $__env->make('partials.schedule', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <h4><i class="fas fa-bullseye"></i> <?php echo e(trans('global.sales_achievements')); ?></h4>
    <?php if(isset(Auth()->user()->sales_tier->sales_tier)): ?>
        <div class="row">
            <div class="col-sm-6 col-lg-3">
                <div class="card">
                    <div class="card-body bg-success text-white text-center">
                        <div>
                            <h5 class="fs-4 fw-semibold"><?php echo e(number_format($target) . ' EGP'); ?></h5>
                            <h5> <?php echo e(trans('global.target')); ?></h5>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-lg-3">
                <div class="card">
                    <div class="card-body bg-primary text-white text-center">
                        <div>
                            <a href="<?php echo e(route('admin.reports.sales-report.view', Auth::user()->id)); ?>"
                                style="color:white;">
                                <h5 class="fs-4 fw-semibold"> <?php echo e(number_format($achieved) . ' EGP'); ?>

                                    (<?php echo e($achieved_per); ?>%)
                                </h5>
                            </a>
                            <h5><?php echo e(trans('global.achieved')); ?></h5>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-lg-3">
                <div class="card">
                    <div class="card-body bg-warning text-white text-center">
                        <div>
                            <h5 class="fs-4 fw-semibold"><?php echo e($pendingTarget . ' EGP' ?? 0); ?></h5>
                            <h5> <?php echo e(trans('global.pending')); ?></h5>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-lg-3">
                <div class="card">
                    <div class="card-body bg-success text-white text-center">
                        <div>
                            <h5 class="fs-4 fw-semibold"><?php echo e(number_format($sales_commission) ?? 0); ?> EGP
                                (<?php echo e($sales_commission_per ?? 0); ?>%)</h5>
                            <h5> <?php echo e(trans('global.commission')); ?></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <h5>Please ask admin to add sales tires to show achieved charts ! </h5>
    <?php endif; ?>

    <hr>

    <h4><i class="fa fa-bell"></i> <?php echo e(trans('cruds.reminder.title')); ?></h4>
    <div class="row">
        <div class="col-sm-6 col-lg-4">
            <a href="<?php echo e(route('admin.reminders.index')); ?>" class="text-decoration-none" target="_blank">
                <div class="card ">
                    <div class="card-body bg-success text-white text-center">
                        <h5 class="fs-4 fw-semibold"><?php echo e($today_reminders->count()); ?></h5>
                        <i class="fa fa-bell"></i>
                        <?php echo e(trans('global.today_reminders')); ?></h5>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-sm-6 col-lg-4">
            <div class="card ">
                <a href="<?php echo e(route('admin.reminders.upcomming', ['due_date[from]' => date('Y-m-01'), 'due_date[to]' => date('Y-m-t')])); ?>"
                    class="text-decoration-none" target="_blank">
                    <div class="card-body bg-warning text-white text-center">
                        <h5 class="fs-4 fw-semibold"><?php echo e($upcomming_reminders->count()); ?></h5>
                        <i class="fa fa-bell"></i>
                        <?php echo e(trans('cruds.reminder.fields.upcomming_reminders')); ?></h5>
                    </div>
                </a>
            </div>
        </div>

        <div class="col-sm-6 col-lg-4">
            <div class="card ">
                <a href="<?php echo e(route('admin.reminders.overdue')); ?>" class="text-decoration-none" target="_blank">
                    <div class="card-body bg-danger text-white text-center">
                        <h5 class="fs-4 fw-semibold"><?php echo e($overdue_reminders->count()); ?></h5>
                        <i class="fa fa-bell"></i>
                        <?php echo e(trans('cruds.reminder.fields.overdue_remiders')); ?></h5>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <hr>

    <div class="row">

        <div class="col-sm-6">
            <div class="card">
                <div class="card-body bg-info text-white text-center">
                    <div>
                        <h5 class="fs-4 fw-semibold"> <?php echo e($monthly_memberships); ?></h5>
                        <h5><i class="fa fa-users"></i> <?php echo e(trans('global.monthly_memberships')); ?></h5>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6">
            <a href="<?php echo e(route('admin.invoice.duePayments', Auth()->user()->id)); ?>" class="text-decoration-none">
                <div class="card">
                    <div class="card-body bg-info text-white text-center">
                        <div>
                            <h5 class="fs-4 fw-semibold"> <?php echo e($duePayments->sum('rest')); ?>

                                (<?php echo e($duePayments->count()); ?>)</h5>
                            <h5><i class="fa fa-users"></i> <?php echo e(trans('global.due_payment')); ?></h5>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </div>

    <?php if($latest_leads->isNotEmpty()): ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="nav nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                            <?php $__currentLoopData = $latest_leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="nav-link <?php echo e($loop->iteration == 1 ? 'active' : ''); ?>"
                                    id="<?php echo e(str_replace(' ', '_', $key)); ?>-tab" data-toggle="pill"
                                    href="#<?php echo e(str_replace(' ', '_', $key)); ?>" role="tab"
                                    aria-controls="<?php echo e(str_replace(' ', '_', $key)); ?>" aria-selected="true">
                                    <?php echo e($key); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="tab-content" id="v-pills-tabContent">
                            <?php $__currentLoopData = $latest_leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tab-pane fade <?php echo e($loop->iteration == 1 ? 'show active' : ''); ?>"
                                    id="<?php echo e(str_replace(' ', '_', $key)); ?>" role="tabpanel"
                                    aria-labelledby="<?php echo e($key); ?>-tab">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <table
                                                class="table table-bordered table-striped table-hover zero-configuration">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Name</th>
                                                        <th>Type</th>
                                                        <th>Sales By</th>
                                                        <th>Source</th>
                                                        <th>Membership</th>
                                                        <th>Paid</th>
                                                        <th>Rest</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <tr>
                                                            <td><?php echo e($loop->iteration); ?></td>
                                                            <td>
                                                                <a href="<?php echo e($lead->type == 'member' ? route('admin.members.show', $lead->id) : route('admin.leads.show', $lead->id)); ?>"
                                                                    target="_blank">
                                                                    <?php echo e($lead->last_membership ? App\Models\Setting::first()->member_prefix . $lead->member_code : ' '); ?>

                                                                    <br>
                                                                    <?php echo e($lead->name); ?> <br>
                                                                    <?php echo e($lead->phone); ?> <br>
                                                                </a>
                                                            </td>
                                                            <td><?php echo e($lead->type); ?></td>
                                                            <td>
                                                                <?php echo e($lead->sales_by->name ?? '-'); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e($lead->source->name ?? '-'); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e($lead->last_membership->service_pricelist->name ?? '-'); ?>

                                                                <br>
                                                                <?php echo e($lead->last_membership ? number_format($lead->last_membership->invoice->net_amount) : ' '); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e($lead->last_membership ? number_format($lead->last_membership->invoice->payments->sum('amount')) : 0); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e($lead->last_membership ? number_format($lead->last_membership->invoice->rest) : '-'); ?>

                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        NOT FOUND 2
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if($reminders_sources->isNotEmpty()): ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="nav nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                            <?php $__currentLoopData = $reminders_sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $reminder_sources): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="nav-link <?php echo e($loop->iteration == 1 ? 'active' : ''); ?>"
                                    id="source_<?php echo e(str_replace(' ', '_', $key)); ?>-tab" data-toggle="pill"
                                    href="#source_<?php echo e(str_replace(' ', '_', $key)); ?>" role="tab"
                                    aria-controls="source_<?php echo e(str_replace(' ', '_', $key)); ?>" aria-selected="true">
                                    <?php echo e($key); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="tab-content" id="v-pills-tabContent">
                            <?php $__currentLoopData = $reminders_sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $reminder_sources): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tab-pane fade <?php echo e($loop->iteration == 1 ? 'show active' : ''); ?>"
                                    id="source_<?php echo e(str_replace(' ', '_', $key)); ?>" role="tabpanel"
                                    aria-labelledby="<?php echo e($key); ?>-tab">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <table
                                                class="table table-bordered table-striped table-hover zero-configuration">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>
                                                            <?php echo e(trans('cruds.lead.title_singular')); ?>

                                                        </th>
                                                        <th>
                                                            <?php echo e(trans('global.type')); ?>

                                                        </th>
                                                        <th>
                                                            <?php echo e(trans('cruds.action.title_singular')); ?>

                                                        </th>
                                                        <th>
                                                            <?php echo e(trans('global.details')); ?>

                                                        </th>
                                                        <th>
                                                            <?php echo e(trans('global.due_date')); ?>

                                                        </th>
                                                        <th><?php echo e(trans('global.notes')); ?></th>
                                                        <th><?php echo e(trans('global.action_date')); ?></th>
                                                        <th><?php echo e(trans('global.action')); ?></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $reminder_sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reminder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($loop->iteration); ?></td>
                                                            <td>
                                                                <?php if($reminder->lead->type == 'member'): ?>
                                                                    <a href="<?php echo e(route('admin.members.show', $reminder->lead_id)); ?>"
                                                                        target="_blank" class="text-decoration-none">
                                                                        <?php echo e(\App\Models\Setting::first()->member_prefix . $reminder->lead->member_code ?? '-'); ?>

                                                                        <span class="d-block">
                                                                            <?php echo e($reminder->lead->name); ?>

                                                                        </span>
                                                                        <span class="d-block">
                                                                            <?php echo e($reminder->lead->phone); ?>

                                                                        </span>
                                                                    </a>
                                                                <?php else: ?>
                                                                    <a href="<?php echo e(route('admin.leads.show', $reminder->lead_id)); ?>"
                                                                        target="_blank" class="text-decoration-none">
                                                                        <span class="d-block">
                                                                            <?php echo e($reminder->lead->name); ?>

                                                                        </span>
                                                                        <span class="d-block">
                                                                            <?php echo e($reminder->lead->phone); ?>

                                                                        </span>
                                                                    </a>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <?php echo e(\App\Models\Reminder::TYPE[$reminder->type] ?? ''); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e(\App\Models\Reminder::ACTION[$reminder->action] ?? ''); ?>

                                                            </td>
                                                            <td>
                                                                <span class="d-block">
                                                                    <?php echo e($reminder->membership->service_pricelist->name ?? '-'); ?>

                                                                </span>
                                                                <?php if($reminder->type == 'due_payment'): ?>
                                                                    <span class="d-block">
                                                                        <?php echo e(trans('global.total')); ?> :
                                                                        <?php echo e($reminder->membership->invoice->net_amount ?? 0); ?>

                                                                    </span>
                                                                    <span class="d-block">
                                                                        Paid :
                                                                        <?php echo e($reminder->membership->invoice->payments_sum_amount ?? 0); ?>

                                                                    </span>
                                                                    <span class="d-block">
                                                                        <?php echo e(trans('global.rest')); ?> :
                                                                        <?php echo e($reminder->membership->invoice->rest ?? 0); ?>

                                                                    </span>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td><?php echo e($reminder->due_date ?? ''); ?></td>
                                                            <td><?php echo e($reminder->notes); ?></td>
                                                            <td><?php echo e($reminder->created_at); ?></td>
                                                            <td>
                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reminder_delete')): ?>
                                                                    <form
                                                                        action="<?php echo e(route('admin.reminderHistory.destroy', $reminder->id)); ?>"
                                                                        method="post"
                                                                        onsubmit="return confirm('Are you sure?');"
                                                                        style="display: inline-block;">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('DELETE'); ?>
                                                                        <button class="btn btn-danger btn-sm"
                                                                            type="submit">
                                                                            <i class="fa fa-trash"></i>
                                                                            <?php echo e(trans('global.delete')); ?>

                                                                        </button>
                                                                    </form>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><?php /**PATH E:\projects\gymapp\resources\views/dashboard/sales.blade.php ENDPATH**/ ?>