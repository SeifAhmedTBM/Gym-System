<?php $__env->startSection('content'); ?>
    
    <div class="form-group">
        <div class="card">
            <div class="card-header">
                <?php echo e($branch->name); ?> Sources
            </div>
            <div class="card-body">
                <table class="table table-striped table-hover table-bordered zero-configuration">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Source</th>
                            <th>Leads</th>
                            <th>Members</th>
                            <th>Percentage</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($source->name); ?></td>
                                <td><?php echo e($source->leads_count); ?></td>
                                <td><?php echo e($source->members_count); ?></td>
                                <td><?php echo e($source->members_count > 0 ? number_format(($source->members_count / $source->leads_count) * 100,2).' %' : '0 %'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    

    
    <div class="form-group">
        <div class="card">
            <div class="card-header">
                <?php echo e($branch->name); ?> Due Payments
            </div>
            <div class="card-body">
                <table class="table table-striped table-hover table-bordered zero-configuration text-center">
                    <thead class="thead-light">
                        <tr>
                            <th class="text-dark">#</th>
                            <th class="text-dark"><?php echo e(trans('global.name')); ?></th>
                            <th class="text-dark">Total Collected</th>
                            <th class="text-dark">Total Remaining</th>
                            <th class="text-dark"><?php echo e(trans('global.count')); ?></th>
                            <th class="text-dark"><?php echo e(trans('global.actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                
                                <td class="font-weight-bold"><?php echo e($loop->iteration); ?></td>
                                <td class="font-weight-bold"><?php echo e($sale->name ?? '-'); ?></td>
                                <td class="font-weight-bold"><?php echo e(number_format($sale->payments->sum('amount')) ?? 0); ?> EGP (<?php echo e($sale->payments->count()); ?>) EGP</td>
                                <!-- <td class="font-weight-bold"><?php echo e(number_format($sale->invoices->sum('rest'))); ?> EGP</td> -->
                                <td class="font-weight-bold"><?php echo e($sale->invoices_count); ?></td>
                                <td class="font-weight-bold">
                                    <a href="<?php echo e(route('admin.invoice.duePayments',$sale->id)); ?>" class="btn font-weight-bold btn-primary btn-sm">
                                        <i class="fa fa-eye"></i> <?php echo e(trans('cruds.invoice.title')); ?>

                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\gymapp\resources\views/admin/reports/sales_details.blade.php ENDPATH**/ ?>