
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <?php echo e(trans('global.attendance_data')); ?> | <?php echo e(Auth()->user()->employee && Auth()->user()->employee->branch_id ? Auth()->user()->employee->branch->name : ''); ?>

            </div>
            <div class="card-body">
                <?php if(Session::has('user_invalid')): ?>
                    <div class="alert alert-danger font-weight-bold text-center">
                       <i class="fa fa-user-times"></i> <?php echo e(session('user_invalid')); ?>

                    </div>
                <?php endif; ?>
                <?php if(\App\Models\Setting::first()->has_lockers): ?>
                    <div class="row form-group">
                        <div class="col-12">
                            <label for=""><?php echo e(trans('global.take_attendance')); ?></label>
                            <input type="hidden" name="membership_id" value="">
                            <input type="hidden" name="member_id" value="">
                            <input type="hidden" name="branch_id" value="<?php echo e(Auth()->user()->employee && Auth()->user()->employee->branch_id ? Auth()->user()->employee->branch_id : NULL); ?>">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <select name="member_branch_id" id="member_branch_id" class="form-control">
                                        <?php $__currentLoopData = \App\Models\Branch::pluck('member_prefix','id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($id); ?>" <?php echo e(Auth()->user()->employee &&  Auth()->user()->employee->branch_id == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <input type="text" class="form-control" name="card_number" value="" id="member_code" autofocus ondragenter="getMember()" onfocus="this.setSelectionRange(this.value.length,this.value.length);">
                            </div>
                        </div>
                    </div>
                    <br>
                    
                <?php else: ?>
                    <form action="<?php echo e(route('admin.take.attend')); ?>" method="post" id="memberAttendanceForm">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="row form-group">
                            <div class="col-12">
                                <label for=""><?php echo e(trans('global.take_attendance')); ?></label>
                                <input type="hidden" name="membership_id" value="">
                                <input type="hidden" name="member_id" value="">
                                <input type="hidden" name="branch_id" value="<?php echo e(Auth()->user()->employee && Auth()->user()->employee->branch_id ? Auth()->user()->employee->branch_id : NULL); ?>">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <select name="member_branch_id" id="member_branch_id" class="form-control">
                                            <?php $__currentLoopData = \App\Models\Branch::pluck('member_prefix','id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($id); ?>" <?php echo e(Auth()->user()->employee &&  Auth()->user()->employee->branch_id == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <input type="text" class="form-control" name="card_number" value="" id="member_code" autofocus  ondragenter="getMember()" onfocus="this.setSelectionRange(this.value.length,this.value.length);" >
                                </div>
                            </div>
                        </div>
                    </form>
                    
                <?php endif; ?>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\projects\Gym-System\resources\views/partials/profile_attendance.blade.php ENDPATH**/ ?>