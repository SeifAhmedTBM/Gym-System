
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h5><?php echo e(trans('global.show')); ?> Task</h5>
        </div>

        <div class="card-body">
            <div class="form-group">
                <div class="form-group">
                    <a class="btn btn-default" href="<?php echo e(route('admin.tasks.index')); ?>">
                        <?php echo e(trans('global.back_to_list')); ?>

                    </a>
                </div>
                <table class="table table-bordered table-striped">
                    <tbody>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.source.fields.id')); ?>

                            </th>
                            <td>
                                <?php echo e($task->id); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                Title
                            </th>
                            <td>
                                <?php echo e($task->title ?? 'N/D'); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                Description
                            </th>
                            <td>
                                <?php echo $task->description ?? 'N/D'; ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                To User
                            </th>
                            <td>
                                <?php echo e($task->to_user->name ?? 'N/D'); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                To Role
                            </th>
                            <td>
                                <?php echo e($task->to_role->title ?? 'N/D'); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                Status
                            </th>
                            <td>
                                <?php echo e($task->status ?? 'N/D'); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                Task Date
                            </th>
                            <td>
                                <?php echo e($task->task_date ?? 'N/D'); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                Done
                            </th>
                            <td>
                                <?php echo e($task->done_at ?? 'N/D'); ?>

                            </td>
                        </tr>

                        <tr>
                            <th>
                                Created At
                            </th>
                            <td>
                                <?php echo e($task->created_at ?? 'N/D'); ?>

                            </td>
                        </tr>

                    </tbody>
                </table>
                <div class="form-group">
                    <a class="btn btn-default" href="<?php echo e(route('admin.tasks.index')); ?>">
                        <?php echo e(trans('global.back_to_list')); ?>

                    </a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Gym-System\resources\views/admin/tasks/show.blade.php ENDPATH**/ ?>