    

    <?php if(config('domains')[config('app.url')]['timeline_schedule'] == true): ?>
    <h4><i class="fa fa-calendar"></i> <?php echo e(trans('global.schedule_timeline')); ?></h4>
    <?php echo $__env->make('partials.schedule', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>


    <?php if(config('domains')[config('app.url')]['profile_attendance_dashboard'] == true): ?>
        <?php echo $__env->make('partials.profile_attendance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <h4><i class="fa fa-money"></i> <?php echo e(trans('cruds.finance.title')); ?></h4>
    <?php if(isset($daily_income)): ?>
        <div class="row py-2">
            <div class="col-sm-6 col-lg-4">
                <a href="<?php echo e(route('admin.invoices.index', ['created_at' => ['from' => date('Y-m-d')]])); ?>"
                    class="text-decoration-none text-white">
                    <div class="card">
                        <div class="card-body bg-primary text-white text-center">
                            <h5 class="fs-4 fw-semibold"><?php echo e(number_format($daily_income)); ?> EGP</h5>
                            <h5><i class="fa fa-money"></i>
                                <?php echo e(trans('global.daily_income')); ?></h5>
                        </div>
                    </div>
                </a>
            </div>
            <!-- /.col-->

            <div class="col-sm-6 col-lg-4">
                <a href="<?php echo e(route('admin.expenses.index', ['created_at' => ['from' => date('Y-m-d')]])); ?>"
                    class="text-decoration-none text-white">
                    <div class="card">
                        <div class="card-body bg-danger text-white text-center">
                            <h5 class="fs-4 fw-semibold"><?php echo e($daily_outcome); ?> EGP</h5>
                            <h5><i class="fa fa-money"></i>
                                <?php echo e(trans('global.daily_outcome')); ?></h5>
                        </div>
                    </div>
                </a>
            </div>
            <!-- /.col-->

            <div class="col-sm-6 col-lg-4">
                <div class="card ">
                    <div class="card-body bg-success text-white text-center">
                        <h5 class="fs-4 fw-semibold"><?php echo e($daily_net); ?> EGP</h5>
                        <h5><i class="fa fa-money"></i>
                            <?php echo e(trans('global.daily_total')); ?></h5>
                    </div>
                </div>
            </div>
            <!-- /.col-->
        </div>
    <?php endif; ?>

    <?php if(isset($monthly_income)): ?>
        <div class="row">
            <div class="col-sm-6 col-lg-4">
                <div class="card ">
                    <div class="card-body bg-primary text-white text-center">
                        <h5 class="fs-4 fw-semibold"><?php echo e(number_format($monthly_income)); ?> EGP</h5>
                        <h5><i class="fa fa-dollar"></i>
                            <?php echo e(trans('global.monthly_income')); ?> </h5>
                    </div>
                </div>
            </div>
            <!-- /.col-->

            <div class="col-sm-6 col-lg-4">
                <div class="card ">
                    <div class="card-body bg-danger text-white text-center">
                        <h5 class="fs-4 fw-semibold"><?php echo e(number_format($monthly_outcome)); ?> EGP</h5>
                        <h5><i class="fa fa-dollar"></i>
                            <?php echo e(trans('global.monthly_outcome')); ?></h5>
                    </div>
                </div>
            </div>
            <!-- /.col-->

            <div class="col-sm-6 col-lg-4">
                <div class="card ">
                    <div class="card-body bg-success text-white text-center">
                        <h5 class="fs-4 fw-semibold"><?php echo e(number_format($monthly_net)); ?> EGP</h5>
                        <h5><i class="fa fa-dollar"></i>
                            <?php echo e(trans('global.monthly_total')); ?></h5>
                    </div>
                </div>
            </div>
            <!-- /.col-->
        </div>
    <?php endif; ?>

    <hr>

    <?php if(isset($monthly_income) && $total_targets > 0): ?>
        <h4><i class="fas fa-bullseye"></i> <?php echo e(trans('global.sales_achievements')); ?></h4>
        <div class="row py-4">
            <div class="col-sm-6 col-lg-4">
                <div class="card ">
                    <div class="card-body  text-center">
                        <h5 class="fs-4 fw-semibold">
                            <?php echo e(number_format($total_targets)); ?> EGP
                        </h5>
                        <?php echo e(trans('global.sales_target')); ?></h5>
                    </div>
                </div>
            </div>
            <!-- /.col-->

            <div class="col-sm-6 col-lg-4">
                <div class="card ">
                    <div class="card-body  text-center">
                        <h5 class="fs-4 fw-semibold">
                            <?php echo e(number_format($monthly_income)); ?> EGP ( <?php echo e(( round(($monthly_income / $total_targets ) * 100, 2))); ?> % )
                        </h5>
                        <?php echo e(trans('global.sales_achievements')); ?></h5>
                    </div>
                </div>
            </div>
            <!-- /.col-->

            <div class="col-sm-6 col-lg-4">
                <div class="card ">
                    <div class="card-body  text-center">
                        <h5 class="fs-4 fw-semibold">
                            <?php echo e(number_format($total_targets - $monthly_income)); ?> EGP ( <?php echo e(( round((($total_targets - $monthly_income) / $total_targets ) * 100, 2))); ?> % )
                        </h5>
                        <?php echo e(trans('global.rest')); ?></h5>
                    </div>
                </div>
            </div>
            <!-- /.col-->
        </div>
    <?php endif; ?>

    <hr>

    <h4><i class="fa fa-bell"></i> <?php echo e(trans('cruds.reminder.title')); ?></h4>
    <div class="row">
        <div class="col-sm-6 col-lg-4">
            <a href="<?php echo e(route('admin.reports.reminders')); ?>" class="text-decoration-none">
                <div class="card ">
                    <div class="card-body bg-info text-white text-center">
                        <h5 class="fs-4 fw-semibold"><?php echo e($today_reminders->count()); ?></h5>
                        <i class="fa fa-bell"></i>
                        <?php echo e(trans('global.today_reminders')); ?></h5>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-sm-6 col-lg-4">
            <a href="<?php echo e(route('admin.reports.reminders')); ?>" class="text-decoration-none">
                <div class="card ">
                    <div class="card-body bg-info text-white text-center">
                        <h5 class="fs-4 fw-semibold"><?php echo e($upcomming_reminders->count()); ?></h5>
                        <i class="fa fa-bell"></i>
                        <?php echo e(trans('cruds.reminder.fields.upcomming_reminders')); ?></h5>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-sm-6 col-lg-4">
            <a href="<?php echo e(route('admin.reports.reminders')); ?>" class="text-decoration-none">
                <div class="card ">
                    <div class="card-body bg-info text-white text-center">
                        <h5 class="fs-4 fw-semibold"><?php echo e($overdue_reminders->count()); ?></h5>
                        <i class="fa fa-bell"></i>
                        <?php echo e(trans('cruds.reminder.fields.overdue_remiders')); ?></h5>
                    </div>
                </div>
            </a>
        </div>
    </div>

    <hr>

    

    

    

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5><i class="fa fa-recycle"></i> <?php echo e(trans('cruds.transactions.title')); ?>

                        <?php echo e(trans('global.list')); ?></h5>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class=" table table-bordered table-striped table-hover datatable datatable-statement">
                            <thead>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.transactions.fields.id')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(trans('cruds.transactions.fields.account')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(trans('cruds.transactions.fields.type')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(trans('cruds.lead.fields.notes')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(trans('cruds.transactions.fields.amount')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(trans('cruds.transactions.fields.created_by')); ?>

                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr
                                        class="<?php echo e(\App\Models\Transaction::color[$transaction->transactionable_type]); ?>">
                                        <td>
                                            <?php echo e($loop->iteration); ?>

                                        </td>
                                        <td>
                                            <?php echo e($transaction->account->name ?? ''); ?>

                                        </td>
                                        <td>
                                            <?php echo e(\App\Models\Transaction::type[$transaction->transactionable_type]); ?>

                                        </td>
                                        <td>
                                            <?php switch(\App\Models\Transaction::type[$transaction->transactionable_type]):
                                                case ('Expenses'): ?>
                                                    <a href="<?php echo e(route('admin.expenses.show',$transaction->transactionable_id)); ?>">
                                                        <?php echo e($transaction->transactionable_type::find($transaction->transactionable_id)->name); ?>

                                                    </a>
                                                    <?php break; ?>
                                                <?php case ('Refunds'): ?>
                                                    <a href="<?php echo e(route('admin.refunds.show',$transaction->transactionable_id)); ?>">
                                                        <?php echo e(App\Models\Setting::first()->invoice_prefix.' '.$transaction->transactionable_type::find($transaction->transactionable_id)->invoice_id); ?></a>
                                                    <?php break; ?>
                                                <?php case ('External Payments'): ?>
                                                    <a href="<?php echo e(route('admin.external-payments.show',$transaction->transactionable_id)); ?>">
                                                        <?php echo e($transaction->transactionable_type::find($transaction->transactionable_id)->title); ?>

                                                    </a>
                                                    <?php break; ?>
                                                <?php case ('Payments'): ?>
                                                    <a href="<?php echo e(route('admin.invoices.show',$transaction->transactionable_type::find($transaction->transactionable_id)->invoice_id)); ?>">
                                                        <?php echo e(App\Models\Setting::first()->invoice_prefix.' '.$transaction->transactionable_type::find($transaction->transactionable_id)->invoice_id); ?>

                                                    </a>
                                                    <?php break; ?>
                                                <?php case ('Withdrawal'): ?>
                                                    <a href="<?php echo e(route('admin.withdrawals.show',$transaction->transactionable_id)); ?>">
                                                        <?php echo e($transaction->transactionable_type::find($transaction->transactionable_id)->notes); ?>

                                                    </a>
                                                    <?php break; ?>

                                                <?php case ('Transfer'): ?>
                                                    <?php echo e(trans('global.from')); ?>

                                                    <?php echo e($transaction->transactionable_type::find($transaction->transactionable_id)->fromAccount->name ?? '-'); ?>

                                                    <?php echo e(trans('global.to')); ?>

                                                    <?php echo e($transaction->transactionable_type::find($transaction->transactionable_id)->toAccount->name ?? '-'); ?>

                                                    <?php break; ?>
                                                <?php default: ?>

                                            <?php endswitch; ?>
                                        </td>
                                        <td>
                                            <?php echo e($transaction->amount ?? ''); ?>

                                        </td>
                                        <td>
                                            <?php echo e($transaction->createdBy->name ?? ''); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <td colspan="6" class="text-center"><?php echo e(trans('global.no_data_available')); ?></td>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="card shadow-sm" style="display: none;">
        <div class="card-header">
            <h5><i class="fa fa-user"></i> <?php echo e(trans('global.attendance_data')); ?></h5>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-hover text-center zero-configuration">
                <thead class="thead-light">
                    <tr>
                        <th>#</th>
                        <th><?php echo e(trans('cruds.member.fields.photo')); ?></th>
                        <th>
                            <?php echo e(trans('cruds.lead.fields.member_code')); ?>

                        </th>
                        <th><?php echo e(trans('global.name')); ?></th>
                        <th><?php echo e(trans('cruds.service.title_singular')); ?></th>
                        <th><?php echo e(trans('cruds.membershipAttendance.fields.sign_in')); ?></th>
                        <?php if(isset(\App\Models\Setting::first()->has_lockers) && \App\Models\Setting::first()->has_lockers == true): ?>
                            <th><?php echo e(trans('cruds.membershipAttendance.fields.sign_out')); ?></th>
                        <?php endif; ?>
                        <th><?php echo e(trans('global.end_date')); ?></th>
                        <th><?php echo e(trans('global.attendance_count')); ?></th>
                        <th><?php echo e(trans('cruds.status.title_singular')); ?></th>
                        <?php if(isset(\App\Models\Setting::first()->has_lockers) && \App\Models\Setting::first()->has_lockers == true): ?>
                            <th><?php echo e(trans('cruds.locker.title_singular')); ?></th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $today_attendants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php if($attendant->membership->member->photo): ?>
                                    <a href="<?php echo e($attendant->membership->member->photo->getUrl()); ?>" target="_blank"
                                        style="display: inline-block">
                                        <img src="<?php echo e($attendant->membership->member->photo->getUrl()); ?>"
                                            class="rounded-circle" style="width: 50px;height:50px">
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(asset('images/user.png')); ?>" target="_blank"
                                        style="display: inline-block">
                                        <img src="<?php echo e(asset('images/user.png')); ?>" class="rounded-circle"
                                            style="width: 50px;height:50px">
                                    </a>
                                <?php endif; ?>
                            </td>
                            <td class="font-weight-bold">
                                <a href="<?php echo e(route('admin.members.show', $attendant->membership->member->id)); ?>"
                                    target="_blank">
                                    <?php echo e(\App\Models\Setting::first()->member_prefix . $attendant->membership->member->member_code); ?>

                                </a>
                            </td>
                            <td class="font-weight-bold">
                                <a href="<?php echo e(route('admin.members.show', $attendant->membership->member->id)); ?>"
                                    target="_blank">
                                    <?php echo e($attendant->membership->member->name); ?>

                                </a>
                            </td>
                            <td>
                                <?php echo e($attendant->membership->service_pricelist->name ?? '-'); ?>

                            </td>
                            <td><?php echo e(date('g:i A', strtotime($attendant->sign_in))); ?></td>
                            <?php if(isset(\App\Models\Setting::first()->has_lockers) && \App\Models\Setting::first()->has_lockers == true): ?>
                                <td><?php echo e(date('g:i A', strtotime($attendant->sign_out))); ?></td>
                            <?php endif; ?>
                            <td>
                                <?php echo e($attendant->membership->end_date ?? '-'); ?>

                            </td>
                            <td>
                                <?php echo e(($attendant->membership->service_pricelist->service->service_type->session_type == "sessions") || ($attendant->membership->service_pricelist->service->service_type->session_type == "group_sessions") ? $attendant->membership->attendances_count ."/".$attendant->membership->service_pricelist->session_count : $attendant->membership->attendances_count); ?>

                            </td>
                            <th>
                                <span
                                    class="badge badge-<?php echo e(\App\Models\Membership::STATUS[$attendant->membership_status]); ?> p-2">
                                    <i class="fa fa-recycle"></i> <?php echo e(ucfirst($attendant->membership_status ) ?? '-'); ?>

                                </span>
                            </th>
                            <?php if(isset(\App\Models\Setting::first()->has_lockers) && \App\Models\Setting::first()->has_lockers == true): ?>
                                <th>
                                    <?php echo $attendant->locker ?? '<span class="badge badge-danger">No locker</span>'; ?>

                                </th>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8"><?php echo e(trans('global.no_data_available')); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
    </div>

<?php /**PATH E:\projects\gymapp\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>