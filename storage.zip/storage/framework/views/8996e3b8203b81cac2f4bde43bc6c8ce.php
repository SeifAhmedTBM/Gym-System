
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <h5><?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.expense.title')); ?></h5>
    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.expenses.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.expense.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($expense->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.expense.fields.name')); ?>

                        </th>
                        <td>
                            <?php echo e($expense->name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.expense.fields.date')); ?>

                        </th>
                        <td>
                            <?php echo e($expense->date); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.expense.fields.payment_method')); ?>

                        </th>
                        <td>
                            <?php echo e($expense->account->name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.expense.fields.amount')); ?>

                        </th>
                        <td>
                            <?php echo e($expense->amount); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.expense.fields.note')); ?>

                        </th>
                        <td>
                            <?php echo e($expense->note); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.expense.fields.expenses_category')); ?>

                        </th>
                        <td>
                            <?php echo e($expense->expenses_category->name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.expense.fields.created_by')); ?>

                        </th>
                        <td>
                            <?php echo e($expense->created_by->name ?? ''); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.expenses.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Gym-System\resources\views/admin/expenses/show.blade.php ENDPATH**/ ?>