<div class="tab-pane fade show active" id="basic_data" role="tabpanel" aria-labelledby="basic_data-tab">
    <div class="row ">
        <div class="col-md-10 mx-auto mb-5">
            <div class="row">
                <div class="col-md-3 text-left">
                    <?php if($member->photo): ?>
                        <a href="<?php echo e($member->photo->getUrl()); ?>" target="_blank" style="display: inline-block">
                            <img src="<?php echo e($member->photo->getUrl()); ?>" class="rounded-circle"
                                style="width: 200px;height:200px;object-fit:cover;">
                        </a>
                    <?php else: ?>
                        <a href="<?php echo e(asset('images/user.png')); ?>" target="_blank" style="display: inline-block">
                            <img src="<?php echo e(asset('images/user.png')); ?>" class="rounded-circle"
                                style="width: 200px;height:200px;object-fit:cover;">
                        </a>
                    <?php endif; ?>
                </div>
                <div class="col-md-9 mx-auto">
                    <ul class="list-group shadow-sm text-left">
                        <li class="list-group-item">
                            <span class="font-weight-bold">
                                <?php echo e(trans('cruds.lead.fields.member_code')); ?> :
                            </span>
                            <?php echo e(($member->branch ? $member->branch->member_prefix : '') . $member->member_code); ?>

                        </li>
                        <li class="list-group-item">
                            <span class="font-weight-bold">
                                <?php echo e(trans('cruds.lead.fields.name')); ?> :
                            </span>
                            <?php echo e($member->name); ?>

                        </li>
                        <li class="list-group-item">
                            <span class="font-weight-bold">
                                <?php echo e(trans('cruds.lead.fields.phone')); ?> :
                            </span>
                            <?php echo e($member->phone); ?>

                        </li>

                        <?php if(!is_null($member->parent_phone)): ?>
                            <li class="list-group-item">
                                <span class="font-weight-bold">
                                    <?php echo e(trans('global.parent_phone')); ?> :
                                </span>
                                <?php echo e($member->parent_phone); ?>

                            </li>
                        <?php endif; ?>

                        <?php if(!is_null($member->parent_phone_two)): ?>
                            <li class="list-group-item">
                                <span class="font-weight-bold">
                                    <?php echo e(trans('global.parent_phone') . ' 2'); ?> :
                                </span>
                                <?php echo e($member->parent_phone_two); ?>

                            </li>
                        <?php endif; ?>

                        <li class="list-group-item">
                            <span class="font-weight-bold">
                                <?php echo e(trans('cruds.branch.title_singular')); ?> :
                            </span>
                            <?php echo e($member->branch->name ?? '-'); ?>

                        </li>

                        <li class="list-group-item">
                            <span class="font-weight-bold">
                                <?php echo e(trans('cruds.status.title_singular')); ?> :
                            </span>
                            <?php echo e($member->status->name ?? '-'); ?>

                        </li>

                        <li class="list-group-item">
                            <span class="font-weight-bold">
                                Area :
                            </span>
                            <?php if($member->address): ?>
                                <?php echo e($member->address->name); ?>

                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </li>

                        <li class="list-group-item">
                            <span class="font-weight-bold">
                                <?php echo e(trans('cruds.user.fields.email')); ?> :
                            </span>
                            <?php echo e($member->user->email ?? '-'); ?>

                        </li>

                        <li class="list-group-item">
                            <span class="font-weight-bold">
                                <?php echo e(trans('cruds.lead.fields.dob')); ?> :
                            </span>
                            <?php echo e($member->dob ?? '-'); ?>

                        </li>

                        <li class="list-group-item">
                            <span class="font-weight-bold">
                                <?php echo e(trans('global.gender')); ?> :
                            </span>
                            <?php echo e(ucfirst($member->gender) ?? '-'); ?>

                        </li>

                        <li class="list-group-item">
                            <span class="font-weight-bold">
                                <?php echo e(trans('cruds.lead.fields.national')); ?> :
                            </span>
                            <?php echo e($member->national ?? '-'); ?>

                        </li>
                        <li class="list-group-item">
                            <span class="font-weight-bold">
                                Sales By :
                            </span>
                            <?php echo e($member->sales_by->name ?? '-'); ?>

                        </li>
                        <li class="list-group-item">
                            <span class="font-weight-bold">
                                <?php echo e(trans('global.coach')); ?> :
                            </span>
                            <?php echo e($member->coach_by->name ?? '-'); ?>

                        </li>
                        <li class="list-group-item">
                            <span class="font-weight-bold">
                                PT Coach :
                            </span>
                            <?php echo e($member->pt_coach_by->name ?? '-'); ?>

                        </li>

                        <li class="list-group-item">
                            <span class="font-weight-bold">
                                Created At :
                            </span>
                            <?php echo e($member->created_at ?? '-'); ?>

                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <?php if(config('domains')[config('app.url')]['add_to_class_in_invoice'] == false): ?>
        <h3 class="text-primary font-weight-bold mb-3"><?php echo e(trans('global.memberships_details')); ?> :
        </h3>
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-6">
                        <ul class="list-group">
                            <li class="list-group-item">
                                <span class="font-weight-bold">
                                    <?php echo e(trans('global.last_attendance')); ?> :
                                </span>
                                <?php if(isset($last_membership) && $last_membership->service_pricelist): ?>
                                    <?php echo $last_membership->last_attendance
                                        ? date('Y-m-d', strtotime($last_membership->last_attendance)) .
                                            '  ' .
                                            '<span class="text-danger">' .
                                            date('h:iA', strtotime($last_membership->last_attendance)) .
                                            '</span>'
                                        : '<span class="badge badge-danger">No Attendance</span>'; ?>

                                <?php else: ?>
                                    <span class="badge badge-danger"><?php echo e(trans('global.no_data_available')); ?></span>
                                <?php endif; ?>
                            </li>

                            <?php if(isset($last_membership) && $last_membership->service_pricelist): ?>
                                <li class="list-group-item">
                                    <span class="font-weight-bold">
                                        <?php echo e(trans('global.main_service')); ?> :
                                    </span>
                                    <?php echo e($main_membership->service_pricelist->name ?? $last_membership->service_pricelist->name); ?>


                                    <?php if(config('domains')[config('app.url')]['sports_option'] == true): ?>
                                        <span class="d-block font-weight-bold">
                                            <?php echo e($main_membership->sport->name ?? '-'); ?>

                                        </span>
                                    <?php endif; ?>
                                </li>

                                <li class="list-group-item">
                                    <span class="font-weight-bold">
                                        Service Attendance :
                                    </span>
                                    <?php if(isset($last_membership) && !is_null($last_membership) && $last_membership->service_pricelist): ?>
                                        <?php if(isset($main_membership)): ?>
                                            <?php echo e($main_membership->attendances->count()); ?>

                                        <?php else: ?>
                                            <?php echo e($last_membership->attendances->count()); ?>

                                        <?php endif; ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </li>

                                <li class="list-group-item">
                                    <span class="font-weight-bold">
                                        <?php echo e(trans('global.start_date') . ' / ' . trans('global.end_date')); ?>

                                    </span>
                                    <?php echo e($main_membership->start_date ?? $last_membership->start_date); ?>

                                    /
                                    <?php echo e($main_membership->end_date ?? $last_membership->end_date); ?>

                                </li>

                                <?php if(
                                    $main_membership &&
                                        $main_membership->service_pricelist &&
                                        $main_membership->service_pricelist->service &&
                                        $main_membership->service_pricelist->service->service_type->session_type == 'sessions'): ?>
                                    <li class="list-group-item">
                                        <span class="font-weight-bold">
                                            <?php echo e(trans('global.membership_sessions')); ?> :
                                        </span>
                                        <?php echo e($main_membership->attendances->count()); ?> /
                                        <?php echo e($main_membership->service_pricelist->session_count); ?>

                                        (<?php echo e($main_membership->service_pricelist->session_count - $main_membership->attendances->count()); ?>

                                        Sessions Left )
                                    </li>
                                <?php endif; ?>
                            <?php endif; ?>

                            <li class="list-group-item">
                                <span class="font-weight-bold">
                                    <?php echo e(trans('cruds.lead.fields.address_details')); ?> :
                                </span>
                                <?php echo e($member->address_details ?? '-'); ?>

                            </li>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <ul class="list-group">
                            <li class="list-group-item">
                                <span class="font-weight-bold">
                                    <?php echo e(trans('cruds.lead.fields.status')); ?> :
                                </span>
                                <?php echo e($member->status->name ?? trans('global.no_data_available')); ?>

                            </li>

                            <li class="list-group-item">
                                <span class="font-weight-bold">
                                    <?php echo e(trans('cruds.lead.fields.source')); ?> :
                                </span>
                                <?php echo e($member->source->name ?? '-'); ?>

                            </li>

                            <li class="list-group-item">
                                <span class="font-weight-bold">
                                    <?php echo e(trans('cruds.lead.fields.sales_by')); ?> :
                                </span>
                                <?php echo e($member->sales_by->name ?? '-'); ?>

                            </li>

                            <li class="list-group-item">
                                <span class="font-weight-bold">
                                    <?php echo e(trans('cruds.lead.fields.referral_member')); ?> :
                                </span>
                                <?php echo e($member->referral_member ?? trans('global.no_data_available')); ?>

                            </li>

                            <li class="list-group-item">
                                <span class="font-weight-bold">
                                    <?php echo e(trans('global.main_notes')); ?> :
                                </span>
                                <?php echo e($member->notes ?? 'No Notes'); ?>

                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH E:\projects\gymapp\resources\views/admin/members/tabs/basic_data.blade.php ENDPATH**/ ?>