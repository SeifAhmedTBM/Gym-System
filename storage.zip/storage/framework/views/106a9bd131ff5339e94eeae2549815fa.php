<?php if(config('domains')[config('app.url')]['employees_schedule'] == true): ?>
    <?php echo $__env->make('partials.schedule', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<div class="row">
    <div class="col-sm-6 col-lg-4">
        <div class="card">
            <div class="card-body bg-primary text-white text-center">
                <div>
                    <h5 class="fs-4 fw-semibold"><?php echo e($memberships->count()); ?><span class="fs-6 fw-normal"></h5>
                    <h5><i class="fa fa-users"></i> <?php echo e(trans('cruds.membership.title')); ?></h5>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-lg-4">
        <div class="card">
            <div class="card-body bg-primary text-white text-center">
                <div>
                    <h5 class="fs-4 fw-semibold">
                        <?php echo e($attendances->count()); ?></h5>
                    <h5><i class="fas fa-fingerprint"></i> <?php echo e(trans('global.attendances')); ?></h5>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-lg-4">
        <div class="card">
            <div class="card-body bg-primary text-white text-center">
                <div>
                    <h5 class="fs-4 fw-semibold">
                        <?php echo e(number_format($payments->sum('amount')) .' EGP'); ?></h5>
                    <h5><i class="fas fa-wallet"></i> <?php echo e(trans('payments')); ?></h5>
                </div>
            </div>
        </div>
    </div>
</div>




<?php if(config('domains')[config('app.url')]['profile_attendance'] == true): ?>
    <?php echo $__env->make('partials.profile_attendance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>


<div class="card shadow-sm">
    <div class="card-header">
        <h5><i class="fa fa-user"></i> <?php echo e(trans('global.attendance_data')); ?></h5>
    </div>
    <div class="card-body">
        <table class="table table-bordered table-hover text-center zero-configuration">
            <thead class="thead-light">
                <tr>
                    <th>#</th>
                    <th><?php echo e(trans('cruds.member.fields.photo')); ?></th>
                    <th>
                        <?php echo e(trans('cruds.lead.fields.member_code')); ?>

                    </th>
                    <th><?php echo e(trans('global.name')); ?></th>
                    <th><?php echo e(trans('cruds.service.title_singular')); ?></th>
                    <th><?php echo e(trans('cruds.membershipAttendance.fields.sign_in')); ?></th>
                    <?php if(\App\Models\Setting::first()->has_lockers == true): ?>
                        <th><?php echo e(trans('cruds.membershipAttendance.fields.sign_out')); ?></th>
                    <?php endif; ?>
                    <th><?php echo e(trans('global.end_date')); ?></th>
                    <th><?php echo e(trans('global.attendance_count')); ?></th>
                    <th><?php echo e(trans('cruds.status.title_singular')); ?></th>
                    <th><?php echo e(trans('cruds.locker.title_singular')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $today_attendants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td>
                            <?php if($attendant->membership->member->photo): ?>
                                <a href="<?php echo e($attendant->membership->member->photo->getUrl()); ?>" target="_blank"
                                    style="display: inline-block">
                                    <img src="<?php echo e($attendant->membership->member->photo->getUrl()); ?>"
                                        class="rounded-circle" style="width: 50px;height:50px">
                                </a>
                            <?php else: ?>
                                <a href="<?php echo e(asset('images/user.png')); ?>" target="_blank"
                                    style="display: inline-block">
                                    <img src="<?php echo e(asset('images/user.png')); ?>" class="rounded-circle"
                                        style="width: 50px;height:50px">
                                </a>
                            <?php endif; ?>
                        </td>
                        <td class="font-weight-bold">
                            <a href="<?php echo e(route('admin.members.show', $attendant->membership->member->id)); ?>"
                                target="_blank">
                                <?php echo e(\App\Models\Setting::first()->member_prefix . $attendant->membership->member->member_code); ?>

                            </a>
                        </td>
                        <td class="font-weight-bold">
                            <a href="<?php echo e(route('admin.members.show', $attendant->membership->member->id)); ?>"
                                target="_blank">
                                <?php echo e($attendant->membership->member->name); ?>

                            </a>
                        </td>
                        <td>
                            <?php echo e($attendant->membership->service_pricelist->name ?? '-'); ?>

                        </td>
                        <td><?php echo e(date('g:i A', strtotime($attendant->sign_in))); ?></td>
                        <?php if(\App\Models\Setting::first()->has_lockers == true): ?>
                            <td><?php echo e(date('g:i A', strtotime($attendant->sign_out))); ?></td>
                        <?php endif; ?>
                        <td>
                            <?php echo e($attendant->membership->end_date ?? '-'); ?>

                        </td>
                        <td>
                            <?php echo e(($attendant->membership->service_pricelist->service->service_type->session_type == "sessions") || ($attendant->membership->service_pricelist->service->service_type->session_type == "group_sessions") ? $attendant->membership->attendances_count ."/".$attendant->membership->service_pricelist->session_count : $attendant->membership->attendances_count); ?>

                        </td>
                        <th>
                            <span
                                class="badge badge-<?php echo e(\App\Models\Membership::STATUS[$attendant->membership->status]); ?> p-2">
                                <i class="fa fa-recycle"></i> <?php echo e($attendant->membership->status ?? '-'); ?>

                            </span>
                        </th>
                        <th>
                            <?php echo $attendant->locker ?? '<span class="badge badge-danger">No locker</span>'; ?>

                        </th>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8"><?php echo e(trans('global.no_data_available')); ?></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH E:\projects\gymapp\resources\views/dashboard/receptionist.blade.php ENDPATH**/ ?>