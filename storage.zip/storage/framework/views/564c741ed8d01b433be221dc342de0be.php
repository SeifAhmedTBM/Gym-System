<div class="card">
    <div class="card-header">
        ENTER DETAILS OF THE SUBSCRIPTION
    </div>
    <div class="card-body">
        <div class="row form-group">
            <div class="col-md-3">
                <label for="service_type" class="required"><?php echo e(trans('cruds.service.fields.service_type')); ?></label>
                <select name="service_type_id" id="service_type_id" class="form-control select2" onchange="getPricelists()">
                    <option value="<?php echo e(NULL); ?>" selected disabled><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = \App\Models\ServiceType::pluck('name','id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="required" for="service_pricelist_id"><?php echo e(trans('cruds.member.fields.service')); ?></label>
                <select onchange="getExpiry()" class="form-control select2 <?php echo e($errors->has('service_pricelist_id') ? 'is-invalid' : ''); ?>"
                    name="service_pricelist_id" id="service_pricelist_id" required>
                    <option disabled selected hidden>Select Service</option>
                    
                </select>
                <?php if($errors->has('service_pricelist_id')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('service_pricelist_id')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.member.fields.service_helper')); ?></span>
            </div>

            <div class="col-md-3">
                <label class="required" for="start_date"><?php echo e(trans('cruds.membership.fields.start_date')); ?></label>
                <input class="form-control date <?php echo e($errors->has('start_date') ? 'is-invalid' : ''); ?>" type="text"
                    name="start_date" id="start_date" onblur="getExpiry()" value="<?php echo e(old('start_date') ?? date('Y-m-d')); ?>" required>
                <?php if($errors->has('start_date')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('start_date')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.membership.fields.start_date_helper')); ?></span>
            </div>

            <div class="col-md-3">
                <label class="required" for="end_date"><?php echo e(trans('cruds.membership.fields.end_date')); ?></label>
                <input class="form-control date <?php echo e($errors->has('end_date') ? 'is-invalid' : ''); ?>" type="text"
                    name="end_date" id="end_date" value="<?php echo e(old('end_date') ?? date('Y-m-d')); ?>" required 
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('editable_end_date')): ?> 
                     readonly
                    <?php endif; ?>
                    >
                <?php if($errors->has('end_date')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('end_date')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.membership.fields.end_date_helper')); ?></span>
            </div>
        </div>

        <div class="row form-group">
            <div class="col-md-4">
                <label class="required" for="trainer_id"><?php echo e(trans('cruds.member.fields.trainer')); ?></label>
                <select class="form-control  <?php echo e($errors->has('trainer_id') ? 'is-invalid' : ''); ?>" name="trainer_id" id="trainer_id" required>
                    <option value="<?php echo e(NULL); ?>" disabled selected hidden><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('trainer_id') == $id ? 'selected' : ''); ?>>
                            <?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('trainer_id')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('trainer_id')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.member.fields.trainer_helper')); ?></span>
            </div>
            <?php if(config('domains')[config('app.url')]['sports_option'] == true): ?>
                <div class="col-md-4 form-group">
                    <label for="sport_id" class="required"><?php echo e(trans('global.sport')); ?></label>
                    <select name="sport_id" id="sport_id" class="select2">
                        <option disabled hidden selected><?php echo e(trans('global.pleaseSelect')); ?></option>
                        <?php $__currentLoopData = $sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sport_id => $sport_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sport_id); ?>"><?php echo e($sport_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            <?php endif; ?>
            <?php if(config('domains')[config('app.url')]['add_to_class_in_invoice'] == true): ?>
                <div class="col-md-4 form-group">
                    <label for="main_schedule_id">Session</label>
                    <select name="main_schedule_id[]" id="main_schedule_id" class="select2 multiple" multiple="multiple">
                        
                        <?php $__currentLoopData = $main_schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $main_schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($main_schedule->id); ?>"><?php echo e(($main_schedule->session->name ?? '').' - '.($main_schedule->trainer->name ?? '').' - '.date('h:i A', strtotime($main_schedule->timeslot->from)) .' -'.$main_schedule->branch->name ?? '-'); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label class="" for="subscription_notes">Subscription Notes</label>
            <input class="form-control" id="subscription_notes" name="subscription_notes" value="<?php echo e(old('subscription_notes')); ?>" />
            <?php if($errors->has('subscription_notes')): ?>
                <div class="invalid-feedback">
                    <?php echo e($errors->first('subscription_notes')); ?>

                </div>
            <?php endif; ?>
            <span class="help-block"><?php echo e(trans('cruds.member.fields.trainer_helper')); ?></span>
        </div>
    </div>
</div><?php /**PATH E:\projects\gymapp\resources\views/partials/subscription_details.blade.php ENDPATH**/ ?>