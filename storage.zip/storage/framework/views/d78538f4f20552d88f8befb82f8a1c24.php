   
   <div class="card">
    <div class="card-header">
        ENTER DETAILS OF THE INVOICE
    </div>
    <div class="card-body">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('free_discount')): ?> 
            <?php if($setting->max_discount != 100): ?>
                    <div class="alert alert-warning text-center">
                        <strong><i class="fa fa-exclamation-circle"></i> <?php echo e(trans('global.max_discount')); ?> : <?php echo e($setting->max_discount); ?> %</strong>
                    </div>
            <?php endif; ?>
        <?php endif; ?>
        <div class="row form-group">
            <div class="col-md-3">
                <label class="required" for="invoice_id"><?php echo e(trans('cruds.payment.fields.invoice')); ?></label>
                <input type="text" class="form-control" name="invoice_id" value="<?php echo e($last_invoice + 001); ?>" readonly>
                <?php if($errors->has('invoice_id')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('invoice_id')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.payment.fields.invoice_helper')); ?></span>
            </div>

            <div class="col-md-3">
                <label class="required" for="membership_fee"><?php echo e(trans('cruds.membership.fields.membership_fee')); ?></label>
                <input class="form-control <?php echo e($errors->has('membership_fee') ? 'is-invalid' : ''); ?>" type="text"
                    name="membership_fee" id="membership_fee" value="<?php echo e(old('membership_fee')); ?>" required readonly>
                <?php if($errors->has('membership_fee')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('membership_fee')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.membership.fields.membership_fee_helper')); ?></span>
            </div>

            <div class="col-md-3">
                <label class="required" for="discount"><?php echo e(trans('cruds.invoice.fields.discount')); ?></label>
                <div class="input-group">
                    <input class="form-control <?php echo e($errors->has('discount') ? 'is-invalid' : ''); ?>" type="number"
                        name="discount" id="discount" value="<?php echo e(old('discount') ?? 0); ?>" required step="0.001">
                    <div class="input-group-append">
                        <span class="input-group-text" >%</span>
                    </div>
                </div>
                <?php if($errors->has('discount')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('discount')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.invoice.fields.discount_helper')); ?></span>
            </div>

            <div class="col-md-3">
                <label class="required" for="discount_amount"><?php echo e(trans('global.discount_amount')); ?></label>
                <div class="input-group">
                    <input class="form-control <?php echo e($errors->has('discount_amount') ? 'is-invalid' : ''); ?>" type="number" name="discount_amount" id="discount_amount" value="<?php echo e(old('discount_amount') ?? 0); ?>" required step="0.001">
                    <div class="input-group-append">
                        <span class="input-group-text">EGP</span>
                    </div>
                </div>
                <?php if($errors->has('discount_amount')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('discount_amount')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <div class="col-md-6">
                <label for="discount_notes"><?php echo e(trans('cruds.invoice.fields.discount_notes')); ?></label>
                <input type="text" name="discount_notes" id="discount_notes" class="form-control" />
            </div>
            <div class="col-md-6">
                <label for="created_at">Invoice Date :</label>
                <input type="date" class="form-control" name="created_at" value="<?php echo e(date('Y-m-d')); ?>" <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('invoice_change_date')): ?> readonly  <?php endif; ?>>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\projects\gymapp\resources\views/partials/invoices_details.blade.php ENDPATH**/ ?>