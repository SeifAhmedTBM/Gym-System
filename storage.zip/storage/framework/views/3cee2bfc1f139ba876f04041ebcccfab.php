<div class="tab-pane fade" id="memberships" role="tabpanel" aria-labelledby="memberships-tab">
    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered table-striped table-hover zero-configuration">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Pricelist</th>
                        <?php if(config('domains')[config('app.url')]['sports_option'] == true): ?>
                            <th><?php echo e(trans('global.sport')); ?></th>
                        <?php endif; ?>
                        <th><?php echo e(trans('cruds.membership.fields.start_date')); ?></th>
                        <th><?php echo e(trans('cruds.membership.fields.end_date')); ?></th>
                        <th><?php echo e(trans('cruds.membership.fields.trainer')); ?></th>
                        <th><?php echo e(trans('global.notes')); ?></th>
                        <th><?php echo e(trans('cruds.status.title')); ?></th>
                        <th>Coach Assigned</th>
                        <th>Assign Date</th>
                        <th><?php echo e(trans('cruds.membership.fields.sales_by')); ?></th>
                        <th><?php echo e(trans('cruds.membership.fields.created_at')); ?></th>
                        <th><?php echo e(trans('global.actions')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $member->memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr
                            class="<?php echo e($membership->service_pricelist->service->service_type->main_service == true ? 'table-info' : ''); ?>">
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.memberships.show', $membership->id)); ?>"
                                    class="text-decoration-none">
                                    <span class="font-weight-bold">
                                        <?php echo e($membership->service_pricelist->name ?? '-'); ?>

                                    </span>
                                    <span class="font-weight-bold d-block">
                                        fees :
                                        <?php echo e(number_format($membership->service_pricelist->amount) ?? '-'); ?>

                                    </span>
                                    <?php if($membership->service_pricelist->service->service_type->main_service == 1): ?>
                                        <span class="font-weight-bold d-block py-2">
                                            <div class="badge badge-info">
                                                Main Service
                                            </div>
                                        </span>
                                    <?php endif; ?>

                                    
                                    <span class="font-weight-bold d-block">
                                        <?php if($membership->service_pricelist->service->service_type->session_type == 'non_sessions'): ?>
                                        <?php else: ?>
                                            <?php echo e($membership->trainer_attendances->count()); ?> /
                                            <?php echo e($membership->service_pricelist->session_count); ?>

                                            (<?php echo e($membership->service_pricelist->session_count - $membership->trainer_attendances->count()); ?>

                                            Sessions Left)
                                        <?php endif; ?>
                                    </span>
                                    <span
                                        class="badge badge-<?php echo e(\App\Models\Membership::MEMBERSHIP_STATUS_COLOR[$membership->membership_status]); ?>">
                                        <?php echo e(\App\Models\Membership::MEMBERSHIP_STATUS[$membership->membership_status]); ?>

                                    </span>
                                </a>
                            </td>
                            <?php if(config('domains')[config('app.url')]['sports_option'] == true): ?>
                                <td>
                                    <?php echo e($membership->sport->name ?? '-'); ?>

                                </td>
                            <?php endif; ?>
                            <td><?php echo e($membership->start_date); ?></td>
                            <td><?php echo e($membership->end_date); ?></td>
                            <td><?php echo e($membership->trainer->name ?? '-'); ?></td>
                            <td><?php echo e($membership->notes ?? '-'); ?></td>

                            <td>
                                <span
                                    class="badge badge-<?php echo e(\App\Models\Membership::STATUS[$membership->status]); ?> p-2">
                                    <i class="fa fa-recycle"></i> <?php echo e($membership->status); ?>

                                </span>
                            </td>
                            <td><?php echo e($membership->assigned_coach->name ?? '-'); ?></td>
                            <td><?php echo e($membership->assign_date ?? '-'); ?></td>
                            <td><?php echo e($membership->sales_by->name ?? '-'); ?></td>
                            <td><?php echo e($membership->created_at->toFormattedDateString() . ' , ' . $membership->created_at->format('g:i A')); ?>

                            </td>
                            <td>
                                <div class="dropdown">
                                    <a class="btn btn-primary dropdown-toggle" href="#" role="button"
                                        id="dropdownMenuLink" data-toggle="dropdown" aria-expanded="false">
                                        <?php echo e(trans('global.action')); ?>

                                    </a>

                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('membership_show')): ?>
                                            <a href="<?php echo e(route('admin.memberships.show', $membership->id)); ?>"
                                                class="dropdown-item">
                                                <i class="fa fa-eye"> </i> &nbsp;
                                                <?php echo e(trans('global.view')); ?>

                                            </a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('take_attendance')): ?>
                                            <a href="<?php echo e(route('admin.memberships.manual_attend', $membership->id)); ?>"
                                                class="dropdown-item">
                                                <i class="fas fa-fingerprint"> </i> &nbsp;
                                                <?php echo e(trans('global.manual_attend')); ?>

                                            </a>
                                        <?php endif; ?>


                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('membership_edit')): ?>
                                            <a href="<?php echo e(route('admin.memberships.edit', $membership->id)); ?>"
                                                class="dropdown-item">
                                                <i class="fa fa-edit"></i> &nbsp; Edit
                                            </a>
                                        <?php endif; ?>

                                        <?php if($membership->service_pricelist->service->service_type->session_type == 'non_sessions'): ?>
                                            <a href="javascript:;" data-toggle="modal" data-target="#assignTrainerNonPt"
                                                class="dropdown-item"
                                                onclick="assignTrainerNonPt(<?php echo e($membership->id); ?>)">
                                                <i class="fa fa-exchange"></i> Assign Trainer
                                            </a>
                                        <?php else: ?>
                                            <a href="javascript:;" data-toggle="modal" data-target="#assignTrainer"
                                                class="dropdown-item" onclick="assignTrainer(<?php echo e($membership->id); ?>)">
                                                <i class="fa fa-exchange"></i> Assign Trainer
                                            </a>
                                        <?php endif; ?>
                                        

                                        <?php if($membership->status == 'current' || $membership->status == 'expiring'): ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('freeze_request_create')): ?>
                                                <a href="<?php echo e(route('admin.membership.freezeRequests', $membership->id)); ?>"
                                                    class="dropdown-item"><i class="fa fa-minus-circle"></i>
                                                    &nbsp; <?php echo e(trans('cruds.freezeRequest.title')); ?>

                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>



                                        <?php if($membership->status !== 'refunded'): ?>
                                            <?php if($membership->status == 'expired'): ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('renew_membership')): ?>
                                                    <a href="<?php echo e(route('admin.membership.renew', $membership->id)); ?>"
                                                        class="dropdown-item">
                                                        <i class="fa fa-plus-circle"></i> &nbsp;
                                                        <?php echo e(trans('cruds.membership.fields.renew')); ?>

                                                    </a>
                                                <?php endif; ?>
                                            <?php endif; ?>

                                            <?php if($membership->status == 'current' || $membership->status == 'expiring'): ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('upgrade_membership')): ?>
                                                    <a href="<?php echo e(route('admin.membership.upgrade', $membership->id)); ?>"
                                                        class="dropdown-item">
                                                        <i class="fa fa-arrow-up"></i> &nbsp;
                                                        <?php echo e(trans('cruds.membership.fields.upgrade')); ?>

                                                    </a>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('downgrade_membership')): ?>
                                                    <a href="<?php echo e(route('admin.membership.downgrade', $membership->id)); ?>"
                                                        class="dropdown-item">
                                                        <i class="fa fa-arrow-down"></i>
                                                        &nbsp;
                                                        <?php echo e(trans('cruds.membership.fields.downgrade')); ?>

                                                    </a>
                                                <?php endif; ?>
                                            <?php endif; ?>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('transfer_membership')): ?>
                                                <a href="<?php echo e(route('admin.membership.transfer', $membership->id)); ?>"
                                                    class="dropdown-item">
                                                    <i class="fa fa-exchange"></i>&nbsp;
                                                    <?php echo e(trans('global.transfer_to_member')); ?>

                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('refund_create')): ?>
                                            <?php if($membership->invoice && $membership->invoice->status !== 'refund'): ?>
                                                <a href="<?php echo e(route('admin.invoice.refund', $membership->invoice->id)); ?>"
                                                    class="dropdown-item"> <i class="fas fa-recycle"></i>&nbsp;
                                                    &nbsp; <?php echo e(trans('cruds.refund.title')); ?></a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td colspan="10" class="text-center">No data Available</td>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div id="assignTrainer" class="modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <form action="" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Assign Trainer</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="type" value="pt">
                    <div class="form-group">
                        <label for="to_trainer_id">To Trainer</label>
                        <select class="form-control" name="to_trainer_id">
                            <option value="<?php echo e(null); ?>">Trainer</option>
                            <?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer_id => $trainer_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($trainer_id); ?>"><?php echo e($trainer_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal"><i
                            class="fa fa-times-circle"></i> Close</button>
                    <button type="submit" class="btn btn-success">
                        <i class="fa fa-check-circle"></i>
                        Confirm
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<div id="assignTrainerNonPt" class="modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <form action="" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Assign Trainer</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <input type="hidden" name="type" value="non_pt">
                        <label for="to_trainer_id">To Trainer</label>
                        <select class="form-control" name="to_trainer_id_non_pt">
                            <option value="<?php echo e(null); ?>">Trainer</option>
                            <?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer_id => $trainer_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($trainer_id); ?>"><?php echo e($trainer_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal"><i
                            class="fa fa-times-circle"></i> Close</button>
                    <button type="submit" class="btn btn-success">
                        <i class="fa fa-check-circle"></i>
                        Confirm
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    function assignTrainer(id) {
        var id = id;
        var url = "<?php echo e(route('admin.assign-coach-to-membership.memberships', ':id')); ?>",
            url = url.replace(':id', id);
        $.ajax({
            method: 'GET',
            url: url,
            success: function(response) {
                var route = "<?php echo e(route('admin.assign-trainer', ':membership_id')); ?>";

                route = route.replace(':membership_id', response.id);

                //  alert(route);
                $('form').attr('action', route)
            }
        });
    }

    function assignTrainerNonPt(id) {
        var id = id;
        var url = "<?php echo e(route('admin.assign-coach-to-membership.memberships', ':id')); ?>",
            url = url.replace(':id', id);
        $.ajax({
            method: 'GET',
            url: url,
            success: function(response) {
                var route = "<?php echo e(route('admin.assign-trainer', ':membership_id')); ?>";

                route = route.replace(':membership_id', response.id);

                //  alert(route);
                $('form').attr('action', route)
            }
        });
    }
</script>
<?php /**PATH E:\projects\gymapp\resources\views/admin/members/tabs/memberships.blade.php ENDPATH**/ ?>