
<?php $__env->startSection('content'); ?>
    <div class="form-group row">
        <div class="col-lg-9">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lead_create')): ?>
                <a class="btn btn-success" href="<?php echo e(route('admin.leads.create')); ?>">
                    <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.lead.title_singular')); ?>

                </a>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lead_import')): ?>
                <button class="btn btn-warning" data-toggle="modal" data-target="#importLead">
                    <i class="fa fa-upload"></i> <?php echo e(trans('global.import_data')); ?>

                </button>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('export_leads')): ?>
                <a href="<?php echo e(route('admin.leads.export',request()->all())); ?>" class="btn btn-info">
                    <i class="fa fa-download"></i> <?php echo e(trans('global.export_excel')); ?>

                </a>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lead_filter')): ?>
            <?php echo $__env->make('admin_includes.filters', [
                'columns' => [
                    'name'              => ['label' => 'Name', 'type' => 'text'],
                    'status_id'         => ['label' => 'Status', 'type' => 'select', 'data' => $statuses],
                    'source_id'         => ['label' => 'Source', 'type' => 'select', 'data' => $sources],
                    'address_id'        => ['label' => 'Address', 'type' => 'select', 'data' => $addresses],
                    'phone'             => ['label' => 'Phone', 'type' => 'number'],
                    'parent_phone'      => ['label' => 'Parent Phone', 'type' => 'number'],
                    'parent_phone_two'  => ['label' => 'Parent Phone 2', 'type' => 'number'],
                    'sport_id'          => ['label' => 'Sport', 'type' => 'select','data' => $sports],
                    'branch_id'         => ['label' => 'Branch', 'type' => 'select', 'data' => $branches],
                    'gender'            => ['label' => 'Gender', 'type' => 'select', 'data' => ['male' => 'Male', 'female' => 'Female']],
                    'sales_by_id'       => ['label' => 'Sales By', 'type' => 'select', 'data' => $sales],
                    'created_at'        => ['label' => 'Created at', 'type' => 'date', 'from_and_to' => true]
                ],
                    'route' => 'admin.leads.index'
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lead_import')): ?>
                <?php echo $__env->make('admin.leads.import-model',['route' => 'admin.import.leads_and_members'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

        </div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lead_counter')): ?>
            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-body">
                        <h2 class="text-center"><?php echo e(trans('cruds.lead.title')); ?></h2>
                        <h2 class="text-center"><?php echo e($leads); ?></h2>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <?php if(Session::has('xl_sheet_error')): ?>
        <div class="alert alert-danger font-weight-bold">
            <i class="fa fa-exclamation-circle"></i> <?php echo e(session('xl_sheet_error')); ?> .
        </div>
    <?php endif; ?>
   
    <div class="card">
        <div class="card-header">
            <h5><?php echo e(trans('cruds.lead.title_singular')); ?> <?php echo e(trans('global.list')); ?></h5>
        </div>

        <div class="card-body">
            <table class="table table-bordered table-striped table-hover ajaxTable datatable datatable-Lead">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                      
                        <th>
                            <?php echo e(trans('cruds.lead.fields.photo')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.lead.fields.name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.lead.fields.gender')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.branch.title_singular')); ?>

                        </th>
                        <th>
                            Parent Phone
                        </th>
                        <th>
                            <?php echo e(trans('cruds.lead.fields.source')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.lead.fields.status')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.lead.fields.address')); ?>

                        </th>
                        <?php if(config('domains')[config('app.url')]['sports_option'] == true): ?>
                        <th>
                            <?php echo e(trans('global.sport')); ?>

                        </th>
                        <?php endif; ?>
                        <th>
                            <?php echo e(trans('cruds.lead.fields.sales_by')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.lead.fields.created_at')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('global.notes')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <div class="modal fade" id="import" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(trans('global.import_data')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('admin.lead.import')); ?>" method="post" class="modalForm2" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <label for="">File</label>
                        <input type="file" name="upload" id="upload" class="form-control">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="leadAction" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
      aria-hidden="true">
         <div class="modal-dialog modal-lg" role="document">
             <div class="modal-content">
                 <div class="modal-header">
                     <h5 class="modal-title" id="exampleModalLabel"><?php echo e(trans('cruds.reminder.fields.action')); ?></h5>
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                         <span aria-hidden="true">&times;</span>
                     </button>
                 </div>
                 <form action="" method="post" class="modalForm2">
                     <?php echo csrf_field(); ?>
                     <div class="modal-body">
                         <div class="alert alert-info font-weight-bold">
                             <i class="fa fa-exclamation-circle"></i> <?php echo e(trans('global.if_empty_due_date')); ?> .
                         </div>
                         
                         <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('reminder-actions');

$__html = app('livewire')->mount($__name, $__params, 'lw-2719412504-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
 
                         <div class="form-group">
                             <label for="notes"><?php echo e(trans('cruds.lead.fields.notes')); ?></label>
                             <textarea name="notes" id="notes" rows="7" class="form-control"></textarea>
                         </div>
                     </div>
                     <div class="modal-footer">
                         <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                         <button type="submit" class="btn btn-primary">Save changes</button>
                     </div>
                 </form>
             </div>
         </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <script>
        $(function() {
            let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
                 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lead_delete')): ?>
                let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>';
                let deleteButton = {
                text: deleteButtonTrans,
                url: "<?php echo e(route('admin.leads.massDestroy')); ?>",
                className: 'btn-danger',
                action: function (e, dt, node, config) {
                var ids = $.map(dt.rows({ selected: true }).data(), function (entry) {
                return entry.id
                });
            
                if (ids.length === 0) {
                alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')
            
                return
                }
            
                if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
                $.ajax({
                headers: {'x-csrf-token': _token},
                method: 'POST',
                url: config.url,
                data: { ids: ids, _method: 'DELETE' }})
                .done(function () { location.reload() })
                }
                }
                }
                dtButtons.push(deleteButton)
            <?php endif; ?>

            let dtOverrideGlobals = {
                buttons:[],
                processing: true,
                serverSide: true,
                retrieve: true,
                searching:true,
                aaSorting: [],
                ajax: "<?php echo e(route('admin.leads.index', request()->all())); ?>",
                columns: [{
                        data: 'placeholder',
                        name: 'placeholder'
                    },
                    {
                        data: 'photo',
                        name: 'photo',
                        sortable: false,
                        searchable: false
                    },
                    {
                        data: 'name',
                        name: 'name'
                    },
                    {
                        data: 'gender',
                        name: 'gender'
                    },
                    {
                        data: 'branch_name',
                        name: 'branch.name'
                    },
                    {
                        data: 'parent',
                        name: 'parent'
                    },
                    {
                        data: 'source_name',
                        name: 'source.name'
                    },
                    {
                        data: 'status_name',
                        name: 'status.name'
                    },
                    {
                        data: 'address_name',
                        name: 'address.name'
                    },
                    <?php if(config('domains')[config('app.url')]['sports_option'] == true): ?>
                    {
                        data: 'sport_name',
                        name: 'sport.name'
                    },
                    <?php endif; ?>
                    {
                        data: 'sales_by_name',
                        name: 'sales_by.name'
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                    {
                        data: 'notes',
                        name: 'notes'
                    },
                    {
                        data: 'actions',
                        name: '<?php echo e(trans('global.actions')); ?>'
                    }
                ],
                orderCellsTop: true,
                order: [
                    [1, 'desc']
                ],
                pageLength: 10,
            };
            let table = $('.datatable-Lead').DataTable(dtOverrideGlobals);
            table.DataTable
            $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e) {
                $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
                
            });
        });
    </script>

    <script>
        function leadAction(id) {
            var id = id;
            var url = "<?php echo e(route('admin.leadAction', ':id')); ?>";
            url = url.replace(':id', id);
            $(".modalForm2").attr('action', url);
        }

        function formSubmit() {
            $('modalForm2').submit();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Gym-System\resources\views/admin/leads/index.blade.php ENDPATH**/ ?>