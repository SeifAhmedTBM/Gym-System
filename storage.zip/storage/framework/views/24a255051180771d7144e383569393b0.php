<div class="modal fade" id="importMembers" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel"><?php echo app('translator')->get('global.datatables.excel'); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <form class="form-horizontal" method="POST" action="<?php echo e(route($route)); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="modal-body">
                    <div class="alert alert-danger font-weight-bold">
                        <i class="fa fa-exclamation-circle"></i> <?php echo e(trans('global.max_number_uploaded') .' 1000 Record'); ?> .
                    </div>
                    <div class='row'>
                        <div class='col-md-12'>
                            <div class="form-group<?php echo e($errors->has('csv_file') ? ' has-error' : ''); ?>">
                                <label for="csv_file" class="col-md-4 control-label"><?php echo app('translator')->get('global.datatables.excel'); ?></label>

                                <div class="col-md-6">
                                    <input id="csv_file" type="file" class="form-control-file" name="Member" required>

                                    <?php if($errors->has('csv_file')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('csv_file')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <a href="<?php echo e(asset('member_demo.xlsx')); ?>" type="submit" class="btn btn-danger">
                        <i class="fa fa-download"></i> <?php echo e(trans('global.download_sample')); ?>

                    </a>
                        
                    <button type="submit" class="btn btn-primary">
                       <i class="fa fa-check"></i> <?php echo app('translator')->get('global.confirm'); ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH E:\projects\gymapp\resources\views/admin/members/import-members-modal.blade.php ENDPATH**/ ?>