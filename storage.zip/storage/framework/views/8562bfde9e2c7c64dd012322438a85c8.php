<?php $__env->startSection('content'); ?>
    <div class="form-group">
        <form action="<?php echo e(route('admin.reports.tax-accountant')); ?>" method="get">
            
            <div class="form-group row">
                <div class="col-md-10">
                    <?php echo $__env->make('admin_includes.filters', [
                        'columns' => [
                            'branch_id'  => ['label' => 'Branch', 'type' => 'select', 'data' => $branches,'related_to' => 'account'],
                            'account_id' => ['label' => 'Account', 'type' => 'select', 'data' => $accounts],
                            'created_at' => ['label' => trans('global.created_at'), 'type' => 'date', 'from_and_to' => true]
                        ],
                        'route' => 'admin.reports.tax-accountant'
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <a href="<?php echo e(route('admin.reports.tax-accountant.export',request()->all())); ?>" class="btn btn-info">
                        <i class="fa fa-download"></i> <?php echo e(trans('global.export_excel')); ?>

                    </a>
                </div>
                <div class="col-md-2">
                    <h3 class="text-center"><?php echo e(number_format($payments->sum('amount'))); ?></h3>
                    <h3 class="text-center"><?php echo e(trans('cruds.payment.title_singular')); ?></h3>
                </div>
            </div>
        </form>
    </div>
    <div class="form-group">
        <div class="card">
            <div class="card-header">
                Tax Accountant
            </div>
            <div class="card-body">
                <label>Month</label>
                
                <table class="table table-striped table-hover table-bordered zero-configuration">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Member</th>
                            <th>National</th>
                            <th>Pricelist</th>
                            <th>Amount</th>
                            <th>Account</th>
                            <th>Branch</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    
                                    <?php echo e($payment->invoice->membership->member->name ?? '-'); ?> <br>
                                    <?php echo e($payment->invoice->membership->member->phone ?? '-'); ?>

                                </td>
                                <td><?php echo e($payment->invoice->membership->member->national ?? '-'); ?></td>
                                <td><?php echo e($payment->invoice->membership->service_pricelist->name ?? '-'); ?></td>
                                <td><?php echo e(number_format($payment->amount) ?? '-'); ?></td>
                                <td><?php echo e($payment->account->name ?? '-'); ?></td>
                                <td><?php echo e($payment->invoice->membership->member->branch->name ?? '-'); ?></td>
                                <td><?php echo e($payment->created_at); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\gymapp\resources\views/admin/reports/tax_accountant.blade.php ENDPATH**/ ?>