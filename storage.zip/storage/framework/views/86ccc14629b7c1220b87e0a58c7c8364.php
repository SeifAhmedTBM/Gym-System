<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <h5><?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.membershipAttendance.title_singular')); ?></h5>
    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.membership-attendances.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="sign_in"><?php echo e(trans('cruds.membershipAttendance.fields.sign_in')); ?></label>
                <input class="form-control timepicker <?php echo e($errors->has('sign_in') ? 'is-invalid' : ''); ?>" type="text" name="sign_in" id="sign_in" value="<?php echo e(old('sign_in')); ?>">
                <?php if($errors->has('sign_in')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('sign_in')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.membershipAttendance.fields.sign_in_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="sign_out"><?php echo e(trans('cruds.membershipAttendance.fields.sign_out')); ?></label>
                <input class="form-control timepicker <?php echo e($errors->has('sign_out') ? 'is-invalid' : ''); ?>" type="text" name="sign_out" id="sign_out" value="<?php echo e(old('sign_out')); ?>">
                <?php if($errors->has('sign_out')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('sign_out')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.membershipAttendance.fields.sign_out_helper')); ?></span>
            </div>

            <div class="form-group">
                <label class="required" for="membership_id"><?php echo e(trans('cruds.membershipAttendance.fields.membership')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('membership') ? 'is-invalid' : ''); ?>" name="membership_id" id="membership_id" required>
                    <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('membership_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('membership')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('membership')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.membershipAttendance.fields.locker_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\gymapp\resources\views/admin/membershipAttendances/create.blade.php ENDPATH**/ ?>